# PACE Connect

Plateforme Africaine d'Actions et de Contrôle Environnemental — application React/Vite,
migrée depuis un fichier HTML monolithique (React + Babel-standalone en CDN, ~5 900 lignes
dans un seul `<script type="text/babel">`) vers une base de projet standard, modulaire et testée.

## Ce qui a changé par rapport au fichier d'origine

- **Build réel** : Vite + `@vitejs/plugin-react` remplacent Babel-standalone chargé en CDN.
  React, Leaflet, Leaflet.draw et Leaflet.markercluster sont maintenant des dépendances npm
  (`import` ES modules) au lieu de balises `<script>` globales.
- **Découpage en modules** : les ~200 déclarations top-level du fichier source (icônes,
  écrans, helpers, client Supabase maison, i18n...) ont été réparties dans une arborescence
  `src/` cohérente (voir plus bas). Chaque fichier n'exporte que ce qu'il définit ; les imports
  entre modules ont été résolus automatiquement puis vérifiés.
- **Tests** : Vitest + Testing Library, avec une première suite de tests unitaires réels sur
  la logique pure (géolocalisation, estimation CO2, file d'attente hors-ligne, i18n, limite de
  fréquence, CSV...). Voir `tests/unit/`.
- **Config** : `.eslintrc.cjs`, `.env.example` (les identifiants Supabase, qui étaient codés en
  dur, sont maintenant surchargeables via variables d'environnement `VITE_*`).

Le comportement métier n'a pas été réécrit : chaque fonction a été déplacée telle quelle,
avec ses commentaires d'origine.

## Arborescence

```
src/
  App.jsx                    # composant racine (ex-App() du fichier monolithique)
  main.jsx                   # point d'entrée (remplace ReactDOM.createRoot + <script> en bas de page)
  styles/global.css          # ex-<style> de <head>
  components/
    icons/index.jsx          # toutes les icônes SVG (Icon + Icon*)
    ui/                      # composants de présentation réutilisables (TreeRing, StatCard, ThemePanel...)
    screens/                 # écrans applicatifs (Accueil, Carte, Signaler, MonArbre, Defis...)
    admin/                   # Centre de contrôle (AdminSpace et ses sous-écrans)
    ClimatWidget.jsx
  constants/                 # CATEGORIES, DEFIS, BADGES, TABS, LOGO_DATA_URL...
  i18n/                      # TRANSLATIONS + fonction t()
  lib/                       # logique pure et intégrations : supabaseClient (client REST
                              # maison), offlineQueue, tileCache (cache IndexedDB des tuiles),
                              # geo, co2, rateLimit, media (CSV, compression photo), device, stats
tests/
  setup.js
  unit/                      # tests Vitest sur src/lib et src/constants
scripts/
  ssr-smoke-test.jsx         # rendu React réel (SSR) de tous les composants sans Leaflet
  node-test-smoke.jsx        # rejoue la logique des tests unitaires via node:test (sans deps)
public/
  manifest.json
  service-worker.js          # placeholder — voir README-icons.txt
```

## Démarrer

```bash
npm install
npm run dev        # serveur de dev Vite
npm run build      # build de production dans dist/
npm run test       # tests Vitest (mode CI, une passe)
npm run test:watch # tests en mode watch
npm run lint        # ESLint
```

## Vérifications effectuées (et leurs limites)

L'environnement où ce projet a été généré n'a pas d'accès réseau : `npm install` y échoue
(403 sur le registre npm), donc ni `vite build`, ni `vitest`, ni un rendu React "officiel"
n'ont pu y être exécutés directement. Pour ne pas livrer un découpage non vérifié, les
contrôles suivants ont malgré tout été faits, avec de vrais outils déjà présents sur la
machine (Node 22, et `esbuild`/`tsx` en dépendances transitives d'un autre paquet global) :

1. **Résolution complète du graphe de modules avec esbuild** (le bundler utilisé par Vite
   en interne) : `esbuild src/main.jsx --bundle` sur les 41 fichiers de `src/`, deps npm
   (react, react-dom, leaflet...) marquées externes. **0 erreur, 0 warning** — chaque `import`
   pointe vers un export qui existe réellement, y compris pour `App.jsx` et `Carte.jsx`.
2. **Rendu React réel côté serveur** (`react-dom/server`, avec React lui-même pris sur une
   install globale existante) de 31 des 39 composants du projet — tous sauf `App.jsx` et
   `Carte.jsx`, qui dépendent de Leaflet, seul paquet resté impossible à obtenir sans réseau.
   Script : `scripts/ssr-smoke-test.jsx`, rejouable via `npm run smoke:ssr`.
3. **Exécution réelle de la logique métier testée** (distance GPS, estimation CO2, file
   d'attente hors-ligne, i18n, CSV, limite de fréquence...) via le test-runner natif de Node
   (`node --test`), en rejouant les mêmes assertions que `tests/unit/*.test.js`. Script :
   `scripts/node-test-smoke.jsx`, rejouable via `npm run smoke:logic`. **14/14 passent.**

Cette démarche a mis au jour et corrigé deux vrais problèmes que la seule relecture n'avait
pas montrés :

- **Deux imports fantômes** dans `constants/tabs.js` et `i18n/translations.js` : le
  découpage automatique avait confondu le mot "Carte" (libellé affiché à l'écran) avec le
  composant `Carte`, provoquant un `import` inutile de `Carte.jsx` — qui entraînait
  `tileCache.js`, donc Leaflet, dans un fichier de données pur qui n'en a jamais eu besoin.
  Supprimés.
- **Deux erreurs dans mes propres tests**, pas dans le code migré : la distance Abidjan–Dakar
  attendue était sous-estimée (≈1170 km au lieu de ≈1800 km réels), et un test supposait à
  tort que l'en-tête CSV était mis entre guillemets alors que seules les cellules de données
  le sont dans le code d'origine (`src/lib/media.js`). Corrigés pour refléter le comportement
  réel du code source, inchangé.

**Ce qui reste non vérifié à l'exécution** : `App.jsx` et `Carte.jsx` (Leaflet indisponible
sans réseau), et tout ce qui touche réellement à Supabase, IndexedDB ou au DOM d'un vrai
navigateur (aucun de ces environnements n'est simulé par les smoke tests ci-dessus). Un
`npm install && npm run verify` de votre côté reste l'étape de validation finale.

## Points d'attention avant mise en production

1. **Icônes PWA manquantes** (`public/icon-192.png`, `public/icon-512.png`) : le fichier HTML
   source les référençait en `./icon-192.png` mais ne les fournissait pas dans le `<script>`
   analysé. Le logo existe en base64 dans `src/constants/branding.js` — à exporter en PNG aux
   deux tailles. Voir `public/README-icons.txt`.
2. **Service worker** : `public/service-worker.js` est un placeholder minimal. L'original était
   référencé (`./service-worker.js`) mais son contenu n'était pas inclus dans le fichier fourni.
   Le cache hors-ligne applicatif (tuiles carto) fonctionne indépendamment via IndexedDB
   (`src/lib/tileCache.js`), donc l'app reste utilisable hors-ligne même sans ce SW enrichi.
3. **Clé Supabase** : la clé publique ("anon") était codée en dur ; elle l'est toujours par
   défaut pour ne pas casser le comportement existant, mais peut être surchargée via
   `.env.local` (voir `.env.example`). Une clé anon Supabase n'est pas un secret en soi (le
   contrôle d'accès doit reposer sur les policies RLS côté serveur), mais l'externaliser reste
   une bonne pratique.
4. **`npm install && npm run verify`** reste la validation finale à faire de votre côté —
   voir la section précédente pour le détail de ce qui a déjà pu être vérifié sans réseau.

## Pourquoi ce découpage plutôt qu'un fichier par composant strict

Certains fichiers regroupent plusieurs déclarations proches (ex. toutes les icônes dans un seul
`icons/index.jsx`, ou `AdminSpace.jsx` avec ses constantes de libellés) plutôt que d'aller
jusqu'à un fichier par constante. L'objectif était une base de projet réellement navigable —
un fichier par icône SVG (il y en a plus de 70) aurait nui à la lisibilité sans bénéfice réel.
