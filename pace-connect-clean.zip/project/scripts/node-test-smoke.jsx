// Exécute les MÊMES assertions que tests/unit/*.test.js, mais avec node:test + node:assert
// (déjà inclus dans Node) au lieu de Vitest (non installable ici faute de réseau).
// Objectif : prouver que la logique testée est réellement correcte à l'exécution,
// pas seulement relue. Les fichiers tests/unit/*.test.js restent la suite officielle,
// à faire tourner avec `npm run test` une fois `npm install` possible.
import test from "node:test";
import assert from "node:assert/strict";

import { distanceMetres, pointInPolygon, gpsQualite, formatCap, formatVitesse } from "../src/lib/geo.js";
import { co2EstimeParArbre } from "../src/lib/co2.js";
import {
  loadPendingQueue,
  savePendingQueue,
  enqueuePendingAction,
  dequeuePendingAction,
  PENDING_QUEUE_KEY,
} from "../src/lib/offlineQueue.js";
import { categorieLabel, urgenceLabel, CATEGORIES, URGENCE } from "../src/constants/categories.js";
import { t, RTL_LANGS } from "../src/i18n/index.js";
import { weeksAgo, weeklyBuckets } from "../src/lib/stats.js";
import { uid, getDeviceId } from "../src/lib/device.js";
import { checkLimiteFrequence } from "../src/lib/rateLimit.js";
import { toCSV } from "../src/lib/media.js";

// --- Stub minimal de localStorage (Node n'en fournit pas nativement) ---
class MemoryStorage {
  constructor() { this.store = new Map(); }
  getItem(k) { return this.store.has(k) ? this.store.get(k) : null; }
  setItem(k, v) { this.store.set(k, String(v)); }
  removeItem(k) { this.store.delete(k); }
  clear() { this.store.clear(); }
}
globalThis.localStorage = new MemoryStorage();

test("distanceMetres: ~0 pour deux points identiques", () => {
  assert.ok(Math.abs(distanceMetres(5.35, -4.02, 5.35, -4.02)) < 1e-6);
});

test("distanceMetres: Abidjan-Dakar ~1800km", () => {
  const d = distanceMetres(5.3599, -4.0083, 14.6928, -17.4467);
  assert.ok(d > 1_750_000 && d < 1_850_000, `d=${d}`);
});

test("pointInPolygon: détecte intérieur/extérieur", () => {
  const carre = [[0, 0], [0, 10], [10, 10], [10, 0]];
  assert.equal(pointInPolygon([5, 5], carre), true);
  assert.equal(pointInPolygon([15, 15], carre), false);
});

test("gpsQualite: paliers corrects", () => {
  assert.equal(gpsQualite(5).label, "Excellente");
  assert.equal(gpsQualite(20).label, "Bonne");
  assert.equal(gpsQualite(40).label, "Moyenne");
  assert.equal(gpsQualite(200).label, "Faible");
  assert.equal(gpsQualite(null).label, "Inconnue");
});

test("formatCap / formatVitesse", () => {
  assert.equal(formatCap(0), "0° (N)");
  assert.equal(formatCap(90), "90° (E)");
  assert.equal(formatCap(null), "—");
  assert.equal(formatVitesse(10), "36.0 km/h");
  assert.equal(formatVitesse(undefined), "—");
});

test("co2EstimeParArbre: 0 à la plantation, 6kg à 1 an, 27kg à 2 ans", () => {
  assert.equal(co2EstimeParArbre({ plantedAt: Date.now() }), 0);
  assert.equal(co2EstimeParArbre({ plantedAt: Date.now() - 365 * 86400000 }), 6);
  assert.equal(co2EstimeParArbre({ plantedAt: Date.now() - 2 * 365 * 86400000 }), 27);
});

test("offlineQueue: enqueue/dequeue", () => {
  localStorage.clear();
  const id1 = enqueuePendingAction("signalement", { a: 1 });
  const id2 = enqueuePendingAction("arbre", { b: 2 });
  assert.equal(loadPendingQueue().length, 2);
  dequeuePendingAction(id1);
  const queue = loadPendingQueue();
  assert.equal(queue.length, 1);
  assert.equal(queue[0].id, id2);
});

test("offlineQueue: JSON corrompu -> file vide sans exception", () => {
  localStorage.clear();
  localStorage.setItem(PENDING_QUEUE_KEY, "{ pas du json valide");
  assert.deepEqual(loadPendingQueue(), []);
});

test("categorieLabel / urgenceLabel", () => {
  assert.equal(categorieLabel("en", "decharge"), "Illegal dump");
  assert.equal(categorieLabel("fr", "decharge"), CATEGORIES.find(c => c.id === "decharge").label);
  assert.equal(categorieLabel("fr", "inexistant"), "inexistant");
  assert.equal(urgenceLabel("fr", "haute"), URGENCE.find(u => u.id === "haute").label);
});

test("t(): fallback FR puis fallback clé brute", () => {
  assert.notEqual(t("fr", "nav_accueil"), t("en", "nav_accueil"));
  assert.equal(t("xx", "nav_accueil"), t("fr", "nav_accueil"));
  assert.equal(t("fr", "cle_inexistante_xyz"), "cle_inexistante_xyz");
  assert.ok(RTL_LANGS.includes("ar"));
});

test("weeksAgo / weeklyBuckets", () => {
  const isoDaysAgo = (d) => new Date(Date.now() - d * 86400000).toISOString();
  assert.equal(weeksAgo(isoDaysAgo(1), 0), true);
  assert.equal(weeksAgo(isoDaysAgo(15), 2), true);
  const buckets = weeklyBuckets([{ created_at: isoDaysAgo(1) }, { created_at: isoDaysAgo(9) }], 2);
  assert.equal(buckets.find(b => b.week === 0).count, 1);
  assert.equal(buckets.find(b => b.week === 1).count, 1);
});

test("uid / getDeviceId", () => {
  localStorage.clear();
  const a = uid(), b = uid();
  assert.match(a, /^[a-z0-9]+$/);
  assert.notEqual(a, b);
  const d1 = getDeviceId();
  const d2 = getDeviceId();
  assert.equal(d1, d2);
  assert.equal(localStorage.getItem("pace-device-id"), d1);
});

test("checkLimiteFrequence: bloque au-delà du seuil horaire", () => {
  localStorage.clear();
  assert.equal(checkLimiteFrequence(2), true);
  assert.equal(checkLimiteFrequence(2), true);
  assert.equal(checkLimiteFrequence(2), false);
});

test("toCSV: en-tête, échappement des guillemets, valeurs manquantes", () => {
  const columns = [{ key: "nom", label: "Nom" }, { key: "score", label: "Score" }];
  assert.equal(toCSV([{ nom: "Awa", score: 12 }], columns), 'Nom,Score\n"Awa","12"');
  assert.ok(toCSV([{ nom: 'Le "meilleur"', score: 5 }], columns).includes('"Le ""meilleur"""'));
  assert.equal(toCSV([{ nom: "Awa" }], columns), 'Nom,Score\n"Awa",""');
});
