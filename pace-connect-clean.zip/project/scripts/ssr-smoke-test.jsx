// Smoke test : rend chaque composant "sans Leaflet" côté serveur (react-dom/server)
// pour vérifier qu'il n'y a pas d'erreur au runtime (imports résolus ET exécution réelle),
// au-delà de la simple vérification syntaxique. Carte.jsx et App.jsx sont exclus car ils
// dépendent de Leaflet, non installable ici faute d'accès réseau (voir LIMITES.md).
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";

import { Screen } from "../src/components/ui/Screen.jsx";
import { SectionTitle } from "../src/components/ui/SectionTitle.jsx";
import { StatCard } from "../src/components/ui/StatCard.jsx";
import { TreeRing } from "../src/components/ui/TreeRing.jsx";
import { ThemePanel } from "../src/components/ui/ThemePanel.jsx";
import { SplashScreen } from "../src/components/ui/SplashScreen.jsx";
import { PasswordInput } from "../src/components/ui/PasswordInput.jsx";
import { ConfirmActionModal } from "../src/components/ui/ConfirmActionModal.jsx";
import { MiniBarChart } from "../src/components/ui/MiniBarChart.jsx";
import { NotifBell } from "../src/components/ui/NotifBell.jsx";

import { ClimatWidget } from "../src/components/ClimatWidget.jsx";

import { Accueil } from "../src/components/screens/Accueil.jsx";
import { Signaler } from "../src/components/screens/Signaler.jsx";
import { MonArbre } from "../src/components/screens/MonArbre.jsx";
import { SuiviForm } from "../src/components/screens/SuiviForm.jsx";
import { Classement } from "../src/components/screens/Classement.jsx";
import { Defis } from "../src/components/screens/Defis.jsx";
import { VolunteerCard } from "../src/components/screens/VolunteerCard.jsx";
import { BenevoleAccesBloque } from "../src/components/screens/BenevoleAccesBloque.jsx";
import { Biodiversite } from "../src/components/screens/Biodiversite.jsx";
import { AssistantIA } from "../src/components/screens/AssistantIA.jsx";
import { Confidentialite } from "../src/components/screens/Confidentialite.jsx";
import { Onboarding } from "../src/components/screens/Onboarding.jsx";
import { InscriptionCitoyen } from "../src/components/screens/InscriptionCitoyen.jsx";

import { AdminSpace } from "../src/components/admin/AdminSpace.jsx";
import { AdminActualites } from "../src/components/admin/AdminActualites.jsx";
import { AdminSuppressions } from "../src/components/admin/AdminSuppressions.jsx";
import { AdminBenevoles } from "../src/components/admin/AdminBenevoles.jsx";
import { AdminRapports } from "../src/components/admin/AdminRapports.jsx";
import { AdminEquipe } from "../src/components/admin/AdminEquipe.jsx";
import { AdminHistorique } from "../src/components/admin/AdminHistorique.jsx";

const noop = () => {};

const cases = [
  ["Screen", <Screen>contenu</Screen>],
  ["SectionTitle", <SectionTitle sub="sous-titre">Titre</SectionTitle>],
  ["StatCard", <StatCard label="Signalements" value={12} unit="pts" />],
  ["TreeRing", <TreeRing pct={42} />],
  ["ThemePanel", <ThemePanel themeMode="light" accent="green" lang="fr" onSetMode={noop} onSetAccent={noop} onSetLang={noop} onClose={noop} />],
  ["SplashScreen", <SplashScreen />],
  ["PasswordInput", <PasswordInput value="" onChange={noop} placeholder="mdp" ariaLabel="mdp" />],
  ["ConfirmActionModal", <ConfirmActionModal title="Titre" description="desc" confirmLabel="OK" onConfirm={noop} onCancel={noop} />],
  ["MiniBarChart", <MiniBarChart data={[{ week: 0, count: 3 }, { week: 1, count: 5 }]} color="#4CAF50" label="Signalements" />],
  ["NotifBell", <NotifBell email={null} onNavigate={noop} />],
  ["ClimatWidget", <ClimatWidget lang="fr" />],
  ["Accueil", <Accueil signalements={[]} arbres={[]} defisProgress={{ points: 0 }} notifState="default" onEnableNotif={noop} onOpenAdmin={noop} actualites={[]} onNavigate={noop} lang="fr" />],
  ["Signaler", <Signaler onSubmit={noop} lang="fr" />],
  ["MonArbre", <MonArbre arbres={[]} suivis={[]} onAdd={noop} onAddSuivi={noop} lang="fr" />],
  ["SuiviForm", <SuiviForm onSave={noop} onCancel={noop} />],
  ["Classement", <Classement myPoints={10} myPseudo="Awa" onSavePseudo={noop} lang="fr" />],
  ["Defis", <Defis progress={{ points: 0 }} onIncrement={noop} badgeState={{ signalements: [], arbres: [], defisProgress: {} }} onSavePseudo={noop} lang="fr" />],
  ["VolunteerCard", <VolunteerCard lang="fr" />],
  ["BenevoleAccesBloque", <BenevoleAccesBloque statut="en_attente" />],
  ["Biodiversite", <Biodiversite observations={[]} onAdd={noop} onBack={noop} lang="fr" />],
  ["AssistantIA", <AssistantIA onBack={noop} signalements={[]} arbres={[]} observations={[]} actualites={[]} defisProgress={{}} />],
  ["Confidentialite", <Confidentialite onBack={noop} />],
  ["Onboarding", <Onboarding onDone={noop} />],
  ["InscriptionCitoyen", <InscriptionCitoyen onSuccess={noop} onAdminAccess={noop} />],
  ["AdminSpace", <AdminSpace signalements={[]} arbres={[]} onUpdateStatut={noop} onResolve={noop} onValidate={noop} onValidateArbre={noop} onDelete={noop} onSoftDeleteArbre={noop} onRevertModeration={noop} onSoftDeleteSignalement={noop} onExit={noop} />],
  ["AdminActualites", <AdminActualites />],
  ["AdminSuppressions", <AdminSuppressions />],
  ["AdminBenevoles", <AdminBenevoles />],
  ["AdminRapports", <AdminRapports signalements={[]} arbres={[]} />],
  ["AdminEquipe", <AdminEquipe />],
  ["AdminHistorique", <AdminHistorique />],
];

let ok = 0;
let fail = 0;
for (const [name, el] of cases) {
  try {
    renderToStaticMarkup(el);
    console.log(`OK   ${name}`);
    ok++;
  } catch (e) {
    console.log(`FAIL ${name} -> ${e.message}`);
    fail++;
  }
}
console.log(`\n${ok} composants rendus avec succès, ${fail} échec(s), sur ${cases.length} testés.`);
if (fail > 0) process.exit(1);
