import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Remplace le tandem Babel-standalone + CDN de l'ancien fichier HTML unique.
// manifest.json et service-worker.js restent dans /public : Vite les copie tels
// quels dans dist/ au build, exactement comme ils étaient servis en statique avant.
export default defineConfig({
  plugins: [react()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./tests/setup.js"],
    coverage: {
      provider: "v8",
      reporter: ["text", "html"],
    },
  },
});
