import { useEffect, useMemo, useState } from 'react';
import { AdminSpace } from './components/admin/AdminSpace';
import { IconClock, IconSettings, IconShield, IconWifiOff } from './components/icons/index';
import { Accueil } from './components/screens/Accueil';
import { AssistantIA } from './components/screens/AssistantIA';
import { BenevoleAccesBloque } from './components/screens/BenevoleAccesBloque';
import { Biodiversite } from './components/screens/Biodiversite';
import { Carte } from './components/screens/Carte';
import { Confidentialite } from './components/screens/Confidentialite';
import { Defis } from './components/screens/Defis';
import { MonArbre } from './components/screens/MonArbre';
import { Onboarding } from './components/screens/Onboarding';
import { Signaler } from './components/screens/Signaler';
import { SplashScreen } from './components/ui/SplashScreen';
import { ThemePanel } from './components/ui/ThemePanel';
import { LOGO_DATA_URL } from './constants/branding';
import { CATEGORIES } from './constants/categories';
import { DEFIS } from './constants/defis';
import { TABS } from './constants/tabs';
import { RTL_LANGS, t } from './i18n/index';
import { logActivity, logAudit } from './lib/activity';
import { DEVICE_ID } from './lib/device';
import { distanceMetres } from './lib/geo';
import { dequeuePendingAction, enqueuePendingAction, loadPendingQueue } from './lib/offlineQueue';
import { subscribeToPush } from './lib/push';
import { checkLimiteFrequence } from './lib/rateLimit';
import { currentSession, refreshSessionIfNeeded, supabase } from './lib/supabaseClient';

export function App() {
  // Deep-linking depuis la page d'accueil publique (pace-accueil.html) ou tout lien externe :
  // ?tab=carte|signaler|arbre|defis  → ouvre directement l'onglet correspondant
  // ?admin=1                         → ouvre le Centre de contrôle PACE
  // Lecture unique au montage, ne modifie aucun comportement existant si absent de l'URL.
  const initialUrlState = useMemo(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const t = params.get("tab");
      const validTabs = ["accueil", "carte", "signaler", "arbre", "defis"];
      let initialTab = "accueil";
      if (t && validTabs.includes(t)) initialTab = t;
      return { initialTab, initialAdmin: params.get("admin") === "1" };
    } catch (e) {
      return { initialTab: "accueil", initialAdmin: false };
    }
  }, []);

  const [tab, setTab] = useState(initialUrlState.initialTab);
  const [showAdmin, setShowAdmin] = useState(initialUrlState.initialAdmin);
  const [showOnboarding, setShowOnboarding] = useState(() => {
    try { return !localStorage.getItem("pace-onboarded"); } catch (e) { return false; }
  });
  const [showSplash, setShowSplash] = useState(true);
  const [citoyenSession, setCitoyenSession] = useState(undefined); // undefined = en cours de vérification, null = pas connecté
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setCitoyenSession(data.session || null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setCitoyenSession(s));
    return () => sub && sub.subscription && sub.subscription.unsubscribe();
  }, []);

  // Statut bénévole de cet appareil : null tant qu'aucune inscription n'existe (accès libre en tant que citoyen).
  // Un enregistrement existant bloque l'accès au contenu tant qu'il n'est pas "valide" (voir Centre de contrôle PACE > Bénévoles).
  const [benevoleStatut, setBenevoleStatut] = useState(null);
  useEffect(() => {
    supabase.from("benevoles").select("statut").eq("device_id", DEVICE_ID).eq("is_deleted", false).order("created_at", { ascending: false }).limit(1)
      .then(({ data }) => {
        if (data && data[0]) setBenevoleStatut(data[0].statut || "valide");
      });
  }, []);
  const accesBloque = benevoleStatut && benevoleStatut !== "valide";

  const [showThemePanel, setShowThemePanel] = useState(false);

  const [themeMode, setThemeMode] = useState(() => {
    try { return localStorage.getItem("pace-theme-mode") || "system"; } catch (e) { return "system"; }
  });
  const [accent, setAccent] = useState(() => {
    try { return localStorage.getItem("pace-theme-accent") || "green"; } catch (e) { return "green"; }
  });
  const [systemDark, setSystemDark] = useState(() => {
    try { return window.matchMedia("(prefers-color-scheme: dark)").matches; } catch (e) { return false; }
  });

  useEffect(() => {
    try {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const handler = (e) => setSystemDark(e.matches);
      mq.addEventListener ? mq.addEventListener("change", handler) : mq.addListener(handler);
      return () => { mq.removeEventListener ? mq.removeEventListener("change", handler) : mq.removeListener(handler); };
    } catch (e) {}
  }, []);

  const isDark = themeMode === "dark" || (themeMode === "system" && systemDark);

  function updateThemeMode(mode) {
    setThemeMode(mode);
    try { localStorage.setItem("pace-theme-mode", mode); } catch (e) {}
  }
  function updateAccent(a) {
    setAccent(a);
    try { localStorage.setItem("pace-theme-accent", a); } catch (e) {}
  }

  // Point 3 : accessibilité — langue de l'interface (FR/EN pour commencer)
  const [lang, setLang] = useState(() => {
    try { return localStorage.getItem("pace-lang") || "fr"; } catch (e) { return "fr"; }
  });
  function updateLang(l) {
    setLang(l);
    try { localStorage.setItem("pace-lang", l); } catch (e) {}
  }

  useEffect(() => {
    const t = setTimeout(() => setShowSplash(false), 1100);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      subscribeToPush();
    }
  }, []);

  useEffect(() => {
    refreshSessionIfNeeded();
    const t = setInterval(refreshSessionIfNeeded, 5 * 60 * 1000);
    return () => clearInterval(t);
  }, []);

  const [signalements, setSignalements] = useState([]);
  const [arbres, setArbres] = useState([]);
  const [defisProgress, setDefisProgress] = useState({ points: 0 });
  const [loaded, setLoaded] = useState(false);
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [notifState, setNotifState] = useState(typeof Notification !== "undefined" ? Notification.permission : "unsupported");
  const [actualites, setActualites] = useState([]);
  const [observations, setObservations] = useState([]);
  const [suivis, setSuivis] = useState([]);
  const [pendingQueueCount, setPendingQueueCount] = useState(() => loadPendingQueue().length);

  useEffect(() => {
    const goOnline = () => { setOnline(true); flushPendingQueue(); };
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    if (navigator.onLine) flushPendingQueue();
    const retryTimer = setInterval(() => { if (navigator.onLine) flushPendingQueue(); }, 20000);
    return () => { window.removeEventListener("online", goOnline); window.removeEventListener("offline", goOffline); clearInterval(retryTimer); };
  }, []);

  function enableNotif() {
    if (typeof Notification === "undefined") return;
    Notification.requestPermission().then((perm) => {
      setNotifState(perm);
      if (perm === "granted") subscribeToPush();
    });
  }

  async function adminUpdateStatut(id, next) {
    const clear = next !== "resolu" ? { resolution_organisme: null, resolution_action: null, resolved_at: null } : {};
    setSignalements(prev => prev.map(s => s.id === id ? { ...s, statut: next, ...clear } : s));
    const { error } = await supabase.from("signalements").update({ statut: next, ...clear }).eq("id", id);
    if (error) {
      console.error("Erreur de mise à jour du statut :", error);
      alert("Action refusée par le serveur (droits admin requis).");
    } else {
      logActivity(next === "resolu" ? "resolution" : "reouverture", "signalements", id);
      if (next === "resolu" && typeof Notification !== "undefined" && Notification.permission === "granted") {
        try { new Notification("Signalement mis à jour", { body: "Un signalement a été marqué comme résolu.", icon: "./icon-192.png" }); } catch (e) {}
      }
    }
  }

  async function adminResolve(signalement, { organisme, action }) {
    const payload = { statut: "resolu", resolution_organisme: organisme, resolution_action: action, resolved_at: new Date().toISOString() };
    const { data, error } = await supabase.from("signalements").update(payload).eq("id", signalement.id).select();
    if (error || !data || data.length === 0) { alert("Action refusée par le serveur (droits admin requis)."); return; }
    setSignalements(prev => prev.map(s => s.id === signalement.id ? { ...s, ...payload } : s));
    logActivity("resolution", "signalements", signalement.id, `${organisme} — ${action}`);
  }

  async function adminValidate(id) {
    setSignalements(prev => prev.map(s => s.id === id ? { ...s, valide: true } : s));
    const { error } = await supabase.from("signalements").update({ valide: true }).eq("id", id);
    if (error) { console.error("Erreur de validation :", error); alert("Action refusée par le serveur (droits admin requis)."); }
    else logActivity("validation", "signalements", id);
  }

  async function adminValidateArbre(id) {
    setArbres(prev => prev.map(a => a.id === id ? { ...a, valide: true } : a));
    const { error } = await supabase.from("arbres").update({ valide: true }).eq("id", id);
    if (error) { console.error("Erreur de validation :", error); alert("Action refusée par le serveur (droits admin requis)."); }
    else logActivity("validation", "arbres", id);
  }

  const MOTIF_LABELS = { faux: "Faux signalement", doublon: "Doublon", spam: "Spam", erreur_localisation: "Erreur de localisation" };

  async function adminRevertModeration(signalement, { reason, motif }) {
    const email = currentSession && currentSession.user ? currentSession.user.email : "";
    setSignalements(prev => prev.map(s => s.id === signalement.id ? { ...s, valide: false, statut: "attente", moderation_motif: motif, moderation_par: email } : s));
    await supabase.from("signalements").update({
      valide: false, statut: "attente", moderation_motif: motif, moderation_par: email, moderation_le: new Date().toISOString(),
    }).eq("id", signalement.id);
    await logAudit("revert_statut", "signalement", signalement.id, reason, { motif });
    // Notifie l'auteur du signalement (citoyen, identifié par device_id)
    supabase.from("notifications").insert({
      destinataire: signalement.device_id,
      message: `Ton signalement a été repassé en vérification. Motif : ${MOTIF_LABELS[motif] || motif}.`,
      lien: "carte",
    }).catch(() => {});
  }

  async function adminSoftDeleteSignalement(signalement, { reason }) {
    const email = currentSession && currentSession.user ? currentSession.user.email : "";
    const { data, error } = await supabase.from("signalements").update({ is_deleted: true, deleted_at: new Date().toISOString(), deleted_by: email }).eq("id", signalement.id).select();
    if (error || !data || data.length === 0) { alert("Suppression refusée par le serveur (droits admin requis) : le signalement n'a pas été modifié et réapparaîtra."); return; }
    await logAudit("soft_delete", "signalement", signalement.id, reason);
    logActivity("soft_delete", "signalements", signalement.id, reason);
    setSignalements(prev => prev.filter(s => s.id !== signalement.id));
  }

  async function adminDelete(table, id) {
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) { alert("Suppression refusée par le serveur."); return; }
    logActivity("suppression", table, id);
    if (table === "signalements") setSignalements(prev => prev.filter(s => s.id !== id));
    if (table === "arbres") setArbres(prev => prev.filter(a => a.id !== id));
  }

  async function adminSoftDeleteArbre(arbre) {
    const email = currentSession && currentSession.user ? currentSession.user.email : "";
    const { data, error } = await supabase.from("arbres").update({ is_deleted: true, deleted_at: new Date().toISOString(), deleted_by: email }).eq("id", arbre.id).select();
    if (error) { alert("Action refusée par le serveur (droits admin requis)."); return; }
    if (!data || data.length === 0) { alert("Suppression refusée par le serveur (droits admin requis) : l'arbre n'a pas été modifié et réapparaîtra."); return; }
    logActivity("soft_delete", "arbres", arbre.id, arbre.nom || "Arbre");
    setArbres(prev => prev.filter(a => a.id !== arbre.id));
  }

  function mapSignalement(r) {
    const d = new Date(r.created_at);
    return { ...r, date: d.toLocaleDateString("fr-FR") + " " + d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) };
  }
  function mapArbre(r) {
    return { ...r, date: new Date(r.planted_at).toLocaleDateString("fr-FR"), plantedAt: new Date(r.planted_at).getTime() };
  }

  useEffect(() => {
    (async () => {
      try {
        const [{ data: sigs }, { data: trees }, { data: progress }, { data: news }, { data: obs }, { data: suiv }] = await Promise.all([
          supabase.from("signalements").select("*").eq("is_deleted", false).order("created_at", { ascending: false }).limit(300),
          supabase.from("arbres").select("*").eq("is_deleted", false).order("created_at", { ascending: false }).limit(300),
          supabase.from("defis_progress").select("*").eq("device_id", DEVICE_ID).maybeSingle(),
          supabase.from("actualites").select("*").order("created_at", { ascending: false }).limit(20),
          supabase.from("observations").select("*").order("created_at", { ascending: false }).limit(200),
          supabase.from("arbre_suivis").select("*").order("created_at", { ascending: false }).limit(1000),
        ]);
        setSignalements((sigs || []).reverse().map(mapSignalement));
        setArbres((trees || []).reverse().map(mapArbre));
        setDefisProgress(progress || { points: 0 });
        setActualites(news || []);
        setObservations((obs || []).reverse());
        setSuivis(suiv || []);

        const lastSeen = localStorage.getItem("pace-last-alert") || "";
        const newAlert = (news || []).find(n => n.urgent && n.created_at > lastSeen);
        if (newAlert && typeof Notification !== "undefined" && Notification.permission === "granted") {
          try { new Notification("Alerte PACE — " + newAlert.titre, { body: newAlert.contenu, icon: "./icon-192.png" }); } catch (e) {}
        }
        if (news && news[0]) localStorage.setItem("pace-last-alert", news[0].created_at);
      } catch (e) {
        console.error("Erreur de chargement Supabase :", e);
      }
      setLoaded(true);
    })();
  }, []);

  async function syncDefisProgress(next) {
    setDefisProgress(next);
    try {
      await supabase.from("defis_progress").upsert({ device_id: DEVICE_ID, ...next }, { onConflict: "device_id" });
    } catch (e) { console.error("Erreur de synchronisation des défis :", e); }
  }

  async function uploadPhoto(dataUrl, prefix) {
    if (!dataUrl) return null;
    try {
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      const ext = (blob.type.split("/")[1] || "jpg").split("+")[0];
      const path = `${prefix}/${DEVICE_ID}-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("pace-photos").upload(path, blob, { contentType: blob.type });
      if (error) throw error;
      const { data } = supabase.storage.from("pace-photos").getPublicUrl(path);
      return data.publicUrl;
    } catch (e) {
      console.error("Erreur d'upload photo :", e);
      return null;
    }
  }

  async function addSuivi(arbreId, { photo, etat, note }) {
    try {
      const photo_url = await uploadPhoto(photo, "suivis");
      const { data, error } = await supabase.from("arbre_suivis").insert({ arbre_id: arbreId, photo_url, etat: etat || "vivant", note: note || null, device_id: DEVICE_ID }).select().single();
      if (error) throw error;
      setSuivis(prev => [data, ...prev]);
    } catch (e) {
      console.error("Erreur d'ajout du suivi :", e);
      alert("Impossible d'enregistrer ce suivi pour le moment (connexion ?).");
    }
  }

  async function addSignalement(s, opts) {
    opts = opts || {};
    if (!opts.isReplay) {
      if (!checkLimiteFrequence(12)) {
        alert("Trop de signalements envoyés depuis cet appareil en une heure. Réessaie plus tard.");
        return;
      }
      const doublonProche = signalements.find(x => !x._pending && x.categorie === s.categorie && distanceMetres(x.lat, x.lng, s.lat, s.lng) < 25 && (Date.now() - new Date(x.created_at || x.date).getTime()) < 172800000);
      if (doublonProche && !window.confirm("Un signalement similaire (même catégorie) existe déjà à moins de 25 m d'ici, envoyé récemment. Envoyer quand même ?")) {
        return;
      }
    }
    const { photo, ...toInsert } = s;
    if (!opts.isReplay && !navigator.onLine) {
      const tempId = enqueuePendingAction("signalement", s);
      setPendingQueueCount(loadPendingQueue().length);
      setSignalements(prev => [...prev, { ...toInsert, id: tempId, photo_url: photo || null, device_id: DEVICE_ID, date: new Date().toLocaleDateString("fr-FR") + " " + new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), _pending: true }]);
      return;
    }
    try {
      const photo_url = await uploadPhoto(photo, "signalements");
      const { data, error } = await supabase.from("signalements").insert({ ...toInsert, photo_url, device_id: DEVICE_ID, is_deleted: false }).select().single();
      if (error) throw error;
      setSignalements(prev => {
        const withoutPending = opts.tempId ? prev.filter(x => x.id !== opts.tempId) : prev;
        return [...withoutPending, mapSignalement(data)];
      });
      if (opts.tempId) dequeuePendingAction(opts.tempId);
      if (s.urgence === "haute") {
        supabase.from("admins").select("email").then(({ data: admins }) => {
          (admins || []).forEach(a => {
            supabase.from("notifications").insert({
              destinataire: a.email, message: `Signalement urgent à valider (${(CATEGORIES.find(c => c.id === s.categorie) || {}).label || s.categorie})`, lien: "signalements",
            }).catch(() => {});
          });
        });
      }
    } catch (e) {
      console.error("Erreur d'envoi du signalement :", e);
      if (opts.isReplay) { throw e; }
      const tempId = enqueuePendingAction("signalement", s);
      setPendingQueueCount(loadPendingQueue().length);
      setSignalements(prev => [...prev, { ...toInsert, id: tempId, photo_url: photo || null, device_id: DEVICE_ID, date: new Date().toLocaleDateString("fr-FR") + " " + new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), _pending: true }]);
      alert("Pas de connexion : ton signalement a été enregistré sur l'appareil et sera envoyé automatiquement dès que le réseau reviendra.");
    }
  }

  async function addArbre(a, opts) {
    opts = opts || {};
    if (!opts.isReplay) {
      if (!checkLimiteFrequence(20)) {
        alert("Trop d'arbres enregistrés depuis cet appareil en une heure. Réessaie plus tard.");
        return;
      }
      const doublonProche = arbres.find(x => !x._pending && distanceMetres(x.lat, x.lng, a.lat, a.lng) < 3 && (Date.now() - (x.plantedAt || 0)) < 600000);
      if (doublonProche && !window.confirm("Un arbre vient déjà d'être enregistré à moins de 3 m d'ici. Ajouter quand même ?")) {
        return;
      }
    }
    const { photo, ...toInsert } = a;
    if (!opts.isReplay && !navigator.onLine) {
      const tempId = enqueuePendingAction("arbre", a);
      setPendingQueueCount(loadPendingQueue().length);
      setArbres(prev => [...prev, { ...toInsert, id: tempId, photo_url: photo || null, device_id: DEVICE_ID, planted_at: new Date().toISOString(), date: new Date().toLocaleDateString("fr-FR"), plantedAt: Date.now(), _pending: true }]);
      return;
    }
    try {
      const photo_url = await uploadPhoto(photo, "arbres");
      const { data, error } = await supabase.from("arbres").insert({ ...toInsert, photo_url, device_id: DEVICE_ID, is_deleted: false }).select().single();
      if (error) throw error;
      setArbres(prev => {
        const withoutPending = opts.tempId ? prev.filter(x => x.id !== opts.tempId) : prev;
        return [...withoutPending, mapArbre(data)];
      });
      if (opts.tempId) dequeuePendingAction(opts.tempId);
      const cur = (defisProgress.d1 || 0) + 1;
      const justCompleted = cur === DEFIS[0].target;
      syncDefisProgress({ ...defisProgress, d1: cur, points: defisProgress.points + (justCompleted ? DEFIS[0].points : 0) });
    } catch (e) {
      console.error("Erreur d'enregistrement de l'arbre :", e);
      if (opts.isReplay) { throw e; }
      const tempId = enqueuePendingAction("arbre", a);
      setPendingQueueCount(loadPendingQueue().length);
      setArbres(prev => [...prev, { ...toInsert, id: tempId, photo_url: photo || null, device_id: DEVICE_ID, planted_at: new Date().toISOString(), date: new Date().toLocaleDateString("fr-FR"), plantedAt: Date.now(), _pending: true }]);
      alert("Pas de connexion : ton arbre a été enregistré sur l'appareil et sera envoyé automatiquement dès que le réseau reviendra.");
    }
  }

  async function addObservation(o, opts) {
    opts = opts || {};
    const { photo, ...toInsert } = o;
    if (!opts.isReplay && !navigator.onLine) {
      const tempId = enqueuePendingAction("observation", o);
      setPendingQueueCount(loadPendingQueue().length);
      setObservations(prev => [...prev, { ...toInsert, id: tempId, photo_url: photo || null, device_id: DEVICE_ID, created_at: new Date().toISOString(), _pending: true }]);
      return;
    }
    try {
      const photo_url = await uploadPhoto(photo, "observations");
      const { data, error } = await supabase.from("observations").insert({ ...toInsert, photo_url, device_id: DEVICE_ID }).select().single();
      if (error) throw error;
      setObservations(prev => {
        const withoutPending = opts.tempId ? prev.filter(x => x.id !== opts.tempId) : prev;
        return [...withoutPending, data];
      });
      if (opts.tempId) dequeuePendingAction(opts.tempId);
    } catch (e) {
      if (opts.isReplay) { throw e; }
      const tempId = enqueuePendingAction("observation", o);
      setPendingQueueCount(loadPendingQueue().length);
      setObservations(prev => [...prev, { ...toInsert, id: tempId, photo_url: photo || null, device_id: DEVICE_ID, created_at: new Date().toISOString(), _pending: true }]);
      alert("Pas de connexion : ton observation a été enregistrée sur l'appareil et sera envoyée automatiquement dès que le réseau reviendra.");
    }
  }

  async function flushPendingQueue() {
    if (!navigator.onLine) return;
    const queue = loadPendingQueue();
    for (const item of queue) {
      try {
        if (item.type === "signalement") await addSignalement(item.payload, { isReplay: true, tempId: item.id });
        else if (item.type === "arbre") await addArbre(item.payload, { isReplay: true, tempId: item.id });
        else if (item.type === "observation") await addObservation(item.payload, { isReplay: true, tempId: item.id });
        else dequeuePendingAction(item.id);
      } catch (e) {
        // Le réseau est probablement encore instable : on arrête ici et on
        // réessaiera au prochain événement 'online' ou au prochain tick.
        break;
      }
    }
    setPendingQueueCount(loadPendingQueue().length);
  }


  async function savePseudo(pseudo) {
    await syncDefisProgress({ ...defisProgress, pseudo });
  }

  function incrementDefi(d) {
    if (d.id === "d1") return; // "Planter 10 arbres" est suivi automatiquement depuis les vraies plantations (addArbre), jamais incrémenté artificiellement.
    const cur = Math.min(d.target, (defisProgress[d.id] || 0) + Math.ceil(d.target / 5));
    const wasDone = (defisProgress[d.id] || 0) >= d.target;
    const nowDone = cur >= d.target;
    syncDefisProgress({ ...defisProgress, [d.id]: cur, points: defisProgress.points + (!wasDone && nowDone ? d.points : 0) });
  }

  return (
    <div dir={RTL_LANGS.includes(lang) ? "rtl" : "ltr"} className={`pace-app-outer ${isDark ? "pace-dark" : ""} accent-${accent}`} style={{ fontFamily: "Work Sans, sans-serif", background: "var(--c-bg)", minHeight: "100vh", display: "flex", justifyContent: "center", transition: "background-color .25s ease" }}>
      {showSplash && <SplashScreen />}
      {showOnboarding && !showSplash && (
        <Onboarding onDone={() => {
          try { localStorage.setItem("pace-onboarded", "1"); } catch (e) {}
          setShowOnboarding(false);
        }} />
      )}
      <div className={`pace-frame ${showAdmin ? "pace-frame-wide" : ""}`} style={{ minHeight: "100vh", background: "var(--c-bg)", position: "relative", boxShadow: "0 0 40px rgba(0,0,0,0.08)", transition: "background-color .25s ease" }}>
        <div style={{ background: "linear-gradient(120deg,var(--c-accent-dark),var(--c-sky))", color: "#fff", padding: "18px 16px 22px", borderRadius: "0 0 20px 20px", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 42, height: 42, borderRadius: "50%", background: "var(--c-surface)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, overflow: "hidden" }}>
            <img src={LOGO_DATA_URL} alt={t(lang, "logo_pace_alt")} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "Fraunces, serif", fontWeight: 700, fontSize: 20, letterSpacing: 0.3 }}>PACE Connect</div>
            <div style={{ fontSize: 10.5, opacity: 0.9, lineHeight: 1.3 }}>{t(lang, "plateforme_desc")}</div>
            <div style={{ fontSize: 10, opacity: 0.75, marginTop: 1 }}>{t(lang, "sub_accueil")}</div>
          </div>
          <button onClick={() => setShowThemePanel(true)} aria-label={t(lang, "reglages_affichage")} title={t(lang, "reglages_affichage")} style={{
            background: "rgba(255,255,255,0.18)", border: "none", borderRadius: "50%", width: 38, height: 38,
            display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}>
            <IconSettings size={17} color="#fff" />
          </button>
          {!showAdmin && (
            <button onClick={() => setShowAdmin(true)} aria-label={t(lang, "centre_controle")} title={t(lang, "centre_controle")} style={{
              background: "rgba(255,255,255,0.18)", border: "none", borderRadius: "50%", width: 38, height: 38,
              display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}>
              <IconShield size={17} color="#fff" />
            </button>
          )}
        </div>

        {showThemePanel && (
          <ThemePanel
            themeMode={themeMode} accent={accent} lang={lang}
            onSetMode={updateThemeMode} onSetAccent={updateAccent} onSetLang={updateLang}
            onClose={() => setShowThemePanel(false)}
          />
        )}

        {!online && (
          <div style={{ background: "#B5451B", color: "#fff", fontSize: 11.5, textAlign: "center", padding: "6px 0", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <IconWifiOff size={13} /> {t(lang, "hors_ligne_banner")}{pendingQueueCount > 0 ? ` (${pendingQueueCount} ${t(lang, "hors_ligne_banner_attente")})` : ""}
          </div>
        )}
        {online && pendingQueueCount > 0 && (
          <div style={{ background: "var(--c-warning)", color: "#fff", fontSize: 11.5, textAlign: "center", padding: "6px 0", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <IconClock size={13} /> {t(lang, "envoi_en_cours_prefix")} {pendingQueueCount} {t(lang, "envoi_attente_suffix")}
          </div>
        )}

        {showAdmin ? (
          <AdminSpace signalements={signalements} arbres={arbres} onUpdateStatut={adminUpdateStatut} onResolve={adminResolve} onValidate={adminValidate} onValidateArbre={adminValidateArbre} onDelete={adminDelete} onSoftDeleteArbre={adminSoftDeleteArbre} onRevertModeration={adminRevertModeration} onSoftDeleteSignalement={adminSoftDeleteSignalement} onExit={() => setShowAdmin(false)} />
        ) : accesBloque ? (
          <BenevoleAccesBloque statut={benevoleStatut} />
        ) : tab === "biodiversite" ? (
          <Biodiversite observations={observations} onAdd={addObservation} onBack={() => setTab("accueil")} lang={lang} />
        ) : tab === "confidentialite" ? (
          <Confidentialite onBack={() => setTab("accueil")} />
        ) : tab === "assistant" ? (
          <AssistantIA onBack={() => setTab("accueil")} signalements={signalements} arbres={arbres} observations={observations} actualites={actualites} defisProgress={defisProgress} />
        ) : (
          <div key={tab} className="pace-fade-in">
            {tab === "accueil" && <Accueil signalements={signalements.filter(s => s.device_id === DEVICE_ID)} arbres={arbres.filter(a => a.device_id === DEVICE_ID)} defisProgress={defisProgress} notifState={notifState} onEnableNotif={enableNotif} onOpenAdmin={() => setShowAdmin(true)} actualites={actualites} onNavigate={setTab} lang={lang} />}
            {tab === "carte" && <Carte signalements={signalements} arbres={arbres} observations={observations} onAddSignalement={addSignalement} onAddArbre={addArbre} onAddObservation={addObservation} online={online} pendingQueueCount={pendingQueueCount} onFlushQueue={flushPendingQueue} lang={lang} />}
            {tab === "signaler" && <Signaler onSubmit={addSignalement} lang={lang} />}
            {tab === "arbre" && <MonArbre arbres={arbres.filter(a => a.device_id === DEVICE_ID)} suivis={suivis} onAdd={addArbre} onAddSuivi={addSuivi} lang={lang} />}
            {tab === "defis" && <Defis progress={defisProgress} onIncrement={incrementDefi} badgeState={{ signalements: signalements.filter(s => s.device_id === DEVICE_ID), arbres: arbres.filter(a => a.device_id === DEVICE_ID), defisProgress }} onSavePseudo={savePseudo} lang={lang} />}
          </div>
        )}

        {!showAdmin && !accesBloque && tab !== "biodiversite" && tab !== "confidentialite" && tab !== "assistant" && (
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, background: "var(--c-surface)", borderTop: "1px solid var(--c-border)", display: "flex", padding: "8px 6px", borderRadius: "18px 18px 0 0", boxShadow: "0 -4px 16px rgba(0,0,0,0.04)" }}>
            {TABS.map(tabItem => {
              const IconT = tabItem.icon;
              const active = tab === tabItem.id;
              const navLabels = { accueil: t(lang, "nav_accueil"), carte: t(lang, "nav_carte"), arbre: t(lang, "nav_arbre") };
              return (
                <button key={tabItem.id} onClick={() => setTab(tabItem.id)} style={{ flex: 1, background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0" }}>
                  <div style={{ background: tabItem.cta ? "#B5451B" : (active ? "var(--c-surface-soft)" : "transparent"), borderRadius: "50%", width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <IconT size={17} color={tabItem.cta ? "#fff" : (active ? "var(--c-accent)" : "var(--c-text-muted)")} />
                  </div>
                  <span style={{ fontSize: 10, color: active ? "var(--c-accent)" : "var(--c-text-muted)", fontWeight: active ? 600 : 500 }}>{navLabels[tabItem.id] || tabItem.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

