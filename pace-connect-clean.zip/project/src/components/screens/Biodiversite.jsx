import { useRef, useState } from 'react';
import { IconCamera, IconPaw, IconPlus } from '../icons/index';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { t } from '../../i18n/index';
import { AFRICA_CENTER } from '../../lib/geo';
import { compressImage } from '../../lib/media';

export function Biodiversite({ observations, onAdd, onBack, lang }) {
  const [showForm, setShowForm] = useState(false);
  const [espece, setEspece] = useState("");
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);

  function handlePhoto(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = async () => setPhoto(await compressImage(reader.result));
    reader.readAsDataURL(f);
  }

  function submit() {
    if (!espece.trim()) return;
    setBusy(true);
    const finalize = (lat, lng) => {
      onAdd({ espece, description, photo, lat, lng }).finally(() => {
        setBusy(false); setEspece(""); setDescription(""); setPhoto(null); setShowForm(false);
      });
    };
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => finalize(pos.coords.latitude, pos.coords.longitude),
        () => finalize(AFRICA_CENTER[0], AFRICA_CENTER[1]),
        { timeout: 6000, enableHighAccuracy: true }
      );
    } else finalize(AFRICA_CENTER[0], AFRICA_CENTER[1]);
  }

  return (
    <Screen>
      <button onClick={onBack} style={{ background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12.5, cursor: "pointer", marginBottom: 10, padding: 0 }}>{t(lang, "retour")}</button>
      <SectionTitle sub={t(lang, "sub_biodiv2")}>{t(lang, "title_biodiversite")}</SectionTitle>

      {!showForm ? (
        <button onClick={() => setShowForm(true)} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "12px 0", borderRadius: 12, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer", marginBottom: 16 }}>
          <IconPlus size={16} /> {t(lang, "signaler_observation")}
        </button>
      ) : (
        <div style={{ background: "var(--c-surface)", borderRadius: 14, padding: 14, border: "1px solid var(--c-border)", marginBottom: 16 }}>
          <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} style={{ display: "none" }} />
          {photo ? (
            <img src={photo} style={{ width: "100%", borderRadius: 10, maxHeight: 130, objectFit: "cover", marginBottom: 10 }} />
          ) : (
            <button onClick={() => fileRef.current.click()} style={{ width: "100%", border: "1.5px dashed var(--c-text-faint)", borderRadius: 10, padding: 14, background: "var(--c-surface-dashed)", color: "var(--c-text-secondary)", cursor: "pointer", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 12 }}>
              <IconCamera size={16} /> {t(lang, "photo_espece")}
            </button>
          )}
          <input value={espece} onChange={e => setEspece(e.target.value)} placeholder={t(lang, "espece_placeholder")}
            style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
          <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} placeholder={t(lang, "remarques_placeholder")}
            style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10, boxSizing: "border-box", resize: "none", fontFamily: "Work Sans, sans-serif" }} />
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setShowForm(false)} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", fontSize: 13 }}>{t(lang, "annuler")}</button>
            <button onClick={submit} disabled={busy} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "none", background: "var(--c-accent)", color: "#fff", fontWeight: 600, cursor: "pointer", fontSize: 13 }}>{busy ? t(lang, "envoi_en_cours") : t(lang, "enregistrer")}</button>
          </div>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {observations.length === 0 && <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 20 }}>{t(lang, "aucune_observation_partagee")}</div>}
        {[...observations].reverse().map(o => (
          <div key={o.id} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 12, border: "1px solid var(--c-border)" }}>
            {o.photo_url && <img src={o.photo_url} style={{ width: "100%", maxHeight: 150, objectFit: "cover", borderRadius: 10, marginBottom: 8 }} />}
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
              <IconPaw size={14} color="var(--c-accent)" />
              <div style={{ fontWeight: 600, fontSize: 13 }}>{o.espece}</div>
            </div>
            {o.description && <div style={{ fontSize: 12, color: "var(--c-text-secondary)" }}>{o.description}</div>}
            <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 4 }}>{new Date(o.created_at).toLocaleDateString("fr-FR")}</div>
          </div>
        ))}
      </div>
    </Screen>
  );
}

