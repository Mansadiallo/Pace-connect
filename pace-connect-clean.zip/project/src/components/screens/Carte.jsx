import { useEffect, useMemo, useRef, useState } from 'react';
import React from 'react';
import L from 'leaflet';
import 'leaflet-draw';
import 'leaflet.markercluster';
import { IconAlert, IconCloudDownload, IconCloudRain, IconDownload, IconDroplet, IconEdit, IconFlame, IconGauge, IconGlobe, IconLayers, IconMapPin, IconMaximize, IconMinimize, IconPlay, IconRoute, IconSearch, IconShield, IconSprout, IconSquareStop, IconTarget, IconTrash, IconTree, IconWaves, IconWifi, IconWifiOff, IconX } from '../icons/index';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { StatCard } from '../ui/StatCard';
import { CATEGORIES, URGENCE, categorieLabel, urgenceLabel } from '../../constants/categories';
import { t } from '../../i18n/index';
import { DEVICE_ID } from '../../lib/device';
import { AFRICA_CENTER, formatCap, formatVitesse, gpsQualite, pointInPolygon } from '../../lib/geo';
import { downloadCSV, toCSV } from '../../lib/media';
import { clearCachedTiles, countCachedTiles, creerCoucheTuilesHorsLigne, getCachedTile, putCachedTile, tilesPourZone } from '../../lib/tileCache';

export function markerHtml(color, kind) {
  // kind: "pin" (signalement), "tree", ou "leaf" (biodiversité)
  if (kind === "tree") {
    return `<div style="width:30px;height:30px;border-radius:50%;background:#fff;border:2px solid ${color};display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,0.25)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 22v-7"/><path d="M9 9a3 3 0 1 1 6 0c0 2-2 3-3 3s-3-1-3-3z"/><path d="M6 13a4 4 0 1 1 8 0c0 2.2-2 4-4 4s-4-1.8-4-4z"/>
      </svg></div>`;
  }
  if (kind === "leaf") {
    return `<div style="width:30px;height:30px;border-radius:50%;background:#fff;border:2px solid ${color};display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,0.25)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>
      </svg></div>`;
  }
  return `<div style="width:30px;height:30px;border-radius:50% 50% 50% 0;background:${color};transform:rotate(-45deg);box-shadow:0 2px 6px rgba(0,0,0,0.25);border:2px solid #fff"></div>`;
}

// Regroupement des catégories de signalements en couches "Déchets" / "Pollution" /
// "Signalements" — la base de données a une seule table `signalements` avec un
// champ `categorie`, donc ces 3 couches filtrent la même source par catégorie
// plutôt que de venir de 3 tables séparées.


export const COUCHE_DECHETS_CATEGORIES = ["decharge", "dechets_dangereux"];


export const COUCHE_POLLUTION_CATEGORIES = ["pollution", "deversement", "pollution_air"];


export function coucheDeCategorie(catId) {
  if (COUCHE_DECHETS_CATEGORIES.includes(catId)) return "dechets";
  if (COUCHE_POLLUTION_CATEGORIES.includes(catId)) return "pollution";
  return "signalements";
}

// Point-dans-polygone (ray casting) — utilisé pour l'analyse de zone sélectionnée,
// sans dépendance supplémentaire (turf.js) puisque Leaflet.draw ne le fournit pas.


export function Carte({ signalements, arbres, observations, onAddSignalement, onAddArbre, onAddObservation, online, pendingQueueCount, onFlushQueue, lang }) {
  const mapElRef = useRef(null);
  const mapRef = useRef(null);
  const layerRef = useRef(null);
  const tileStandardRef = useRef(null);
  const tileSatelliteRef = useRef(null);
  const zonesLayerRef = useRef(null);
  const parcoursLayerRef = useRef(null);
  const [locating, setLocating] = useState(true);
  const [selected, setSelected] = useState(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [satellite, setSatellite] = useState(false);

  // Couches — toutes désactivées par défaut, seul le fond de carte est actif.
  const [layersOn, setLayersOn] = useState({ arbres: true, signalements: true, dechets: true, pollution: true, biodiversite: true });
  const [showLayers, setShowLayers] = useState(false);

  // Filtres intelligents combinables.
  const [filtreCategorie, setFiltreCategorie] = useState("");
  const [filtreStatut, setFiltreStatut] = useState("");
  const [filtreDepuis, setFiltreDepuis] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const filtresActifs = !!(filtreCategorie || filtreStatut || filtreDepuis);

  const [visibleCount, setVisibleCount] = useState({ arbres: 0, dechets: 0, pollution: 0, signalements: 0, biodiversite: 0 });

  // Outils d'analyse géographique.
  const drawnItemsRef = useRef(null);
  const drawControlRef = useRef(null);
  const [showTools, setShowTools] = useState(false);
  const [coordMode, setCoordMode] = useState(false);
  const [clickedCoord, setClickedCoord] = useState(null);
  const [measureResult, setMeasureResult] = useState(null); // { type: "distance"|"superficie", texte }
  const [zoneAnalysis, setZoneAnalysis] = useState(null); // { total, parType: {...}, items: [...] }
  const analysisDataRef = useRef({ signalements: [], arbres: [], observations: [], layersOn: {} });
  useEffect(() => { analysisDataRef.current = { signalements, arbres, observations, layersOn }; }, [signalements, arbres, observations, layersOn]);
  const coordModeRef = useRef(false);
  useEffect(() => { coordModeRef.current = coordMode; }, [coordMode]);
  const coordMarkerRef = useRef(null);

  // Sources environnementales externes. Seule "Climat" est une intégration
  // réelle et vérifiée (Open-Meteo, déjà utilisée ailleurs dans l'app, sans
  // clé requise). Les autres sont volontairement laissées "non connectées" :
  // je n'ai pas pu vérifier en conditions réelles d'URL de tuiles fiable pour
  // elles ici, et le cahier des charges interdit d'inventer des données
  // externes. Prêtes à être branchées dès qu'une source vérifiée existe —
  // voir EXTERNAL_LAYER_DEFS ci-dessous pour l'endroit où l'ajouter.
  const [climatMode, setClimatMode] = useState(false);
  const climatModeRef = useRef(false);
  useEffect(() => { climatModeRef.current = climatMode; }, [climatMode]);
  const [climatLoading, setClimatLoading] = useState(false);

  const userMarkerRef = useRef(null);
  const [locateError, setLocateError] = useState("");

  // ===== 1. GPS précis (panneau détaillé + suivi continu) =====
  const [showGps, setShowGps] = useState(false);
  const [gpsData, setGpsData] = useState(null); // { lat,lng,accuracy,altitude,altitudeAccuracy,speed,heading,timestamp }
  const gpsWatchIdRef = useRef(null);

  useEffect(() => {
    if (!showGps) {
      if (gpsWatchIdRef.current != null && navigator.geolocation) { navigator.geolocation.clearWatch(gpsWatchIdRef.current); gpsWatchIdRef.current = null; }
      return;
    }
    if (!navigator.geolocation) return;
    gpsWatchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const c = pos.coords;
        setGpsData({ lat: c.latitude, lng: c.longitude, accuracy: c.accuracy, altitude: c.altitude, altitudeAccuracy: c.altitudeAccuracy, speed: c.speed, heading: c.heading, timestamp: pos.timestamp });
      },
      () => {},
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
    );
    return () => { if (gpsWatchIdRef.current != null && navigator.geolocation) { navigator.geolocation.clearWatch(gpsWatchIdRef.current); gpsWatchIdRef.current = null; } };
  }, [showGps]);

  // ===== 2. Recherche (données PACE locales + lieux OpenStreetMap/Nominatim) =====
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchPlaceResults, setSearchPlaceResults] = useState([]);
  const searchLocalResults = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (q.length < 2) return [];
    const out = [];
    (arbres || []).filter(a => a.valide || a.device_id === DEVICE_ID).forEach(a => { if ((a.nom || "").toLowerCase().includes(q)) out.push({ kind: "arbre", label: a.nom, sub: t(lang, "legend_arbre_plante"), lat: a.lat, lng: a.lng, data: a }); });
    (signalements || []).filter(s => s.valide || s.device_id === DEVICE_ID).forEach(s => {
      const cat = CATEGORIES.find(c => c.id === s.categorie);
      const label = cat ? cat.label : s.categorie;
      if ((label || "").toLowerCase().includes(q) || (s.description || "").toLowerCase().includes(q)) out.push({ kind: "signalement", label, sub: s.date, lat: s.lat, lng: s.lng, data: s });
    });
    (observations || []).forEach(o => { if ((o.espece || "").toLowerCase().includes(q)) out.push({ kind: "observation", label: o.espece || t(lang, "observation_generique"), sub: t(lang, "layer_biodiversite"), lat: o.lat, lng: o.lng, data: o }); });
    return out.slice(0, 12);
  }, [searchQuery, arbres, signalements, observations]);

  useEffect(() => {
    const q = searchQuery.trim();
    if (q.length < 3) { setSearchPlaceResults([]); return; }
    setSearchLoading(true);
    const timer = setTimeout(() => {
      fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(q)}`)
        .then(r => r.ok ? r.json() : [])
        .then(list => setSearchPlaceResults((list || []).map(p => ({ kind: "lieu", label: p.display_name, lat: parseFloat(p.lat), lng: parseFloat(p.lon) }))))
        .catch(() => setSearchPlaceResults([]))
        .finally(() => setSearchLoading(false));
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  function allerVers(lat, lng, zoom = 16) {
    if (!mapRef.current || lat == null || lng == null) return;
    mapRef.current.setView([lat, lng], zoom);
    setShowSearch(false);
  }

  // ===== 4. Collecte terrain directement depuis la carte =====
  const [addMode, setAddMode] = useState(false);
  const addModeRef = useRef(false);
  useEffect(() => { addModeRef.current = addMode; }, [addMode]);
  const [addPoint, setAddPoint] = useState(null);
  const [addType, setAddType] = useState(null); // "signalement" | "arbre" | "observation" | "zone"
  const [addSaving, setAddSaving] = useState(false);
  const addPointMarkerRef = useRef(null);
  const [fCategorie, setFCategorie] = useState(CATEGORIES[0] ? CATEGORIES[0].id : "");
  const [fUrgence, setFUrgence] = useState("moyenne");
  const [fDescription, setFDescription] = useState("");
  const [fNom, setFNom] = useState("");
  const [fEspece, setFEspece] = useState("");
  const [fZoneNom, setFZoneNom] = useState("");

  function resetAddForm() {
    setAddType(null); setFCategorie(CATEGORIES[0] ? CATEGORIES[0].id : ""); setFUrgence("moyenne");
    setFDescription(""); setFNom(""); setFEspece(""); setFZoneNom("");
  }
  function annulerAjout() {
    setAddMode(false); setAddPoint(null); resetAddForm();
    if (addPointMarkerRef.current && mapRef.current) { mapRef.current.removeLayer(addPointMarkerRef.current); addPointMarkerRef.current = null; }
  }
  async function validerAjout() {
    if (!addPoint || !addType) return;
    const [lat, lng] = addPoint;
    setAddSaving(true);
    try {
      if (addType === "signalement" && onAddSignalement) {
        await onAddSignalement({ categorie: fCategorie, urgence: fUrgence, description: fDescription, photo: null, lat, lng });
      } else if (addType === "arbre" && onAddArbre) {
        await onAddArbre({ nom: fNom || t(lang, "type_arbre"), photo: null, lat, lng });
      } else if (addType === "observation" && onAddObservation) {
        await onAddObservation({ espece: fEspece || t(lang, "non_identifiee"), description: fDescription, photo: null, lat, lng });
      } else if (addType === "zone") {
        enregistrerZoneLocale({ nom: fZoneNom || t(lang, "zone_sans_nom"), type: "point", lat, lng, cree_le: new Date().toISOString() });
      }
      annulerAjout();
    } finally {
      setAddSaving(false);
    }
  }

  // ===== Zones (polygones) — persistées localement, prêtes pour la synchro serveur =====
  const [zonesLocales, setZonesLocales] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pace-zones-local") || "[]"); } catch { return []; }
  });
  const [showZones, setShowZones] = useState(true);
  function enregistrerZoneLocale(zone) {
    setZonesLocales(prev => {
      const next = [...prev, { ...zone, id: `zone-${Date.now()}` }];
      try { localStorage.setItem("pace-zones-local", JSON.stringify(next)); } catch {}
      return next;
    });
  }
  function supprimerZoneLocale(id) {
    setZonesLocales(prev => {
      const next = prev.filter(z => z.id !== id);
      try { localStorage.setItem("pace-zones-local", JSON.stringify(next)); } catch {}
      return next;
    });
  }

  // ===== Parcours GPS (tracé de terrain) =====
  const [parcoursRecording, setParcoursRecording] = useState(false);
  const [parcoursPoints, setParcoursPoints] = useState([]);
  const [parcoursStart, setParcoursStart] = useState(null);
  const [parcoursElapsed, setParcoursElapsed] = useState(0);
  const parcoursWatchIdRef = useRef(null);
  const parcoursPolylineRef = useRef(null);
  const [savedParcours, setSavedParcours] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pace-parcours-local") || "[]"); } catch { return []; }
  });
  const [showParcoursPanel, setShowParcoursPanel] = useState(false);

  function demarrerParcours() {
    if (!navigator.geolocation || !mapRef.current) return;
    setParcoursPoints([]);
    setParcoursStart(Date.now());
    setParcoursRecording(true);
    if (parcoursPolylineRef.current) { mapRef.current.removeLayer(parcoursPolylineRef.current); }
    parcoursPolylineRef.current = L.polyline([], { color: "var(--c-warning)", weight: 4 }).addTo(mapRef.current);
    parcoursWatchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const p = [pos.coords.latitude, pos.coords.longitude];
        setParcoursPoints(prev => {
          const next = [...prev, p];
          if (parcoursPolylineRef.current) parcoursPolylineRef.current.setLatLngs(next);
          return next;
        });
      },
      () => {},
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
    );
  }
  function arreterParcours(sauvegarder) {
    if (parcoursWatchIdRef.current != null && navigator.geolocation) navigator.geolocation.clearWatch(parcoursWatchIdRef.current);
    parcoursWatchIdRef.current = null;
    setParcoursRecording(false);
    if (sauvegarder && parcoursPoints.length > 1) {
      let dist = 0;
      for (let i = 1; i < parcoursPoints.length; i++) {
        dist += L.latLng(parcoursPoints[i - 1]).distanceTo(L.latLng(parcoursPoints[i]));
      }
      const parcours = {
        id: `parcours-${Date.now()}`, points: parcoursPoints, distance_m: Math.round(dist),
        duree_s: Math.round((Date.now() - parcoursStart) / 1000), date: new Date().toISOString(),
      };
      setSavedParcours(prev => {
        const next = [...prev, parcours];
        try { localStorage.setItem("pace-parcours-local", JSON.stringify(next)); } catch {}
        return next;
      });
    }
    if (!sauvegarder && parcoursPolylineRef.current && mapRef.current) { mapRef.current.removeLayer(parcoursPolylineRef.current); parcoursPolylineRef.current = null; }
  }
  function supprimerParcours(id) {
    setSavedParcours(prev => {
      const next = prev.filter(p => p.id !== id);
      try { localStorage.setItem("pace-parcours-local", JSON.stringify(next)); } catch {}
      return next;
    });
  }
  useEffect(() => {
    if (!parcoursRecording) return;
    const t = setInterval(() => setParcoursElapsed(Math.round((Date.now() - parcoursStart) / 1000)), 1000);
    return () => clearInterval(t);
  }, [parcoursRecording, parcoursStart]);
  function formatDuree(s) {
    const m = Math.floor(s / 60), sec = s % 60;
    return `${m}min ${String(sec).padStart(2, "0")}s`;
  }

  // ===== 5. Mode hors connexion — tuiles téléchargées à l'avance =====
  const [showOffline, setShowOffline] = useState(false);
  const [tilesCachedCount, setTilesCachedCount] = useState(0);
  const [offlineDownloading, setOfflineDownloading] = useState(false);
  const [offlineProgress, setOfflineProgress] = useState({ done: 0, total: 0 });
  const offlineCancelRef = useRef(false);

  useEffect(() => { if (showOffline) countCachedTiles().then(setTilesCachedCount); }, [showOffline]);

  async function telechargerZoneHorsLigne() {
    if (!mapRef.current) return;
    setOfflineDownloading(true);
    offlineCancelRef.current = false;
    const bounds = mapRef.current.getBounds();
    const zActuel = mapRef.current.getZoom();
    const zMin = Math.max(4, zActuel - 1);
    const zMax = Math.min(18, zActuel + 2); // zone + 2 niveaux de zoom pour naviguer une fois sur place
    const tuiles = tilesPourZone(bounds, zMin, zMax);
    setOfflineProgress({ done: 0, total: tuiles.length });
    const urlBase = satellite
      ? { tpl: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", id: "satellite", subs: null }
      : { tpl: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png", id: "osm", subs: "abcd" };
    let done = 0;
    for (const t of tuiles) {
      if (offlineCancelRef.current) break;
      const sub = urlBase.subs ? urlBase.subs[done % urlBase.subs.length] : "a";
      const url = urlBase.tpl.replace("{s}", sub).replace("{z}", t.z).replace("{x}", t.x).replace("{y}", t.y);
      const key = `${urlBase.id}/${t.z}/${t.x}/${t.y}`;
      try {
        const already = await getCachedTile(key);
        if (!already) {
          const res = await fetch(url);
          if (res.ok) { const blob = await res.blob(); await putCachedTile(key, blob); }
          // Petite pause entre les requêtes : téléchargement respectueux, pas en rafale.
          await new Promise(r => setTimeout(r, 40));
        }
      } catch { /* tuile ignorée, la synchro/tentative suivante pourra réussir */ }
      done++;
      if (done % 5 === 0 || done === tuiles.length) setOfflineProgress({ done, total: tuiles.length });
    }
    setOfflineDownloading(false);
    countCachedTiles().then(setTilesCachedCount);
  }
  function annulerTelechargement() { offlineCancelRef.current = true; }
  async function viderCacheHorsLigne() { await clearCachedTiles(); setTilesCachedCount(0); }
  function locateMe(mapInstance) {
    const map = mapInstance || mapRef.current;
    if (!map) return;
    if (!navigator.geolocation) { setLocateError(t(lang, "geoloc_non_supportee")); setLocating(false); return; }
    if (window.isSecureContext === false) { setLocateError(t(lang, "geoloc_contexte_securise")); setLocating(false); return; }
    setLocateError("");
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const latlng = [pos.coords.latitude, pos.coords.longitude];
        map.setView(latlng, 13);
        if (userMarkerRef.current) {
          userMarkerRef.current.setLatLng(latlng);
        } else {
          userMarkerRef.current = L.circleMarker(latlng, {
            radius: 8, color: "var(--c-sky)", fillColor: "var(--c-sky)", fillOpacity: 0.9, weight: 2,
          }).addTo(map).bindPopup(t(lang, "toi_ici"));
        }
        setLocating(false);
      },
      (err) => {
        setLocating(false);
        if (err.code === 1) setLocateError(t(lang, "geoloc_refusee"));
        else if (err.code === 2) setLocateError(t(lang, "geoloc_indisponible"));
        else setLocateError(t(lang, "geoloc_timeout"));
      },
      { timeout: 6000, enableHighAccuracy: true }
    );
  }

  function startDraw(type) {
    if (!mapRef.current) return;
    setCoordMode(false);
    setClickedCoord(null);
    if (type === "marker") new L.Draw.Marker(mapRef.current).enable();
    else if (type === "polyline") new L.Draw.Polyline(mapRef.current, { shapeOptions: { color: "var(--c-accent-dark)", weight: 3 } }).enable();
    else if (type === "polygon") new L.Draw.Polygon(mapRef.current, { shapeOptions: { color: "var(--c-accent-dark)", weight: 3 } }).enable();
  }
  function clearAnalyse() {
    if (drawnItemsRef.current) drawnItemsRef.current.clearLayers();
    if (coordMarkerRef.current && mapRef.current) { mapRef.current.removeLayer(coordMarkerRef.current); coordMarkerRef.current = null; }
    setMeasureResult(null);
    setZoneAnalysis(null);
    setClickedCoord(null);
    setCoordMode(false);
  }
  function exporterAnalyse() {
    if (!zoneAnalysis || !zoneAnalysis.items.length) return;
    const csv = toCSV(zoneAnalysis.items, [
      { key: "type", label: "Type" }, { key: "nom", label: "Nom / catégorie" }, { key: "date", label: "Date" },
      { key: "lat", label: "Latitude" }, { key: "lng", label: "Longitude" },
    ]);
    downloadCSV(`pace-analyse-zone-${Date.now()}.csv`, csv);
  }

  function toggleLayer(id) { setLayersOn(prev => ({ ...prev, [id]: !prev[id] })); }
  function resetFiltres() { setFiltreCategorie(""); setFiltreStatut(""); setFiltreDepuis(""); }

  function passeFiltrePeriode(dateIso) {
    if (!filtreDepuis || !dateIso) return true;
    return new Date(dateIso) >= new Date(filtreDepuis);
  }

  useEffect(() => {
    if (!mapRef.current) return;
    setTimeout(() => mapRef.current.invalidateSize(), 250);
  }, [fullscreen]);

  useEffect(() => {
    if (!tileStandardRef.current || !tileSatelliteRef.current) return;
    if (satellite) {
      mapRef.current.removeLayer(tileStandardRef.current);
      tileSatelliteRef.current.addTo(mapRef.current);
    } else {
      mapRef.current.removeLayer(tileSatelliteRef.current);
      tileStandardRef.current.addTo(mapRef.current);
    }
  }, [satellite]);

  useEffect(() => {
    if (mapRef.current || !mapElRef.current || typeof L === "undefined") return;
    const map = L.map(mapElRef.current, { zoomControl: true }).setView(AFRICA_CENTER, 4);
    // Tuiles servies via un cache IndexedDB local (section 5 — mode hors connexion) :
    // en ligne, elles sont téléchargées puis mises en cache automatiquement ;
    // hors ligne, les tuiles déjà visitées ou pré-téléchargées restent affichées.
    tileStandardRef.current = creerCoucheTuilesHorsLigne("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
      maxZoom: 19, id: "osm", subdomains: "abcd",
    }).addTo(map);
    tileSatelliteRef.current = creerCoucheTuilesHorsLigne("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
      attribution: "Tiles &copy; Esri", maxZoom: 19, id: "satellite",
    });
    // 8. Performance : regroupement des marqueurs (clustering) quand la librairie est
    // chargée, avec repli silencieux sur un simple groupe de calques sinon.
    layerRef.current = (typeof L.markerClusterGroup === "function")
      ? L.markerClusterGroup({ maxClusterRadius: 60, spiderfyOnMaxZoom: true, disableClusteringAtZoom: 17 }).addTo(map)
      : L.layerGroup().addTo(map);
    drawnItemsRef.current = new L.FeatureGroup().addTo(map);
    zonesLayerRef.current = L.layerGroup().addTo(map);
    parcoursLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    map.on("click", (e) => {
      if (addModeRef.current) {
        const p = [e.latlng.lat, e.latlng.lng];
        setAddPoint(p);
        if (addPointMarkerRef.current) map.removeLayer(addPointMarkerRef.current);
        addPointMarkerRef.current = L.circleMarker(e.latlng, { radius: 8, color: "var(--c-accent-dark)", fillColor: "var(--c-accent-dark)", fillOpacity: 0.9, weight: 2 }).addTo(map);
        return;
      }
      if (coordModeRef.current) {
        setClickedCoord([e.latlng.lat, e.latlng.lng]);
        if (coordMarkerRef.current) map.removeLayer(coordMarkerRef.current);
        coordMarkerRef.current = L.circleMarker(e.latlng, { radius: 7, color: "var(--c-warning)", fillColor: "var(--c-warning)", fillOpacity: 0.9, weight: 2 }).addTo(map);
      }
      if (climatModeRef.current) {
        setClimatLoading(true);
        const popup = L.popup().setLatLng(e.latlng).setContent(t(lang, "climat_chargement")).openOn(map);
        fetch(`https://api.open-meteo.com/v1/forecast?latitude=${e.latlng.lat}&longitude=${e.latlng.lng}&current=temperature_2m,precipitation,weather_code,wind_speed_10m&timezone=auto`)
          .then((res) => res.json())
          .then((data) => {
            const c = data.current;
            if (!c) { popup.setContent(t(lang, "climat_indisponible")); return; }
            popup.setContent(
              `<b>${t(lang, "climat_actuel_title")}</b><br/>${t(lang, "climat_temperature")} : ${c.temperature_2m}°C<br/>${t(lang, "climat_precipitations")} : ${c.precipitation} mm<br/>${t(lang, "climat_vent")} : ${c.wind_speed_10m} km/h`
            );
          })
          .catch(() => popup.setContent(t(lang, "climat_erreur_reseau")))
          .finally(() => setClimatLoading(false));
      }
    });

    map.on(L.Draw.Event.CREATED, (e) => {
      drawnItemsRef.current.clearLayers();
      const layer = e.layer;
      drawnItemsRef.current.addLayer(layer);

      if (e.layerType === "marker") {
        const p = layer.getLatLng();
        setMeasureResult({ type: "point", texte: `Point créé : ${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}` });
        setZoneAnalysis(null);
      } else if (e.layerType === "polyline") {
        const pts = layer.getLatLngs();
        let dist = 0;
        for (let i = 1; i < pts.length; i++) dist += pts[i - 1].distanceTo(pts[i]);
        const texte = dist >= 1000 ? `${(dist / 1000).toFixed(2)} km` : `${Math.round(dist)} m`;
        setMeasureResult({ type: "distance", texte: `Distance mesurée : ${texte}` });
        setZoneAnalysis(null);
      } else if (e.layerType === "polygon" || e.layerType === "rectangle") {
        const latlngs = layer.getLatLngs()[0];
        const areaM2 = L.GeometryUtil.geodesicArea(latlngs);
        const texte = areaM2 >= 10000 ? `${(areaM2 / 10000).toFixed(2)} ha` : `${Math.round(areaM2)} m²`;
        setMeasureResult({ type: "superficie", texte: `Superficie mesurée : ${texte}` });

        const poly = latlngs.map((p) => [p.lat, p.lng]);
        const d = analysisDataRef.current;
        const items = [];
        if (d.layersOn.arbres) (d.arbres || []).filter((a) => a.valide || a.device_id === DEVICE_ID).forEach((a) => { if (a.lat && a.lng && pointInPolygon([a.lat, a.lng], poly)) items.push({ type: "Arbre", nom: a.nom, date: a.date, lat: a.lat, lng: a.lng }); });
        if (d.layersOn.signalements || d.layersOn.dechets || d.layersOn.pollution) {
          (d.signalements || []).filter((s) => s.valide || s.device_id === DEVICE_ID).forEach((s) => {
            const couche = coucheDeCategorie(s.categorie);
            if (!d.layersOn[couche]) return;
            if (s.lat && s.lng && pointInPolygon([s.lat, s.lng], poly)) {
              const cat = CATEGORIES.find((c) => c.id === s.categorie);
              items.push({ type: cat ? cat.label : "Signalement", nom: cat ? cat.label : s.categorie, date: s.date, lat: s.lat, lng: s.lng });
            }
          });
        }
        if (d.layersOn.biodiversite) (d.observations || []).forEach((o) => { if (o.lat && o.lng && pointInPolygon([o.lat, o.lng], poly)) items.push({ type: "Biodiversité", nom: o.espece || "Observation", date: new Date(o.created_at).toLocaleDateString("fr-FR"), lat: o.lat, lng: o.lng }); });

        const parType = {};
        items.forEach((it) => { parType[it.type] = (parType[it.type] || 0) + 1; });
        setZoneAnalysis({ total: items.length, parType, items });
      }
    });

    if (navigator.geolocation) {
      locateMe(map);
    } else {
      setLocating(false);
    }

    setTimeout(() => map.invalidateSize(), 200);
  }, []);

  useEffect(() => {
    if (!layerRef.current) return;
    layerRef.current.clearLayers();
    const counts = { arbres: 0, dechets: 0, pollution: 0, signalements: 0, biodiversite: 0 };

    if (layersOn.arbres) {
      (arbres || []).filter((a) => a.valide || a.device_id === DEVICE_ID).forEach((a) => {
        if (!passeFiltrePeriode(a.planted_at)) return;
        counts.arbres++;
        const icon = L.divIcon({ html: markerHtml("var(--c-accent)", "tree"), className: "", iconSize: [30, 30], iconAnchor: [15, 30] });
        const photoHtml = a.photo_url ? `<img src="${a.photo_url}" style="width:100%;max-height:110px;object-fit:cover;border-radius:8px;margin-top:6px" />` : "";
        const pendingHtml = !a.valide ? `<div style="font-size:11px;color:#B5451B;margin-top:4px">⏳ ${t(lang, "en_attente_validation")}</div>` : "";
        L.marker([a.lat, a.lng], { icon, opacity: a.valide ? 1 : 0.6 }).addTo(layerRef.current)
          .on("click", () => setSelected({ type: "arbre", data: a }))
          .bindPopup(`<b>${a.nom}</b><br/>${t(lang, "plante_le")}${a.date}${photoHtml}${pendingHtml}`);
      });
    }

    if (layersOn.dechets || layersOn.pollution || layersOn.signalements) {
      (signalements || []).filter((s) => s.valide || s.device_id === DEVICE_ID).forEach((s) => {
        const couche = coucheDeCategorie(s.categorie);
        if (!layersOn[couche]) return;
        if (filtreCategorie && s.categorie !== filtreCategorie) return;
        if (filtreStatut && s.statut !== filtreStatut) return;
        if (!passeFiltrePeriode(s.created_at)) return;
        counts[couche]++;
        const u = URGENCE.find((x) => x.id === s.urgence);
        const color = u ? u.color : "#B5451B";
        const icon = L.divIcon({ html: markerHtml(color, "pin"), className: "", iconSize: [30, 30], iconAnchor: [15, 30] });
        const cat = CATEGORIES.find((c) => c.id === s.categorie);
        const photoHtml = s.photo_url ? `<img src="${s.photo_url}" style="width:100%;max-height:110px;object-fit:cover;border-radius:8px;margin-top:6px" />` : "";
        const pendingHtml = !s.valide ? `<div style="font-size:11px;color:#B5451B;margin-top:4px">⏳ ${t(lang, "en_attente_validation")}</div>` : "";
        L.marker([s.lat, s.lng], { icon, opacity: s.valide ? 1 : 0.6 }).addTo(layerRef.current)
          .on("click", () => setSelected({ type: "signalement", data: s }))
          .bindPopup(`<b>${cat ? cat.label : t(lang, "type_signalement")}</b><br/>${s.date}${photoHtml}${pendingHtml}`);
      });
    }

    if (layersOn.biodiversite) {
      (observations || []).forEach((o) => {
        if (!o.lat || !o.lng) return;
        if (!passeFiltrePeriode(o.created_at)) return;
        counts.biodiversite++;
        const icon = L.divIcon({ html: markerHtml("var(--c-sky)", "leaf"), className: "", iconSize: [30, 30], iconAnchor: [15, 30] });
        const photoHtml = o.photo_url ? `<img src="${o.photo_url}" style="width:100%;max-height:110px;object-fit:cover;border-radius:8px;margin-top:6px" />` : "";
        L.marker([o.lat, o.lng], { icon }).addTo(layerRef.current)
          .on("click", () => setSelected({ type: "observation", data: o }))
          .bindPopup(`<b>${o.espece || t(lang, "observation_generique")}</b><br/>${new Date(o.created_at).toLocaleDateString("fr-FR")}${photoHtml}`);
      });
    }

    setVisibleCount(counts);
  }, [signalements, arbres, observations, layersOn, filtreCategorie, filtreStatut, filtreDepuis]);

  // Rendu des zones locales et des parcours enregistrés (7. interaction avec les données PACE Connect).
  useEffect(() => {
    if (!zonesLayerRef.current) return;
    zonesLayerRef.current.clearLayers();
    if (!showZones) return;
    zonesLocales.forEach(z => {
      const icon = L.divIcon({ html: markerHtml("var(--c-warning)", "pin"), className: "", iconSize: [26, 26], iconAnchor: [13, 26] });
      L.marker([z.lat, z.lng], { icon }).addTo(zonesLayerRef.current).bindPopup(`<b>${z.nom}</b><br/>${t(lang, "zone_enregistree_localement")}`);
    });
  }, [zonesLocales, showZones]);

  useEffect(() => {
    if (!parcoursLayerRef.current) return;
    parcoursLayerRef.current.clearLayers();
    if (!showParcoursPanel) return;
    savedParcours.forEach(p => {
      L.polyline(p.points, { color: "var(--c-sky)", weight: 3, opacity: 0.8, dashArray: "6 4" }).addTo(parcoursLayerRef.current)
        .bindPopup(`<b>Parcours</b><br/>${(p.distance_m / 1000).toFixed(2)} km · ${formatDuree(p.duree_s)}`);
    });
  }, [savedParcours, showParcoursPanel]);

  const totalVisible = visibleCount.arbres + visibleCount.dechets + visibleCount.pollution + visibleCount.signalements + visibleCount.biodiversite;
  const aucuneCoucheActive = !layersOn.arbres && !layersOn.signalements && !layersOn.dechets && !layersOn.pollution && !layersOn.biodiversite;

  const LAYER_DEFS = [
    { id: "arbres", label: "Arbres", labelKey: "layer_arbres", icon: IconTree, color: "var(--c-accent)" },
    { id: "signalements", label: "Signalements (autres)", labelKey: "layer_signalements", icon: IconAlert, color: "#B5451B" },
    { id: "dechets", label: "Déchets", labelKey: "layer_dechets", icon: IconTrash, color: "#8A6318" },
    { id: "pollution", label: "Pollution", labelKey: "layer_pollution", icon: IconDroplet, color: "#2E6B8A" },
    { id: "biodiversite", label: "Biodiversité", labelKey: "layer_biodiversite", icon: IconSprout, color: "var(--c-sky)" },
  ];

  // Sources externes prévues par le cahier des charges mais pas encore
  // branchées à une donnée réelle vérifiable (voir commentaire plus haut).
  const EXTERNAL_LAYERS_NON_CONNECTEES = [
    { id: "forets", label: "Couverture forestière", icon: IconTree },
    { id: "aires_protegees", label: "Aires protégées", icon: IconShield },
    { id: "zones_humides", label: "Zones humides", icon: IconWaves },
    { id: "occupation_sols", label: "Occupation des sols", icon: IconGlobe },
    { id: "risques", label: "Risques (incendie / inondation)", icon: IconFlame },
  ];

  function DetailCard({ s }) {
    if (s.type === "signalement") {
      return (
        <>
          {s.data.photo_url && <img src={s.data.photo_url} style={{ width: "100%", maxHeight: 180, objectFit: "cover", borderRadius: 10, marginBottom: 8 }} />}
          <div style={{ fontWeight: 600, fontSize: 14 }}>{categorieLabel(lang, s.data.categorie)}</div>
          <div style={{ fontSize: 12, color: "var(--c-text-muted)", marginTop: 3 }}>{s.data.date}{s.data.statut ? ` · ${s.data.statut}` : ""}</div>
          <div style={{ fontSize: 13, color: "var(--c-text-secondary)", marginTop: 6 }}>{s.data.description || t(lang, "aucune_description")}</div>
        </>
      );
    }
    if (s.type === "observation") {
      return (
        <>
          {s.data.photo_url && <img src={s.data.photo_url} style={{ width: "100%", maxHeight: 180, objectFit: "cover", borderRadius: 10, marginBottom: 8 }} />}
          <div style={{ fontWeight: 600, fontSize: 14 }}>{s.data.espece || t(lang, "observation_biodiversite")}</div>
          <div style={{ fontSize: 12, color: "var(--c-text-muted)", marginTop: 3 }}>{new Date(s.data.created_at).toLocaleDateString("fr-FR")}</div>
          <div style={{ fontSize: 13, color: "var(--c-text-secondary)", marginTop: 6 }}>{s.data.description || t(lang, "aucune_description")}</div>
        </>
      );
    }
    return (
      <>
        {s.data.photo_url && <img src={s.data.photo_url} style={{ width: "100%", maxHeight: 180, objectFit: "cover", borderRadius: 10, marginBottom: 8 }} />}
        <div style={{ fontWeight: 600, fontSize: 14 }}>{s.data.nom}</div>
        <div style={{ fontSize: 12, color: "var(--c-text-muted)", marginTop: 3 }}>{t(lang, "plante_le")}{s.data.date}</div>
      </>
    );
  }

  function fermerTousLesPanneaux() {
    setShowLayers(false); setShowFilters(false); setShowTools(false);
    setShowSearch(false); setShowOffline(false); setShowParcoursPanel(false);
    if (addMode) annulerAjout();
  }
  function ouvrirPanneau(setter) { fermerTousLesPanneaux(); setter(true); }

  return (
    <Screen>
      <SectionTitle sub={t(lang, "sub_carte_intelligente")}>{t(lang, "titre_carte_intelligente")}</SectionTitle>

      {/* Statut réseau / synchronisation — visible en permanence (section 9 : Synchroniser). */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, fontSize: 11.5 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 9px", borderRadius: 20, background: online ? "rgba(22,163,74,0.12)" : "rgba(220,38,38,0.12)", color: online ? "#16a34a" : "#dc2626", fontWeight: 600 }}>
          {online ? <IconWifi size={12} /> : <IconWifiOff size={12} />} {online ? t(lang, "en_ligne") : t(lang, "hors_ligne")}
        </span>
        {pendingQueueCount > 0 && (
          <button onClick={() => onFlushQueue && onFlushQueue()} style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 9px", borderRadius: 20, border: "none", background: "var(--c-warning)", color: "#fff", fontWeight: 600, fontSize: 11.5, cursor: "pointer" }}>
            <IconCloudDownload size={12} /> {pendingQueueCount} {t(lang, "en_attente_synchro")}
          </button>
        )}
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <button onClick={() => showLayers ? setShowLayers(false) : ouvrirPanneau(setShowLayers)} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: showLayers ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: showLayers ? "var(--c-accent-dark)" : "var(--c-surface)", color: showLayers ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconLayers size={14} /> {t(lang, "couches_btn")} {!aucuneCoucheActive && `(${Object.values(layersOn).filter(Boolean).length})`}
        </button>
        <button onClick={() => showFilters ? setShowFilters(false) : ouvrirPanneau(setShowFilters)} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: filtresActifs ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: filtresActifs ? "var(--c-accent-dark)" : "var(--c-surface)", color: filtresActifs ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconTarget size={14} /> {t(lang, "filtres_btn")} {filtresActifs && "●"}
        </button>
        <button onClick={() => showTools ? setShowTools(false) : ouvrirPanneau(setShowTools)} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: showTools ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: showTools ? "var(--c-accent-dark)" : "var(--c-surface)", color: showTools ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconEdit size={14} /> {t(lang, "outils_btn")}
        </button>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        <button onClick={() => addMode ? annulerAjout() : ouvrirPanneau(() => setAddMode(true))} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: addMode ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: addMode ? "var(--c-accent-dark)" : "var(--c-surface)", color: addMode ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconMapPin size={14} /> {t(lang, "ajouter_btn")}
        </button>
        <button onClick={() => showSearch ? setShowSearch(false) : ouvrirPanneau(setShowSearch)} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: showSearch ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: showSearch ? "var(--c-accent-dark)" : "var(--c-surface)", color: showSearch ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconSearch size={14} /> {t(lang, "rechercher_btn")}
        </button>
        <button onClick={() => showOffline ? setShowOffline(false) : ouvrirPanneau(setShowOffline)} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: showOffline ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: showOffline ? "var(--c-accent-dark)" : "var(--c-surface)", color: showOffline ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconCloudDownload size={14} /> {t(lang, "hors_ligne")}
        </button>
        <button onClick={() => showParcoursPanel ? setShowParcoursPanel(false) : ouvrirPanneau(setShowParcoursPanel)} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 10,
          border: showParcoursPanel ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
          background: showParcoursPanel ? "var(--c-accent-dark)" : "var(--c-surface)", color: showParcoursPanel ? "#fff" : "var(--c-text)",
          fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          <IconRoute size={14} /> {t(lang, "parcours_btn")}
        </button>
      </div>

      {addMode && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-accent-dark)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          {!addPoint && (
            <div style={{ fontSize: 12, color: "var(--c-text-secondary)" }}>{t(lang, "toucher_carte_ajouter")}</div>
          )}
          {addPoint && !addType && (
            <>
              <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>
                {t(lang, "point_choisi_prefix")}{addPoint[0].toFixed(5)}, {addPoint[1].toFixed(5)}{t(lang, "point_choisi_suffix")}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                <button onClick={() => setAddType("signalement")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>🚩 {t(lang, "type_signalement")}</button>
                <button onClick={() => setAddType("arbre")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>🌳 {t(lang, "type_arbre")}</button>
                <button onClick={() => setAddType("observation")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>🦋 {t(lang, "type_observation")}</button>
                <button onClick={() => setAddType("zone")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>⬠ {t(lang, "type_zone")}</button>
              </div>
            </>
          )}
          {addPoint && addType === "signalement" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <select value={fCategorie} onChange={e => setFCategorie(e.target.value)} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }}>
                {CATEGORIES.map(c => <option key={c.id} value={c.id}>{categorieLabel(lang, c.id)}</option>)}
              </select>
              <select value={fUrgence} onChange={e => setFUrgence(e.target.value)} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }}>
                {URGENCE.map(u => <option key={u.id} value={u.id}>{urgenceLabel(lang, u.id)}</option>)}
              </select>
              <textarea value={fDescription} onChange={e => setFDescription(e.target.value)} placeholder={t(lang, "description_optionnel")} rows={2} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)", resize: "vertical" }} />
            </div>
          )}
          {addPoint && addType === "arbre" && (
            <input value={fNom} onChange={e => setFNom(e.target.value)} placeholder={t(lang, "essence_nom_arbre")} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }} />
          )}
          {addPoint && addType === "observation" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <input value={fEspece} onChange={e => setFEspece(e.target.value)} placeholder={t(lang, "espece_observee_placeholder")} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }} />
              <textarea value={fDescription} onChange={e => setFDescription(e.target.value)} placeholder={t(lang, "description_optionnel")} rows={2} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)", resize: "vertical" }} />
            </div>
          )}
          {addPoint && addType === "zone" && (
            <input value={fZoneNom} onChange={e => setFZoneNom(e.target.value)} placeholder={t(lang, "nom_zone_placeholder")} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }} />
          )}
          {addPoint && addType && (
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <button onClick={() => setAddType(null)} style={{ flex: 1, padding: "8px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>{t(lang, "retour_btn")}</button>
              <button onClick={validerAjout} disabled={addSaving} style={{ flex: 2, padding: "8px 0", borderRadius: 8, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontSize: 12, fontWeight: 600, cursor: addSaving ? "default" : "pointer", opacity: addSaving ? 0.7 : 1 }}>{addSaving ? t(lang, "enregistrement_encours") : t(lang, "enregistrer")}</button>
            </div>
          )}
          <button onClick={annulerAjout} style={{ marginTop: 8, width: "100%", padding: "6px 0", borderRadius: 8, border: "none", background: "none", color: "var(--c-text-muted)", fontSize: 11, cursor: "pointer" }}>{t(lang, "annuler_ajout")}</button>
        </div>
      )}

      {showSearch && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder={t(lang, "rechercher_placeholder")} style={{ width: "100%", padding: "9px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)", marginBottom: 8 }} autoFocus />
          {searchLocalResults.length > 0 && (
            <div style={{ marginBottom: 6 }}>
              <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--c-text-muted)", margin: "4px 0" }}>{t(lang, "donnees_pace")}</div>
              {searchLocalResults.map((r, i) => (
                <div key={i} onClick={() => allerVers(r.lat, r.lng)} style={{ padding: "7px 4px", fontSize: 12.5, color: "var(--c-text)", cursor: "pointer", borderBottom: "1px solid var(--c-border)" }}>{r.label} <span style={{ color: "var(--c-text-muted)", fontSize: 11 }}>· {r.sub}</span></div>
              ))}
            </div>
          )}
          {searchPlaceResults.length > 0 && (
            <div>
              <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--c-text-muted)", margin: "4px 0" }}>{t(lang, "lieux_osm")}</div>
              {searchPlaceResults.map((r, i) => (
                <div key={i} onClick={() => allerVers(r.lat, r.lng, 14)} style={{ padding: "7px 4px", fontSize: 12.5, color: "var(--c-text)", cursor: "pointer", borderBottom: "1px solid var(--c-border)" }}>{r.label}</div>
              ))}
            </div>
          )}
          {searchLoading && <div style={{ fontSize: 11.5, color: "var(--c-text-muted)" }}>{t(lang, "recherche_encours")}</div>}
          {!searchLoading && searchQuery.trim().length >= 2 && searchLocalResults.length === 0 && searchPlaceResults.length === 0 && (
            <div style={{ fontSize: 11.5, color: "var(--c-text-muted)" }}>{t(lang, "aucun_resultat")}</div>
          )}
        </div>
      )}

      {showOffline && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Carte hors connexion</div>
          <div style={{ fontSize: 11.5, color: "var(--c-text-muted)", marginBottom: 10, lineHeight: 1.5 }}>
            Télécharge la zone actuellement affichée pour pouvoir naviguer, mesurer et collecter des données sans réseau. Les données collectées hors ligne sont conservées et envoyées automatiquement dès que la connexion revient.
          </div>
          <div style={{ fontSize: 12, marginBottom: 10 }}>{tilesCachedCount} tuile{tilesCachedCount > 1 ? "s" : ""} déjà en cache sur cet appareil.</div>
          {offlineDownloading ? (
            <>
              <div style={{ height: 8, borderRadius: 4, background: "var(--c-bg)", overflow: "hidden", marginBottom: 6 }}>
                <div style={{ height: "100%", width: `${offlineProgress.total ? (offlineProgress.done / offlineProgress.total) * 100 : 0}%`, background: "var(--c-accent-dark)" }} />
              </div>
              <div style={{ fontSize: 11.5, color: "var(--c-text-muted)", marginBottom: 8 }}>{offlineProgress.done} / {offlineProgress.total} tuiles téléchargées</div>
              <button onClick={annulerTelechargement} style={{ width: "100%", padding: "8px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Arrêter le téléchargement</button>
            </>
          ) : (
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={telechargerZoneHorsLigne} style={{ flex: 2, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 8, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                <IconCloudDownload size={14} /> Télécharger cette zone
              </button>
              <button onClick={viderCacheHorsLigne} style={{ flex: 1, padding: "9px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Vider</button>
            </div>
          )}
        </div>
      )}

      {showParcoursPanel && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Parcours GPS de terrain</div>
          {parcoursRecording ? (
            <>
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--c-accent-dark)", marginBottom: 8 }}>⏺ Enregistrement… {formatDuree(parcoursElapsed)} · {parcoursPoints.length} points</div>
              <button onClick={() => arreterParcours(true)} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 8, border: "none", background: "#dc2626", color: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                <IconSquareStop size={13} /> Arrêter et enregistrer
              </button>
            </>
          ) : (
            <button onClick={demarrerParcours} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 0", borderRadius: 8, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer", marginBottom: 10 }}>
              <IconPlay size={13} /> Démarrer un parcours
            </button>
          )}
          {savedParcours.length > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--c-text-muted)", marginBottom: 6 }}>Parcours enregistrés</div>
              {savedParcours.map(p => (
                <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: "1px solid var(--c-border)" }}>
                  <IconRoute size={13} color="var(--c-sky)" />
                  <span style={{ fontSize: 12, flex: 1 }}>{(p.distance_m / 1000).toFixed(2)} km · {formatDuree(p.duree_s)}</span>
                  <button onClick={() => supprimerParcours(p.id)} style={{ background: "none", border: "none", color: "var(--c-text-muted)", cursor: "pointer" }}><IconX size={13} /></button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {showTools && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Outils d'analyse géographique</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 10 }}>
            <button onClick={() => { setCoordMode(!coordMode); setClimatMode(false); setClickedCoord(null); }} style={{ padding: "8px 6px", borderRadius: 8, border: coordMode ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)", background: coordMode ? "var(--c-accent-dark)" : "var(--c-bg)", color: coordMode ? "#fff" : "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>📍 Coordonnées GPS</button>
            <button onClick={() => startDraw("marker")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>📌 Créer un point</button>
            <button onClick={() => startDraw("polyline")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>📏 Mesurer une distance</button>
            <button onClick={() => startDraw("polygon")} style={{ padding: "8px 6px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-bg)", color: "var(--c-text)", fontSize: 11.5, fontWeight: 600, cursor: "pointer" }}>⬠ Zone / superficie</button>
          </div>
          <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginBottom: 8, lineHeight: 1.5 }}>
            "Zone / superficie" dessine un polygone : calcule sa surface et analyse automatiquement les données des couches actives à l'intérieur.
          </div>

          {clickedCoord && (
            <div style={{ background: "var(--c-surface-soft)", borderRadius: 8, padding: 8, fontSize: 12, marginBottom: 8 }}>
              Coordonnées : {clickedCoord[0].toFixed(5)}, {clickedCoord[1].toFixed(5)}
            </div>
          )}
          {measureResult && (
            <div style={{ background: "var(--c-surface-soft)", borderRadius: 8, padding: 8, fontSize: 12, marginBottom: 8 }}>
              {measureResult.texte}
            </div>
          )}
          {zoneAnalysis && (
            <div style={{ background: "var(--c-surface-soft)", borderRadius: 8, padding: 10, marginBottom: 8 }}>
              <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 4 }}>{zoneAnalysis.total} donnée{zoneAnalysis.total > 1 ? "s" : ""} dans la zone</div>
              {Object.entries(zoneAnalysis.parType).map(([t, n]) => (
                <div key={t} style={{ fontSize: 11.5, color: "var(--c-text-secondary)" }}>{t} : {n}</div>
              ))}
              {zoneAnalysis.total === 0 && <div style={{ fontSize: 11.5, color: "var(--c-text-muted)" }}>Aucune donnée des couches actives dans cette zone.</div>}
            </div>
          )}
          <div style={{ display: "flex", gap: 8 }}>
            {(measureResult || zoneAnalysis || clickedCoord) && (
              <button onClick={clearAnalyse} style={{ flex: 1, padding: "8px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Effacer</button>
            )}
            {zoneAnalysis && zoneAnalysis.total > 0 && (
              <button onClick={exporterAnalyse} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "8px 0", borderRadius: 8, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                <IconDownload size={13} /> Exporter
              </button>
            )}
          </div>
        </div>
      )}

      {showLayers && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>{t(lang, "donnees_pace")}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {LAYER_DEFS.map(l => (
              <label key={l.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 4px", cursor: "pointer" }}>
                <input type="checkbox" checked={layersOn[l.id]} onChange={() => toggleLayer(l.id)} style={{ width: 16, height: 16, accentColor: "var(--c-accent-dark)" }} />
                <l.icon size={14} color={l.color} />
                <span style={{ fontSize: 12.5, color: "var(--c-text)" }}>{t(lang, l.labelKey)}</span>
                <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--c-text-muted)" }}>{visibleCount[l.id]}</span>
              </label>
            ))}
          </div>
          <label style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 4px", cursor: "pointer" }}>
            <input type="checkbox" checked={showZones} onChange={() => setShowZones(!showZones)} style={{ width: 16, height: 16, accentColor: "var(--c-accent-dark)" }} />
            <IconMapPin size={14} color="var(--c-warning)" />
            <span style={{ fontSize: 12.5, color: "var(--c-text)" }}>{t(lang, "zones_enregistrees_local")}</span>
            <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--c-text-muted)" }}>{zonesLocales.length}</span>
          </label>
          <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 10, lineHeight: 1.5 }}>
            {t(lang, "projets_suivi_admin")}
          </div>

          <div style={{ height: 1, background: "var(--c-border)", margin: "12px 0" }} />

          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Sources environnementales externes</div>
          <label style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 4px", cursor: "pointer" }}>
            <input type="checkbox" checked={climatMode} onChange={() => { setClimatMode(!climatMode); setCoordMode(false); setClickedCoord(null); }} style={{ width: 16, height: 16, accentColor: "var(--c-accent-dark)" }} />
            <IconCloudRain size={14} color="var(--c-sky)" />
            <span style={{ fontSize: 12.5, color: "var(--c-text)" }}>Climat (Open-Meteo)</span>
            {climatLoading && <span style={{ marginLeft: "auto", fontSize: 10.5, color: "var(--c-text-muted)" }}>…</span>}
          </label>
          {climatMode && (
            <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", padding: "2px 4px 6px", lineHeight: 1.5 }}>
              Touche n'importe où sur la carte pour voir la météo actuelle à cet endroit.
            </div>
          )}
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 4px", opacity: 0.5 }}>
            <IconLayers size={14} color="var(--c-text-muted)" />
            <span style={{ fontSize: 12.5, color: "var(--c-text-muted)" }}>Imagerie satellite</span>
            <span style={{ marginLeft: "auto", fontSize: 9.5, fontWeight: 700, color: "var(--c-accent-dark)" }}>via le bouton dédié ↗</span>
          </div>
          {EXTERNAL_LAYERS_NON_CONNECTEES.map(l => (
            <div key={l.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 4px", opacity: 0.45 }}>
              <l.icon size={14} color="var(--c-text-muted)" />
              <span style={{ fontSize: 12.5, color: "var(--c-text-muted)" }}>{l.label}</span>
              <span style={{ marginLeft: "auto", fontSize: 9.5, fontWeight: 700, color: "var(--c-text-faint)" }}>Non connecté</span>
            </div>
          ))}
          <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 8, lineHeight: 1.5 }}>
            Ces sources ne sont pas encore branchées à une donnée réelle vérifiée — elles apparaissent pour montrer où elles s'intégreront, sans rien afficher de fictif.
          </div>
        </div>
      )}

      {showFilters && (
        <div style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 14, padding: 12, marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>{t(lang, "filtres_titre")}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <select value={filtreCategorie} onChange={e => setFiltreCategorie(e.target.value)} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }}>
              <option value="">{t(lang, "toutes_categories")}</option>
              {CATEGORIES.map(c => <option key={c.id} value={c.id}>{categorieLabel(lang, c.id)}</option>)}
            </select>
            <select value={filtreStatut} onChange={e => setFiltreStatut(e.target.value)} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }}>
              <option value="">{t(lang, "tous_statuts")}</option>
              <option value="resolu">{t(lang, "resolu")}</option>
              <option value="en_cours">{t(lang, "statut_en_cours")}</option>
              <option value="en_attente">{t(lang, "en_attente")}</option>
            </select>
            <div>
              <label style={{ fontSize: 11, color: "var(--c-text-muted)", display: "block", marginBottom: 4 }}>{t(lang, "depuis_le")}</label>
              <input type="date" value={filtreDepuis} onChange={e => setFiltreDepuis(e.target.value)} style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, background: "var(--c-bg)", color: "var(--c-text)" }} />
            </div>
            {filtresActifs && (
              <button onClick={resetFiltres} style={{ padding: "8px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>{t(lang, "reinitialiser_filtres")}</button>
            )}
          </div>
        </div>
      )}

      <div style={fullscreen
        ? { position: "fixed", inset: 0, zIndex: 9999, background: "#000" }
        : { position: "relative" }}>
        <div ref={mapElRef} style={fullscreen
          ? { width: "100vw", height: "100vh" }
          : { width: "100%", height: 360, borderRadius: 16, overflow: "hidden", border: "1px solid var(--c-border)" }} />

        <button onClick={() => setFullscreen(!fullscreen)} aria-label={fullscreen ? t(lang, "quitter_plein_ecran") : t(lang, "plein_ecran")} style={{
          position: "absolute", top: fullscreen ? 16 : 10, right: fullscreen ? 16 : 10,
          background: "var(--c-surface)", border: "none", borderRadius: fullscreen ? "50%" : 10,
          width: fullscreen ? 42 : 40, height: fullscreen ? 42 : 40, display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 2px 8px rgba(0,0,0,0.25)", cursor: "pointer", zIndex: 10000 }}>
          {fullscreen ? <IconMinimize size={18} color="var(--c-accent-dark)" /> : <IconMaximize size={16} color="var(--c-accent-dark)" />}
        </button>

        <button onClick={() => setSatellite(!satellite)} aria-label={t(lang, "vue_satellite")} aria-pressed={satellite} style={{
          position: "absolute", top: fullscreen ? 66 : 56, right: fullscreen ? 16 : 10,
          background: satellite ? "var(--c-accent-dark)" : "var(--c-surface)", border: "none", borderRadius: fullscreen ? "50%" : 10,
          width: fullscreen ? 42 : 40, height: fullscreen ? 42 : 40, display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 2px 8px rgba(0,0,0,0.25)", cursor: "pointer", zIndex: 10000 }} title={t(lang, "vue_satellite")}>
          <IconLayers size={fullscreen ? 18 : 16} color={satellite ? "#fff" : "var(--c-accent-dark)"} />
        </button>

        <button onClick={() => locateMe()} aria-label={t(lang, "me_geolocaliser")} disabled={locating} style={{
          position: "absolute", top: fullscreen ? 116 : 102, right: fullscreen ? 16 : 10,
          background: "var(--c-surface)", border: "none", borderRadius: fullscreen ? "50%" : 10,
          width: fullscreen ? 42 : 40, height: fullscreen ? 42 : 40, display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 2px 8px rgba(0,0,0,0.25)", cursor: locating ? "default" : "pointer", zIndex: 10000, opacity: locating ? 0.6 : 1 }} title={t(lang, "me_geolocaliser")}>
          <IconTarget size={fullscreen ? 18 : 16} color="var(--c-accent-dark)" />
        </button>

        <button onClick={() => setShowGps(!showGps)} aria-label={t(lang, "gps_detaille")} aria-pressed={showGps} style={{
          position: "absolute", top: fullscreen ? 166 : 148, right: fullscreen ? 16 : 10,
          background: showGps ? "var(--c-accent-dark)" : "var(--c-surface)", border: "none", borderRadius: fullscreen ? "50%" : 10,
          width: fullscreen ? 42 : 40, height: fullscreen ? 42 : 40, display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 2px 8px rgba(0,0,0,0.25)", cursor: "pointer", zIndex: 10000 }} title={t(lang, "gps_detaille")}>
          <IconGauge size={fullscreen ? 18 : 16} color={showGps ? "#fff" : "var(--c-accent-dark)"} />
        </button>

        {showGps && (
          <div style={{ position: "absolute", top: fullscreen ? 18 : 10, right: fullscreen ? 66 : 56, background: "var(--c-surface)", borderRadius: 12, padding: "10px 12px", fontSize: 11.5, color: "var(--c-text)", boxShadow: "0 2px 10px rgba(0,0,0,0.25)", zIndex: 10000, minWidth: 180 }}>
            {!gpsData ? (
              <div style={{ color: "var(--c-text-muted)" }}>{t(lang, "gps_recherche_signal")}</div>
            ) : (
              <>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
                  <span style={{ width: 8, height: 8, borderRadius: "50%", background: gpsQualite(gpsData.accuracy).couleur, display: "inline-block" }} />
                  <b>{t(lang, "gps_precision_label")} {gpsQualite(gpsData.accuracy).label.toLowerCase()}</b>
                </div>
                <div>{t(lang, "gps_lat_label")} : {gpsData.lat.toFixed(6)}</div>
                <div>{t(lang, "gps_lng_label")} : {gpsData.lng.toFixed(6)}</div>
                <div>{t(lang, "gps_precision_label")} : ±{gpsData.accuracy != null ? Math.round(gpsData.accuracy) : "?"} m</div>
                <div>{t(lang, "gps_altitude_label")} : {gpsData.altitude != null ? Math.round(gpsData.altitude) + " m" : "—"}</div>
                <div>{t(lang, "gps_vitesse_label")} : {formatVitesse(gpsData.speed)}</div>
                <div>{t(lang, "gps_cap_label")} : {formatCap(gpsData.heading)}</div>
                <div style={{ marginTop: 4, color: "var(--c-text-muted)", fontSize: 10.5 }}>{new Date(gpsData.timestamp).toLocaleTimeString("fr-FR")}</div>
              </>
            )}
          </div>
        )}

        {locating && (
          <div style={{ position: "absolute", top: fullscreen ? 18 : 10, left: fullscreen ? 16 : 10, background: "var(--c-surface)", borderRadius: 20, padding: "5px 12px", fontSize: 11.5, color: "var(--c-text-secondary)", boxShadow: "0 2px 6px rgba(0,0,0,0.15)", zIndex: 10000 }}>
            {t(lang, "geoloc_en_cours")}
          </div>
        )}

        {locateError && !locating && (
          <div style={{ position: "absolute", bottom: fullscreen ? 16 : 10, left: fullscreen ? 16 : 10, right: fullscreen ? 16 : 10, background: "#B5451B", color: "#fff", borderRadius: 10, padding: "9px 12px", fontSize: 11.5, boxShadow: "0 2px 8px rgba(0,0,0,0.25)", zIndex: 10000, display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ flex: 1 }}>{locateError}</span>
            <button onClick={() => setLocateError("")} style={{ background: "none", border: "none", color: "#fff", fontSize: 14, cursor: "pointer", padding: 0, lineHeight: 1 }}>✕</button>
          </div>
        )}

        {aucuneCoucheActive && !locating && (
          <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "var(--c-surface)", borderRadius: 14, padding: "12px 16px", fontSize: 12, color: "var(--c-text-secondary)", boxShadow: "0 2px 10px rgba(0,0,0,0.15)", zIndex: 9998, textAlign: "center", maxWidth: 220 }}>
            {t(lang, "aucune_couche_active")}
          </div>
        )}

        {selected && fullscreen && (
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, background: "var(--c-surface)", borderRadius: "16px 16px 0 0", padding: 16, maxHeight: "42%", overflowY: "auto", boxShadow: "0 -4px 20px rgba(0,0,0,0.25)", zIndex: 10000 }}>
            <DetailCard s={selected} />
          </div>
        )}
      </div>

      {!fullscreen && (
        <>
          <div style={{ display: "flex", gap: 14, marginTop: 12, fontSize: 11.5, color: "var(--c-text-secondary)", flexWrap: "wrap" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 10, height: 10, borderRadius: "50% 50% 50% 0", background: "#B5451B", transform: "rotate(-45deg)", display: "inline-block" }}></span> {t(lang, "type_signalement")}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}><IconTree size={13} color="var(--c-accent)" /> {t(lang, "legend_arbre_plante")}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}><IconSprout size={13} color="var(--c-sky)" /> {t(lang, "layer_biodiversite")}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 10, height: 10, borderRadius: "50%", background: "var(--c-sky)", display: "inline-block" }}></span> {t(lang, "legend_toi")}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}><IconMapPin size={13} color="var(--c-warning)" /> {t(lang, "type_zone")}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 14, height: 2, background: "var(--c-sky)", display: "inline-block" }}></span> {t(lang, "parcours_btn")}</div>
          </div>

          <div style={{ fontFamily: "Fraunces, serif", fontSize: 14.5, fontWeight: 600, color: "var(--c-accent-dark)", marginTop: 18, marginBottom: 10 }}>{t(lang, "tableau_bord_zone")}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: 8 }}>
            <StatCard label={t(lang, "stat_donnees_affichees")} value={totalVisible} unit="" accent="var(--c-accent-dark)" />
            <StatCard label={t(lang, "layer_arbres")} value={visibleCount.arbres} unit="" accent="var(--c-accent)" />
            <StatCard label={t(lang, "stat_signalements")} value={visibleCount.dechets + visibleCount.pollution + visibleCount.signalements} unit="" accent="#B5451B" />
            <StatCard label={t(lang, "layer_biodiversite")} value={visibleCount.biodiversite} unit="" accent="var(--c-sky)" />
          </div>
          <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 6, lineHeight: 1.5 }}>
            {t(lang, "note_reboisement")}
          </div>

          {selected && (
            <div style={{ marginTop: 14, background: "var(--c-surface)", borderRadius: 14, padding: 14, border: "1px solid var(--c-border)" }}>
              <DetailCard s={selected} />
            </div>
          )}
        </>
      )}
    </Screen>
  );
}

