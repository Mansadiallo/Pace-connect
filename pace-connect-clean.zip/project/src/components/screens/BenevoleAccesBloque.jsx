import { IconAlert, IconClock } from '../icons/index';

export function BenevoleAccesBloque({ statut }) {
  const infos = {
    en_attente: {
      icon: <IconClock size={30} color="var(--c-warning)" />,
      titre: "Inscription en cours de validation",
      texte: "Ton inscription comme bénévole a bien été reçue. L'accès à PACE Connect s'ouvrira automatiquement dès qu'un administrateur du Centre de contrôle PACE aura validé ton compte.",
    },
    suspendu: {
      icon: <IconAlert size={30} color="#B5451B" />,
      titre: "Accès suspendu",
      texte: "Ton accès bénévole à PACE Connect a été suspendu par un administrateur. Contacte l'équipe PACE si tu penses qu'il s'agit d'une erreur.",
    },
    rejete: {
      icon: <IconAlert size={30} color="var(--c-text-muted)" />,
      titre: "Demande non retenue",
      texte: "Ta demande d'inscription comme bénévole n'a pas été validée par l'équipe PACE. Contacte l'équipe PACE pour plus d'informations.",
    },
  };
  const info = infos[statut] || infos.en_attente;
  return (
    <div style={{ padding: "60px 24px", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
      <div style={{ background: "var(--c-surface-soft)", borderRadius: "50%", width: 64, height: 64, display: "flex", alignItems: "center", justifyContent: "center" }}>
        {info.icon}
      </div>
      <div style={{ fontFamily: "Fraunces, serif", fontSize: 17, fontWeight: 600, color: "var(--c-text)" }}>{info.titre}</div>
      <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", lineHeight: 1.6, maxWidth: 320 }}>{info.texte}</div>
    </div>
  );
}

