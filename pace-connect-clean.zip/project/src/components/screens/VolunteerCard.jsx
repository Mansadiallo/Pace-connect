import { useState } from 'react';
import { IconCheck, IconUsers } from '../icons/index';
import { t } from '../../i18n/index';
import { DEVICE_ID } from '../../lib/device';
import { supabase } from '../../lib/supabaseClient';

export const PAYS_INDICATIFS = [
  // Afrique
  { region: "Afrique", pays: "Afrique du Sud", indicatif: "+27" },
  { region: "Afrique", pays: "Algérie", indicatif: "+213" },
  { region: "Afrique", pays: "Angola", indicatif: "+244" },
  { region: "Afrique", pays: "Bénin", indicatif: "+229" },
  { region: "Afrique", pays: "Botswana", indicatif: "+267" },
  { region: "Afrique", pays: "Burkina Faso", indicatif: "+226" },
  { region: "Afrique", pays: "Burundi", indicatif: "+257" },
  { region: "Afrique", pays: "Cameroun", indicatif: "+237" },
  { region: "Afrique", pays: "Cap-Vert", indicatif: "+238" },
  { region: "Afrique", pays: "Comores", indicatif: "+269" },
  { region: "Afrique", pays: "Congo-Brazzaville", indicatif: "+242" },
  { region: "Afrique", pays: "Côte d'Ivoire", indicatif: "+225" },
  { region: "Afrique", pays: "Djibouti", indicatif: "+253" },
  { region: "Afrique", pays: "Égypte", indicatif: "+20" },
  { region: "Afrique", pays: "Érythrée", indicatif: "+291" },
  { region: "Afrique", pays: "Eswatini", indicatif: "+268" },
  { region: "Afrique", pays: "Éthiopie", indicatif: "+251" },
  { region: "Afrique", pays: "Gabon", indicatif: "+241" },
  { region: "Afrique", pays: "Gambie", indicatif: "+220" },
  { region: "Afrique", pays: "Ghana", indicatif: "+233" },
  { region: "Afrique", pays: "Guinée", indicatif: "+224" },
  { region: "Afrique", pays: "Guinée-Bissau", indicatif: "+245" },
  { region: "Afrique", pays: "Guinée équatoriale", indicatif: "+240" },
  { region: "Afrique", pays: "Kenya", indicatif: "+254" },
  { region: "Afrique", pays: "Lesotho", indicatif: "+266" },
  { region: "Afrique", pays: "Liberia", indicatif: "+231" },
  { region: "Afrique", pays: "Libye", indicatif: "+218" },
  { region: "Afrique", pays: "Madagascar", indicatif: "+261" },
  { region: "Afrique", pays: "Malawi", indicatif: "+265" },
  { region: "Afrique", pays: "Mali", indicatif: "+223" },
  { region: "Afrique", pays: "Maroc", indicatif: "+212" },
  { region: "Afrique", pays: "Maurice", indicatif: "+230" },
  { region: "Afrique", pays: "Mauritanie", indicatif: "+222" },
  { region: "Afrique", pays: "Mozambique", indicatif: "+258" },
  { region: "Afrique", pays: "Namibie", indicatif: "+264" },
  { region: "Afrique", pays: "Niger", indicatif: "+227" },
  { region: "Afrique", pays: "Nigeria", indicatif: "+234" },
  { region: "Afrique", pays: "Ouganda", indicatif: "+256" },
  { region: "Afrique", pays: "République centrafricaine", indicatif: "+236" },
  { region: "Afrique", pays: "République démocratique du Congo", indicatif: "+243" },
  { region: "Afrique", pays: "Rwanda", indicatif: "+250" },
  { region: "Afrique", pays: "Sao Tomé-et-Principe", indicatif: "+239" },
  { region: "Afrique", pays: "Sénégal", indicatif: "+221" },
  { region: "Afrique", pays: "Seychelles", indicatif: "+248" },
  { region: "Afrique", pays: "Sierra Leone", indicatif: "+232" },
  { region: "Afrique", pays: "Somalie", indicatif: "+252" },
  { region: "Afrique", pays: "Soudan", indicatif: "+249" },
  { region: "Afrique", pays: "Soudan du Sud", indicatif: "+211" },
  { region: "Afrique", pays: "Tanzanie", indicatif: "+255" },
  { region: "Afrique", pays: "Tchad", indicatif: "+235" },
  { region: "Afrique", pays: "Togo", indicatif: "+228" },
  { region: "Afrique", pays: "Tunisie", indicatif: "+216" },
  { region: "Afrique", pays: "Zambie", indicatif: "+260" },
  { region: "Afrique", pays: "Zimbabwe", indicatif: "+263" },
  // Europe
  { region: "Europe", pays: "Allemagne", indicatif: "+49" },
  { region: "Europe", pays: "Autriche", indicatif: "+43" },
  { region: "Europe", pays: "Belgique", indicatif: "+32" },
  { region: "Europe", pays: "Danemark", indicatif: "+45" },
  { region: "Europe", pays: "Espagne", indicatif: "+34" },
  { region: "Europe", pays: "Finlande", indicatif: "+358" },
  { region: "Europe", pays: "France", indicatif: "+33" },
  { region: "Europe", pays: "Grèce", indicatif: "+30" },
  { region: "Europe", pays: "Irlande", indicatif: "+353" },
  { region: "Europe", pays: "Italie", indicatif: "+39" },
  { region: "Europe", pays: "Luxembourg", indicatif: "+352" },
  { region: "Europe", pays: "Norvège", indicatif: "+47" },
  { region: "Europe", pays: "Pays-Bas", indicatif: "+31" },
  { region: "Europe", pays: "Pologne", indicatif: "+48" },
  { region: "Europe", pays: "Portugal", indicatif: "+351" },
  { region: "Europe", pays: "Roumanie", indicatif: "+40" },
  { region: "Europe", pays: "Royaume-Uni", indicatif: "+44" },
  { region: "Europe", pays: "Russie", indicatif: "+7" },
  { region: "Europe", pays: "Suède", indicatif: "+46" },
  { region: "Europe", pays: "Suisse", indicatif: "+41" },
  { region: "Europe", pays: "Turquie", indicatif: "+90" },
  { region: "Europe", pays: "Ukraine", indicatif: "+380" },
  // Amérique du Nord
  { region: "Amérique du Nord", pays: "Canada", indicatif: "+1" },
  { region: "Amérique du Nord", pays: "États-Unis", indicatif: "+1" },
  { region: "Amérique du Nord", pays: "Mexique", indicatif: "+52" },
  // Amérique centrale et Caraïbes
  { region: "Amérique centrale et Caraïbes", pays: "Cuba", indicatif: "+53" },
  { region: "Amérique centrale et Caraïbes", pays: "Guatemala", indicatif: "+502" },
  { region: "Amérique centrale et Caraïbes", pays: "Haïti", indicatif: "+509" },
  { region: "Amérique centrale et Caraïbes", pays: "Jamaïque", indicatif: "+1" },
  { region: "Amérique centrale et Caraïbes", pays: "Panama", indicatif: "+507" },
  { region: "Amérique centrale et Caraïbes", pays: "République dominicaine", indicatif: "+1" },
  // Amérique du Sud
  { region: "Amérique du Sud", pays: "Argentine", indicatif: "+54" },
  { region: "Amérique du Sud", pays: "Bolivie", indicatif: "+591" },
  { region: "Amérique du Sud", pays: "Brésil", indicatif: "+55" },
  { region: "Amérique du Sud", pays: "Chili", indicatif: "+56" },
  { region: "Amérique du Sud", pays: "Colombie", indicatif: "+57" },
  { region: "Amérique du Sud", pays: "Équateur", indicatif: "+593" },
  { region: "Amérique du Sud", pays: "Paraguay", indicatif: "+595" },
  { region: "Amérique du Sud", pays: "Pérou", indicatif: "+51" },
  { region: "Amérique du Sud", pays: "Uruguay", indicatif: "+598" },
  { region: "Amérique du Sud", pays: "Venezuela", indicatif: "+58" },
  // Moyen-Orient
  { region: "Moyen-Orient", pays: "Arabie saoudite", indicatif: "+966" },
  { region: "Moyen-Orient", pays: "Bahreïn", indicatif: "+973" },
  { region: "Moyen-Orient", pays: "Émirats arabes unis", indicatif: "+971" },
  { region: "Moyen-Orient", pays: "Irak", indicatif: "+964" },
  { region: "Moyen-Orient", pays: "Iran", indicatif: "+98" },
  { region: "Moyen-Orient", pays: "Israël", indicatif: "+972" },
  { region: "Moyen-Orient", pays: "Jordanie", indicatif: "+962" },
  { region: "Moyen-Orient", pays: "Koweït", indicatif: "+965" },
  { region: "Moyen-Orient", pays: "Liban", indicatif: "+961" },
  { region: "Moyen-Orient", pays: "Oman", indicatif: "+968" },
  { region: "Moyen-Orient", pays: "Palestine", indicatif: "+970" },
  { region: "Moyen-Orient", pays: "Qatar", indicatif: "+974" },
  { region: "Moyen-Orient", pays: "Syrie", indicatif: "+963" },
  { region: "Moyen-Orient", pays: "Yémen", indicatif: "+967" },
  // Asie
  { region: "Asie", pays: "Bangladesh", indicatif: "+880" },
  { region: "Asie", pays: "Chine", indicatif: "+86" },
  { region: "Asie", pays: "Corée du Sud", indicatif: "+82" },
  { region: "Asie", pays: "Inde", indicatif: "+91" },
  { region: "Asie", pays: "Indonésie", indicatif: "+62" },
  { region: "Asie", pays: "Japon", indicatif: "+81" },
  { region: "Asie", pays: "Malaisie", indicatif: "+60" },
  { region: "Asie", pays: "Népal", indicatif: "+977" },
  { region: "Asie", pays: "Pakistan", indicatif: "+92" },
  { region: "Asie", pays: "Philippines", indicatif: "+63" },
  { region: "Asie", pays: "Singapour", indicatif: "+65" },
  { region: "Asie", pays: "Sri Lanka", indicatif: "+94" },
  { region: "Asie", pays: "Thaïlande", indicatif: "+66" },
  { region: "Asie", pays: "Vietnam", indicatif: "+84" },
  // Océanie
  { region: "Océanie", pays: "Australie", indicatif: "+61" },
  { region: "Océanie", pays: "Nouvelle-Zélande", indicatif: "+64" },
  // Autre
  { region: "Autre", pays: "Autre", indicatif: "" },
];


export function VolunteerCard({ lang }) {
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState(false);
  const [nom, setNom] = useState("");
  const [contact, setContact] = useState("");
  const [pays, setPays] = useState("");
  const [ville, setVille] = useState("");
  const [zone, setZone] = useState("");
  const [busy, setBusy] = useState(false);

  const indicatif = (PAYS_INDICATIFS.find(p => p.pays === pays) || {}).indicatif || "";

  async function submit(e) {
    if (e && e.preventDefault) e.preventDefault();
    setBusy(true);
    // Associe automatiquement l'indicatif téléphonique du pays choisi devant le numéro,
    // sauf si le champ contient une adresse e-mail ou un indicatif déjà saisi manuellement.
    let contactFinal = contact.trim();
    if (indicatif && contactFinal && !contactFinal.includes("@") && !contactFinal.startsWith("+")) {
      contactFinal = `${indicatif} ${contactFinal}`;
    }
    const { error } = await supabase.from("benevoles").insert({ nom, contact: contactFinal, pays: pays || null, ville: ville || null, zone, device_id: DEVICE_ID, statut: "en_attente" });
    setBusy(false);
    if (!error) { setDone(true); setNom(""); setContact(""); setPays(""); setVille(""); setZone(""); }
    else alert(t(lang, "inscription_echec"));
  }

  return (
    <div style={{ marginTop: 22, background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        <IconUsers size={17} color="var(--c-accent-dark)" />
        <div style={{ fontFamily: "Fraunces, serif", fontSize: 15, fontWeight: 600, color: "var(--c-accent-dark)" }}>{t(lang, "devenir_benevole")}</div>
      </div>
      {done ? (
        <div style={{ fontSize: 12.5, color: "var(--c-accent)", display: "flex", alignItems: "center", gap: 6 }}><IconCheck size={14} /> {t(lang, "inscription_recue")}</div>
      ) : !open ? (
        <>
          <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", marginBottom: 10 }}>{t(lang, "rejoindre_equipe")}</div>
          <button onClick={() => setOpen(true)} style={{ padding: "9px 14px", borderRadius: 10, border: "1px solid var(--c-accent-dark)", background: "var(--c-surface)", color: "var(--c-accent-dark)", fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>{t(lang, "sinscrire")}</button>
        </>
      ) : (
        <form onSubmit={submit}>
          <input required value={nom} onChange={e => setNom(e.target.value)} placeholder={t(lang, "nom_complet")}
            style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
          <input required value={contact} onChange={e => setContact(e.target.value)} placeholder={indicatif ? `${t(lang, "telephone_email")} (${indicatif})` : t(lang, "telephone_email")}
            style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
          <select required value={pays} onChange={e => setPays(e.target.value)}
            style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 4, boxSizing: "border-box", background: "var(--c-surface)", color: pays ? "var(--c-text)" : "var(--c-text-muted)" }}>
            <option value="" disabled>{t(lang, "pays_label")}</option>
            {Object.entries(PAYS_INDICATIFS.reduce((acc, p) => { (acc[p.region] = acc[p.region] || []).push(p); return acc; }, {})).map(([region, list]) => (
              <optgroup key={region} label={region}>
                {list.map(p => <option key={p.pays} value={p.pays}>{p.pays}{p.indicatif ? ` (${p.indicatif})` : ""}</option>)}
              </optgroup>
            ))}
          </select>
          {indicatif && (
            <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginBottom: 8 }}>{t(lang, "indicatif_associe")}{indicatif}</div>
          )}
          <input required value={ville} onChange={e => setVille(e.target.value)} placeholder={t(lang, "ville_label")}
            style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
          <input value={zone} onChange={e => setZone(e.target.value)} placeholder={t(lang, "quartier_zone")}
            style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10, boxSizing: "border-box" }} />
          <button type="button" onClick={submit} disabled={busy} style={{ width: "100%", padding: "10px 0", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
            {busy ? t(lang, "envoi_en_cours") : t(lang, "confirmer_inscription")}
          </button>
        </form>
      )}
    </div>
  );
}

