import { ClimatWidget } from '../ClimatWidget';
import { ORGANISME_LABELS } from '../admin/AdminSpace';
import { IconAlert, IconBell, IconNewspaper, IconPaw, IconShield, IconSparkles } from '../icons/index';
import { VolunteerCard } from './VolunteerCard';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { StatCard } from '../ui/StatCard';
import { CATEGORIES, categorieLabel } from '../../constants/categories';
import { t } from '../../i18n/index';
import { co2EstimeParArbre } from '../../lib/co2';

export function Accueil({ signalements, arbres, defisProgress, notifState, onEnableNotif, onOpenAdmin, actualites, onNavigate, lang }) {
  const resolus = signalements.filter(s => s.statut === "resolu").length;
  const co2 = arbres.reduce((sum, a) => sum + co2EstimeParArbre(a), 0);
  return (
    <Screen>
      <SectionTitle sub={t(lang, "sub_accueil")}>{t(lang, "title_accueil")}</SectionTitle>

      {notifState === "default" && (
        <button onClick={onEnableNotif} style={{
          display: "flex", alignItems: "center", gap: 8, width: "100%", textAlign: "left",
          background: "var(--c-surface-soft)", border: "1px solid var(--c-border-soft)", borderRadius: 12, padding: "10px 12px",
          marginBottom: 14, cursor: "pointer", color: "var(--c-accent-dark)", fontSize: 12.5
        }}>
          <IconBell size={16} /> {t(lang, "activer_notifs")}
        </button>
      )}

      <ClimatWidget lang={lang} />

      <button onClick={() => onNavigate("assistant")} style={{
        display: "flex", alignItems: "center", gap: 10, width: "100%", textAlign: "left",
        background: "linear-gradient(120deg,var(--c-accent-dark),var(--c-accent))", border: "none", borderRadius: 14, padding: "13px 14px",
        marginBottom: 16, cursor: "pointer", color: "#fff"
      }}>
        <div style={{ background: "rgba(255,255,255,0.18)", borderRadius: 10, padding: 8 }}><IconSparkles size={17} color="#fff" /></div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600 }}>{t(lang, "assistant_titre")}</div>
          <div style={{ fontSize: 11, opacity: 0.85 }}>{t(lang, "assistant_sub")}</div>
        </div>
      </button>

      <div style={{ marginBottom: 18 }}>
        <button onClick={() => onNavigate("biodiversite")} style={{
          display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 8, padding: 14, borderRadius: 14,
          border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", textAlign: "left", width: "100%" }}>
          <div style={{ background: "var(--c-surface-soft)", borderRadius: 10, padding: 8 }}><IconPaw size={18} color="var(--c-accent)" /></div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: "var(--c-text)" }}>{t(lang, "title_biodiversite")}</div>
        </button>
      </div>

      {actualites.length > 0 && (
        <div style={{ marginBottom: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
            <IconNewspaper size={15} color="var(--c-accent-dark)" />
            <div style={{ fontFamily: "Fraunces, serif", fontSize: 16, fontWeight: 600, color: "var(--c-accent-dark)" }}>{t(lang, "actualites")}</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {actualites.slice(0, 3).map(n => (
              <div key={n.id} style={{
                background: n.urgent ? "var(--c-warning-bg)" : "var(--c-surface)", border: `1px solid ${n.urgent ? "var(--c-warning-border-soft)" : "var(--c-border)"}`,
                borderRadius: 12, padding: 12 }}>
                {n.urgent && <div style={{ fontSize: 10, fontWeight: 700, color: "#B5451B", marginBottom: 3 }}>⚠ ALERTE</div>}
                <div style={{ fontWeight: 600, fontSize: 13, color: "var(--c-text)" }}>{n.titre}</div>
                <div style={{ fontSize: 12, color: "var(--c-text-secondary)", marginTop: 3 }}>{n.contenu}</div>
                <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 5 }}>{new Date(n.created_at).toLocaleDateString("fr-FR")}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
        <StatCard label={t(lang, "stat_arbres")} value={arbres.length} unit="" accent="var(--c-accent)" />
        <StatCard label={t(lang, "signalements_resolus")} value={resolus} unit={`/${signalements.length}`} accent="#B5451B" />
      </div>
      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <StatCard label={t(lang, "stat_co2")} value={co2} unit="kg" accent="#E3A73B" />
        <StatCard label={t(lang, "points_cumules")} value={defisProgress.points} unit="pts" accent="var(--c-accent-dark)" />
      </div>
      <SectionTitle>{t(lang, "activite_recente")}</SectionTitle>
      {signalements.length === 0 && arbres.length === 0 && (
        <div style={{ color: "var(--c-text-muted)", fontSize: 13.5, background: "var(--c-surface)", padding: 16, borderRadius: 12, border: "1px dashed var(--c-border-soft)" }}>
          {t(lang, "rien_signaler")}
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {[...signalements].reverse().slice(0, 3).map(s => {
          const cat = CATEGORIES.find(c => c.id === s.categorie);
          const IconC = cat ? cat.icon : IconAlert;
          return (
            <div key={s.id} style={{ display: "flex", gap: 10, alignItems: "center", background: "var(--c-surface)", padding: 10, borderRadius: 12, border: "1px solid var(--c-border)" }}>
              <div style={{ background: "var(--c-surface-soft)", borderRadius: 10, padding: 8 }}><IconC size={16} color="var(--c-accent)" /></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--c-text)" }}>{cat ? categorieLabel(lang, cat.id) : ""}</div>
                <div style={{ fontSize: 11.5, color: "var(--c-text-muted)" }}>{s.date}</div>
              </div>
              <span style={{
                fontSize: 10.5, fontWeight: 600, padding: "3px 8px", borderRadius: 20,
                background: s.statut === "resolu" ? "var(--c-success-bg)" : "var(--c-warning-bg)", color: s.statut === "resolu" ? "var(--c-accent)" : "#B5451B" }}>
                {s.statut === "resolu" ? t(lang, "resolu") : t(lang, "en_attente")}
              </span>
            </div>
          );
        })}
        {[...signalements].reverse().slice(0, 3).some(s => s.statut === "resolu" && s.resolution_organisme) && (
          <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", padding: "0 4px" }}>
            {[...signalements].reverse().slice(0, 3).filter(s => s.statut === "resolu" && s.resolution_organisme).map(s => (
              <div key={s.id} style={{ marginBottom: 2 }}>{t(lang, "traite_par")} {ORGANISME_LABELS[s.resolution_organisme] || s.resolution_organisme}{s.resolution_action ? ` — ${s.resolution_action}` : ""}</div>
            ))}
          </div>
        )}
      </div>

      <VolunteerCard lang={lang} />

      <button onClick={onOpenAdmin} style={{
        marginTop: 24, width: "100%", background: "none", border: "none", color: "var(--c-text-faint)",
        fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 4, padding: 8
      }}><IconShield size={12} /> {t(lang, "centre_controle")}</button>
      <button onClick={() => onNavigate("confidentialite")} style={{
        width: "100%", background: "none", border: "none", color: "var(--c-text-faint)",
        fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 4, padding: 8
      }}>{t(lang, "apropos_confidentialite")}</button>
    </Screen>
  );
}

