import { useState } from 'react';
import { IconAlert, IconMapPin, IconTree, IconTrophy } from '../icons/index';

export const ONBOARDING_SLIDES = [
  { icon: IconAlert, title: "Signale un problème", text: "Décharges, pollution, déforestation... prends une photo, ta position s'ajoute automatiquement." },
  { icon: IconMapPin, title: "Vois la carte communautaire", text: "Les signalements validés et les arbres plantés par tout le monde, en direct." },
  { icon: IconTree, title: "Plante et suis tes arbres", text: "Enregistre chaque arbre planté et suis sa croissance dans le temps." },
  { icon: IconTrophy, title: "Relève des défis", text: "Gagne des points, débloque des badges, grimpe dans le classement." },
];


export function Onboarding({ onDone }) {
  const [step, setStep] = useState(0);
  const slide = ONBOARDING_SLIDES[step];
  const Icon = slide.icon;
  const last = step === ONBOARDING_SLIDES.length - 1;
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 20000, background: "linear-gradient(160deg,var(--c-accent-dark),var(--c-sky))", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 32, color: "#fff", textAlign: "center" }}>
      <button onClick={onDone} aria-label="Fermer" style={{
        position: "absolute", top: 18, right: 18, background: "rgba(255,255,255,0.18)", border: "none",
        borderRadius: "50%", width: 34, height: 34, color: "#fff", fontSize: 16, cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>

      <div style={{ background: "rgba(255,255,255,0.15)", borderRadius: "50%", padding: 22, marginBottom: 22 }}>
        <Icon size={36} color="#fff" />
      </div>
      <div style={{ fontFamily: "Fraunces, serif", fontSize: 21, fontWeight: 600, marginBottom: 10 }}>{slide.title}</div>
      <div style={{ fontSize: 14, opacity: 0.9, lineHeight: 1.5, maxWidth: 280 }}>{slide.text}</div>

      <div style={{ display: "flex", gap: 6, marginTop: 28, marginBottom: 28 }}>
        {ONBOARDING_SLIDES.map((_, i) => (
          <span key={i} style={{ width: i === step ? 20 : 6, height: 6, borderRadius: 4, background: i === step ? "#fff" : "rgba(255,255,255,0.4)", transition: "all .3s" }} />
        ))}
      </div>

      <div style={{ display: "flex", gap: 10, width: "100%", maxWidth: 300 }}>
        {step > 0 && (
          <button onClick={() => setStep(step - 1)} style={{ flex: 1, padding: "12px 0", borderRadius: 12, border: "1px solid rgba(255,255,255,0.4)", background: "transparent", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer" }}>Précédent</button>
        )}
        <button onClick={() => last ? onDone() : setStep(step + 1)} style={{ flex: 2, padding: "12px 0", borderRadius: 12, border: "none", background: "var(--c-surface)", color: "var(--c-accent-dark)", fontWeight: 700, fontSize: 13.5, cursor: "pointer" }}>
          {last ? "Commencer" : "Suivant"}
        </button>
      </div>
      <button onClick={onDone} style={{ marginTop: 18, background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.3)", borderRadius: 20, padding: "8px 20px", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Passer l'introduction</button>
      {last && (
        <div style={{ fontSize: 11, opacity: 0.85, marginTop: 16, maxWidth: 280 }}>
          En continuant, tu acceptes notre politique de confidentialité (consultable à tout moment depuis l'accueil → À propos & Informations légales).
        </div>
      )}
    </div>
  );
}

