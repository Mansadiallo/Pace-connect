import { useRef, useState } from 'react';
import { IconCamera } from '../icons/index';
import { ETAT_SUIVI } from './MonArbre';
import { compressImage } from '../../lib/media';

export function SuiviForm({ onSave, onCancel }) {
  const [photo, setPhoto] = useState(null);
  const [etat, setEtat] = useState("vivant");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);

  function handlePhoto(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = async () => setPhoto(await compressImage(reader.result));
    reader.readAsDataURL(f);
  }

  return (
    <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid var(--c-border-soft)" }}>
      <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} style={{ display: "none" }} />
      {photo ? (
        <img src={photo} style={{ width: "100%", borderRadius: 10, maxHeight: 120, objectFit: "cover", marginBottom: 8 }} />
      ) : (
        <button onClick={() => fileRef.current.click()} style={{ width: "100%", border: "1.5px dashed var(--c-text-faint)", borderRadius: 10, padding: 12, background: "var(--c-surface-dashed)", color: "var(--c-text-secondary)", cursor: "pointer", marginBottom: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 12 }}>
          <IconCamera size={15} /> Photo de suivi
        </button>
      )}
      <select value={etat} onChange={e => setEtat(e.target.value)} style={{ width: "100%", padding: 8, borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, marginBottom: 8, boxSizing: "border-box" }}>
        {Object.entries(ETAT_SUIVI).map(([id, v]) => <option key={id} value={id}>{v.label}</option>)}
      </select>
      <input value={note} onChange={e => setNote(e.target.value)} placeholder="Note (optionnel)" style={{ width: "100%", padding: 8, borderRadius: 8, border: "1px solid var(--c-border)", fontSize: 12.5, marginBottom: 8, boxSizing: "border-box" }} />
      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={onCancel} style={{ flex: 1, padding: "8px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", fontSize: 12.5 }}>Annuler</button>
        <button disabled={busy} onClick={async () => { setBusy(true); await onSave({ photo, etat, note }); setBusy(false); }} style={{ flex: 1, padding: "8px 0", borderRadius: 8, border: "none", background: "var(--c-accent)", color: "#fff", fontWeight: 600, cursor: "pointer", fontSize: 12.5 }}>
          {busy ? "Envoi…" : "Enregistrer le suivi"}
        </button>
      </div>
    </div>
  );
}

