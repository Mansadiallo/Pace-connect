import { useState } from 'react';
import { PasswordInput } from '../ui/PasswordInput';
import { supabase } from '../../lib/supabaseClient';

export function InscriptionCitoyen({ onSuccess, onAdminAccess }) {
  const [mode, setMode] = useState("signup"); // "signup" | "login"
  const [nomComplet, setNomComplet] = useState("");
  const [email, setEmail] = useState("");
  const [telephone, setTelephone] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();
    setError("");

    if (!email.trim() || !email.includes("@")) { setError("Adresse e-mail invalide."); return; }
    if (!password || password.length < 8) { setError("Le mot de passe doit contenir au moins 8 caractères."); return; }
    if (mode === "signup") {
      if (!nomComplet.trim()) { setError("Le nom complet est requis."); return; }
      if (!telephone.trim()) { setError("Le numéro de téléphone est requis."); return; }
    }

    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: email.trim(), password,
          options: { data: { nom_complet: nomComplet.trim(), telephone: telephone.trim() } },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      }
      onSuccess();
    } catch (err) {
      setError(err.message || "Une erreur est survenue.");
    }
    setBusy(false);
  }

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: 24, background: "var(--c-bg)" }}>
      <div style={{ textAlign: "center", marginBottom: 24 }}>
        <div style={{ fontFamily: "Fraunces, serif", fontSize: 22, fontWeight: 700, color: "var(--c-accent-dark)" }}>PACE Connect</div>
        <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", marginTop: 4 }}>
          {mode === "signup" ? "Crée ton compte pour accéder à l'application." : "Connecte-toi pour continuer."}
        </div>
      </div>

      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {mode === "signup" && (
          <>
            <input value={nomComplet} onChange={e => setNomComplet(e.target.value)} placeholder="Nom complet" style={{ padding: "12px 14px", borderRadius: 12, border: "1px solid var(--c-border)", fontSize: 14, background: "var(--c-surface)", color: "var(--c-text)" }} />
            <input value={telephone} onChange={e => setTelephone(e.target.value)} type="tel" placeholder="Numéro de téléphone" style={{ padding: "12px 14px", borderRadius: 12, border: "1px solid var(--c-border)", fontSize: 14, background: "var(--c-surface)", color: "var(--c-text)" }} />
          </>
        )}
        <input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="Adresse e-mail" style={{ padding: "12px 14px", borderRadius: 12, border: "1px solid var(--c-border)", fontSize: 14, background: "var(--c-surface)", color: "var(--c-text)" }} />
        <PasswordInput value={password} onChange={e => setPassword(e.target.value)} placeholder="Mot de passe (8 caractères minimum)"
          style={{ padding: "12px 14px", borderRadius: 12, border: "1px solid var(--c-border)", fontSize: 14, background: "var(--c-surface)", color: "var(--c-text)" }} />

        {error && <div role="alert" style={{ fontSize: 12.5, color: "#B5451B", background: "var(--c-danger-border-soft)", borderRadius: 10, padding: "9px 12px" }}>{error}</div>}

        <button type="submit" disabled={busy} style={{ marginTop: 6, padding: "13px 0", borderRadius: 12, border: "none", background: busy ? "var(--c-text-faint)" : "var(--c-accent-dark)", color: "#fff", fontWeight: 700, fontSize: 14.5, cursor: busy ? "default" : "pointer" }}>
          {busy ? "…" : mode === "signup" ? "Créer mon compte" : "Se connecter"}
        </button>
      </form>

      <button onClick={() => { setMode(mode === "signup" ? "login" : "signup"); setError(""); }} style={{ marginTop: 16, background: "none", border: "none", color: "var(--c-accent-dark)", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
        {mode === "signup" ? "J'ai déjà un compte — Me connecter" : "Pas encore de compte — En créer un"}
      </button>

      {onAdminAccess && (
        <button onClick={onAdminAccess} style={{ marginTop: 28, background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12, cursor: "pointer" }}>
          Tu es administrateur ? Accéder directement au Centre de contrôle →
        </button>
      )}
    </div>
  );
}

