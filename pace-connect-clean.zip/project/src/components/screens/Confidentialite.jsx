import { useState } from 'react';
import { IconLogOut } from '../icons/index';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { DEVICE_ID } from '../../lib/device';
import { supabase } from '../../lib/supabaseClient';

export function Confidentialite({ onBack }) {
  async function handleLogout() {
    await supabase.auth.signOut();
  }
  const Section = ({ title, children }) => (
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontFamily: "Fraunces, serif", fontSize: 15, fontWeight: 600, color: "var(--c-accent-dark)", marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 13, color: "var(--c-text-secondary)", lineHeight: 1.6 }}>{children}</div>
    </div>
  );
  return (
    <Screen>
      <button onClick={onBack} style={{ background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12.5, cursor: "pointer", marginBottom: 10, padding: 0 }}>← Retour</button>
      <SectionTitle sub="Dernière mise à jour : 17 juillet 2026">À propos & Informations légales</SectionTitle>

      <button onClick={handleLogout} style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 14px", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", color: "var(--c-text-secondary)", fontSize: 12.5, fontWeight: 600, cursor: "pointer", marginBottom: 18 }}>
        <IconLogOut size={15} /> Se déconnecter de mon compte
      </button>

      <Section title="À propos de PACE Connect">
        PACE Connect est une application citoyenne pour l'environnement en Afrique, développée dans le cadre de la Plateforme Africaine d'Actions et de Contrôle Environnemental (PACE).<br/><br/>
        Conçu par Mansa Diallo.
      </Section>

      <Section title="Responsable du traitement">
        Plateforme Africaine d'Actions et de Contrôle Environnemental (PACE) — Conakry, Guinée.<br/>Contact : diallomansa80@gmail.com
      </Section>

      <div style={{ fontFamily: "Fraunces, serif", fontSize: 16, fontWeight: 600, color: "var(--c-accent-dark)", marginBottom: 4, marginTop: 4 }}>Politique de confidentialité</div>

      <Section title="Données collectées">
        Signalements (catégorie, urgence, description, photo, position GPS) ; arbres plantés et observations de biodiversité (espèce, photo, position) ; publications communautaires ; inscriptions bénévoles (nom, contact, zone) ; un identifiant anonyme propre à ton appareil, sans lien avec ton identité civile.
      </Section>

      <Section title="Pourquoi">
        Faire fonctionner la carte communautaire, calculer tes statistiques et badges, assurer la modération, prévenir les abus. Aucune donnée n'est utilisée à des fins publicitaires ni vendue à un tiers.
      </Section>

      <Section title="Ce qui est public">
        Les signalements validés, les arbres, observations et publications sont visibles par tous les utilisateurs de l'app. Les inscriptions bénévoles restent réservées à l'équipe d'administration.
      </Section>

      <Section title="Prestataires techniques">
        Supabase (hébergement UE), OpenStreetMap/Esri (fonds de carte), Open-Meteo (météo locale), Netlify (hébergement web).
      </Section>

      <Section title="Sécurité">
        Connexions chiffrées (HTTPS), accès aux données restreint par appareil et par rôle, mots de passe administrateurs chiffrés, limites automatiques contre les abus.
      </Section>

      <Section title="Tes droits">
        Pour toute demande d'accès ou de rectification concernant tes données ou une contribution, écris-nous à diallomansa80@gmail.com en précisant la date, le lieu et le contenu concerné.
      </Section>

      <Section title="Supprimer mes données">
        Tu peux demander la suppression de toutes les données associées à ton appareil (signalements, arbres, observations, publications). Cette demande est traitée sous 30 jours maximum.
      </Section>
      <SuppressionDonneesCitoyen />

      <div style={{ fontSize: 11, color: "var(--c-text-muted)", marginTop: 4 }}>
        Document complet disponible sur demande auprès du responsable du traitement.
      </div>
    </Screen>
  );
}


export function SuppressionDonneesCitoyen() {
  const [step, setStep] = useState("idle"); // idle | confirm | sent
  async function envoyerDemande() {
    await supabase.from("demandes_suppression").insert({ device_id: DEVICE_ID, motif: "Demande depuis l'écran Confidentialité (citoyen)" });
    setStep("sent");
  }
  if (step === "sent") {
    return (
      <div style={{ background: "var(--c-surface-soft)", borderRadius: 12, padding: 14, fontSize: 12.5, color: "var(--c-text-secondary)", marginBottom: 18 }}>
        Ta demande a été enregistrée. Tes données seront supprimées sous 30 jours.
      </div>
    );
  }
  if (step === "confirm") {
    return (
      <div style={{ background: "var(--c-warning-bg)", border: "1px solid var(--c-warning-border-soft)", borderRadius: 12, padding: 14, marginBottom: 18 }}>
        <div style={{ fontSize: 12.5, color: "var(--c-warning-text)", lineHeight: 1.5, marginBottom: 10 }}>
          Toutes les données liées à cet appareil seront définitivement supprimées sous 30 jours. Confirmer ?
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => setStep("idle")} style={{ flex: 1, padding: "9px 0", borderRadius: 8, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>Annuler</button>
          <button onClick={envoyerDemande} style={{ flex: 1, padding: "9px 0", borderRadius: 8, border: "none", background: "#B5451B", color: "#fff", fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>Confirmer</button>
        </div>
      </div>
    );
  }
  return (
    <button onClick={() => setStep("confirm")} style={{ width: "100%", padding: "10px 0", borderRadius: 10, border: "1px solid #B5451B", background: "none", color: "#B5451B", fontWeight: 600, fontSize: 13, cursor: "pointer", marginBottom: 18 }}>
      Demander la suppression de mes données
    </button>
  );
}

