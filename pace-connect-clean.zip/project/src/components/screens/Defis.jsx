import { IconAward, IconCheck, IconLock, IconShare } from '../icons/index';
import { Classement } from './Classement';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { BADGES, DEFIS, badgeDesc, badgeLabel, defiTitle, defiUnit } from '../../constants/defis';
import { t } from '../../i18n/index';
import { shareContent } from '../../lib/media';

export function Defis({ progress, onIncrement, badgeState, onSavePseudo, lang }) {
  const badgesComputed = BADGES.map(b => ({ ...b, unlocked: b.check(badgeState) }));
  return (
    <Screen>
      <SectionTitle sub={t(lang, "sub_defis")}>{t(lang, "title_defis")}</SectionTitle>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "var(--c-accent-dark)", borderRadius: 14, padding: "14px 16px", marginBottom: 18, color: "#fff" }}>
        <div>
          <div style={{ fontSize: 11.5, opacity: 0.75 }}>{t(lang, "total_points")}</div>
          <div style={{ fontFamily: "IBM Plex Mono, monospace", fontSize: 24, fontWeight: 700 }}>{progress.points} pts</div>
        </div>
        <IconAward size={30} color="#E3A73B" />
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <div style={{ fontFamily: "Fraunces, serif", fontSize: 16, fontWeight: 600, color: "var(--c-accent-dark)" }}>{t(lang, "badges")}</div>
        <span style={{ fontSize: 11, color: "var(--c-text-muted)" }}>{badgesComputed.filter(b => b.unlocked).length}/{badgesComputed.length}</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginBottom: 22 }}>
        {badgesComputed.map(b => {
          const BIcon = b.icon;
          return (
            <div key={b.id} title={badgeDesc(lang, b.id)} style={{
              background: b.unlocked ? "var(--c-surface)" : "var(--c-bg)", border: `1px solid ${b.unlocked ? "var(--c-border)" : "var(--c-border-soft)"}`,
              borderRadius: 12, padding: "12px 6px", textAlign: "center", opacity: b.unlocked ? 1 : 0.55 }}>
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 6, color: b.unlocked ? "var(--c-accent)" : "var(--c-text-muted)" }}>
                {b.unlocked ? <BIcon size={20} /> : <IconLock size={18} />}
              </div>
              <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--c-text)", lineHeight: 1.2 }}>{badgeLabel(lang, b.id)}</div>
            </div>
          );
        })}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {DEFIS.map(d => {
          const cur = d.id === "d1" ? Math.min(d.target, (badgeState.arbres || []).length) : (progress[d.id] || 0);
          const pct = Math.min(100, Math.round((cur / d.target) * 100));
          const done = cur >= d.target;
          return (
            <div key={d.id} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 14, border: "1px solid var(--c-border)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <div style={{ fontWeight: 600, fontSize: 13.5, color: "var(--c-text)" }}>{defiTitle(lang, d.id)}</div>
                <span style={{ fontSize: 11, fontWeight: 600, color: "#E3A73B" }}>+{d.points} pts</span>
              </div>
              <div style={{ background: "var(--c-bg)", borderRadius: 8, height: 8, overflow: "hidden", marginBottom: 6 }}>
                <div style={{ width: `${pct}%`, height: "100%", background: done ? "var(--c-accent)" : "var(--c-progress-track)", transition: "width .4s" }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 11.5, color: "var(--c-text-muted)" }}>{cur} / {d.target} {defiUnit(lang, d.id)}</span>
                {done ? (
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 11, color: "var(--c-accent)", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}><IconCheck size={13} /> {t(lang, "termine")}</span>
                    <button onClick={() => shareContent(t(lang, "partage_titre_defi"), t(lang, "partage_texte_defi").replace("{titre}", d.title))} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--c-text-muted)" }}><IconShare size={15} /></button>
                  </div>
                ) : d.id === "d1" ? (
                  <span style={{ fontSize: 10.5, color: "var(--c-text-muted)", fontStyle: "italic" }}>{t(lang, "suivi_auto")}</span>
                ) : (
                  <button onClick={() => onIncrement(d)} style={{ fontSize: 11.5, padding: "5px 10px", borderRadius: 20, border: "1px solid var(--c-accent)", background: "var(--c-surface)", color: "var(--c-accent)", cursor: "pointer", fontWeight: 600 }}>{t(lang, "progresser")}</button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <Classement myPoints={progress.points} myPseudo={progress.pseudo} onSavePseudo={onSavePseudo} lang={lang} />
    </Screen>
  );
}

