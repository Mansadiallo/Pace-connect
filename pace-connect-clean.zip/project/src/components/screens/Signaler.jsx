import { useRef, useState } from 'react';
import { IconCamera, IconCheck, IconChevronLeft, IconMapPin, IconX } from '../icons/index';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { CATEGORIES, URGENCE, categorieLabel, urgenceLabel } from '../../constants/categories';
import { t } from '../../i18n/index';
import { AFRICA_CENTER } from '../../lib/geo';
import { compressImage } from '../../lib/media';

export function Signaler({ onSubmit, lang }) {
  const [step, setStep] = useState(1);
  const [categorie, setCategorie] = useState(null);
  const [urgence, setUrgence] = useState("moyenne");
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState(null);
  const [sent, setSent] = useState(false);
  const fileRef = useRef(null);

  function handlePhoto(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = async () => setPhoto(await compressImage(reader.result));
    reader.readAsDataURL(f);
  }

  function submit() {
    const finalize = (lat, lng) => {
      onSubmit({ categorie, urgence, description, photo, lat, lng });
      setSent(true);
      setTimeout(() => { setSent(false); setStep(1); setCategorie(null); setDescription(""); setPhoto(null); setUrgence("moyenne"); }, 1800);
    };
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => finalize(pos.coords.latitude, pos.coords.longitude),
        () => finalize(AFRICA_CENTER[0], AFRICA_CENTER[1]),
        { timeout: 6000, enableHighAccuracy: true }
      );
    } else {
      finalize(AFRICA_CENTER[0], AFRICA_CENTER[1]);
    }
  }

  if (sent) {
    return (
      <Screen>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: 380, textAlign: "center" }}>
          <div style={{ background: "var(--c-success-bg)", borderRadius: "50%", padding: 18, marginBottom: 14 }}><IconCheck size={32} color="var(--c-accent)" /></div>
          <div style={{ fontFamily: "Fraunces, serif", fontSize: 19, fontWeight: 600, color: "var(--c-accent-dark)" }}>{t(lang, "signalement_envoye")}</div>
          <div style={{ fontSize: 13, color: "var(--c-text-secondary)", marginTop: 6 }}>{t(lang, "merci_equipe")}</div>
        </div>
      </Screen>
    );
  }

  return (
    <Screen>
      <SectionTitle sub={t(lang, "sub_signaler")}>{t(lang, "title_signaler")}</SectionTitle>
      {step === 1 && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {CATEGORIES.map(c => {
            const IconC = c.icon;
            const active = categorie === c.id;
            return (
              <button key={c.id} onClick={() => setCategorie(c.id)} style={{
                textAlign: "left", border: active ? "2px solid var(--c-accent)" : "1px solid var(--c-border)",
                background: active ? "var(--c-surface-soft)" : "var(--c-surface)", borderRadius: 14, padding: 12, cursor: "pointer" }}>
                <IconC size={20} color={active ? "var(--c-accent)" : "var(--c-text-secondary)"} />
                <div style={{ fontSize: 12.5, marginTop: 8, fontWeight: 600, color: "var(--c-text)", lineHeight: 1.25 }}>{categorieLabel(lang, c.id)}</div>
              </button>
            );
          })}
        </div>
      )}
      {step === 2 && (
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--c-text)", marginBottom: 8 }}>{t(lang, "urgence_label")}</div>
          <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
            {URGENCE.map(u => (
              <button key={u.id} onClick={() => setUrgence(u.id)} style={{
                flex: 1, padding: "10px 0", borderRadius: 10, cursor: "pointer",
                border: urgence === u.id ? `2px solid ${u.color}` : "1px solid var(--c-border)",
                background: urgence === u.id ? `${u.color}18` : "var(--c-surface)",
                color: urgence === u.id ? u.color : "var(--c-text-secondary)", fontWeight: 600, fontSize: 12.5 }}>{urgenceLabel(lang, u.id)}</button>
            ))}
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--c-text)", marginBottom: 8 }}>{t(lang, "photo_label")}</div>
          <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} style={{ display: "none" }} />
          {photo ? (
            <div style={{ position: "relative", marginBottom: 16 }}>
              <img src={photo} alt={t(lang, "apercu_photo")} style={{ width: "100%", borderRadius: 12, maxHeight: 160, objectFit: "cover" }} />
              <button onClick={() => setPhoto(null)} style={{ position: "absolute", top: 8, right: 8, background: "var(--c-text)bb", border: "none", borderRadius: "50%", width: 26, height: 26, color: "#fff", cursor: "pointer" }}><IconX size={14} /></button>
            </div>
          ) : (
            <button onClick={() => fileRef.current.click()} style={{ width: "100%", border: "1.5px dashed var(--c-text-faint)", borderRadius: 12, padding: 18, background: "var(--c-surface-dashed)", color: "var(--c-text-secondary)", cursor: "pointer", marginBottom: 16, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, fontSize: 12.5 }}>
              <IconCamera size={20} /> {t(lang, "ajouter_photo")}
            </button>
          )}
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--c-text)", marginBottom: 8 }}>{t(lang, "description_label")}</div>
          <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder={t(lang, "decrire_situation")}
            style={{ width: "100%", borderRadius: 12, border: "1px solid var(--c-border)", padding: 10, fontSize: 13, fontFamily: "Work Sans, sans-serif", resize: "none" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, fontSize: 12, color: "var(--c-text-muted)" }}><IconMapPin size={14} /> {t(lang, "gps_auto")}</div>
        </div>
      )}
      <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
        {step === 2 && <button onClick={() => setStep(1)} style={{ padding: "12px 16px", borderRadius: 12, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer" }}><IconChevronLeft size={16} /></button>}
        <button disabled={step === 1 && !categorie} onClick={() => step === 1 ? setStep(2) : submit()} style={{
          flex: 1, padding: "12px 0", borderRadius: 12, border: "none",
          background: (step === 1 && !categorie) ? "var(--c-text-faint)" : "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 14,
          cursor: (step === 1 && !categorie) ? "default" : "pointer" }}>
          {step === 1 ? t(lang, "continuer") : t(lang, "envoyer_signalement")}
        </button>
      </div>
    </Screen>
  );
}

