import { useEffect, useState } from 'react';
import { IconRank } from '../icons/index';
import { t } from '../../i18n/index';
import { DEVICE_ID } from '../../lib/device';
import { supabase } from '../../lib/supabaseClient';

export function Classement({ myPoints, myPseudo, onSavePseudo, lang }) {
  const [top, setTop] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [pseudoInput, setPseudoInput] = useState(myPseudo || "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase.from("defis_progress").select("device_id, pseudo, points").order("points", { ascending: false }).limit(10)
      .then(({ data }) => { setTop(data || []); setLoading(false); });
  }, [myPoints]);

  async function save() {
    setSaving(true);
    await onSavePseudo(pseudoInput.trim());
    setSaving(false); setEditing(false);
  }

  return (
    <div style={{ marginTop: 22 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <IconRank size={16} color="var(--c-accent-dark)" />
          <div style={{ fontFamily: "Fraunces, serif", fontSize: 16, fontWeight: 600, color: "var(--c-accent-dark)" }}>{t(lang, "classement")}</div>
        </div>
        <button onClick={() => setEditing(!editing)} style={{ background: "none", border: "none", color: "var(--c-accent)", fontSize: 11.5, cursor: "pointer", fontWeight: 600 }}>
          {myPseudo ? t(lang, "modifier_pseudo") : t(lang, "ajouter_pseudo")}
        </button>
      </div>

      {editing && (
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <input value={pseudoInput} onChange={e => setPseudoInput(e.target.value)} placeholder={t(lang, "ton_pseudo")} maxLength={24}
            style={{ flex: 1, padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, boxSizing: "border-box" }} />
          <button onClick={save} disabled={saving} style={{ padding: "0 16px", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>OK</button>
        </div>
      )}

      {loading ? <div style={{ textAlign: "center", color: "var(--c-text-muted)", fontSize: 13 }}>{t(lang, "chargement")}</div> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {top.map((u, i) => (
            <div key={u.device_id} style={{
              display: "flex", alignItems: "center", gap: 10, background: u.device_id === DEVICE_ID ? "var(--c-surface-soft)" : "var(--c-surface)",
              border: "1px solid var(--c-border)", borderRadius: 10, padding: "8px 12px" }}>
              <div style={{ width: 20, fontFamily: "IBM Plex Mono, monospace", fontSize: 12.5, fontWeight: 700, color: i < 3 ? "#E3A73B" : "var(--c-text-muted)" }}>{i + 1}</div>
              <div style={{ flex: 1, fontSize: 12.5, fontWeight: 600, color: "var(--c-text)" }}>{u.pseudo || `${t(lang, "citoyen")} ${u.device_id.slice(0, 5)}`}{u.device_id === DEVICE_ID ? t(lang, "toi") : ""}</div>
              <div style={{ fontFamily: "IBM Plex Mono, monospace", fontSize: 12.5, fontWeight: 600, color: "var(--c-accent)" }}>{u.points} pts</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

