import { useRef, useState } from 'react';
import { IconCamera, IconPlus, IconShare, IconSprout, IconTree } from '../icons/index';
import { SuiviForm } from './SuiviForm';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { TreeRing } from '../ui/TreeRing';
import { t } from '../../i18n/index';
import { AFRICA_CENTER } from '../../lib/geo';
import { compressImage, shareContent } from '../../lib/media';

export const ETAT_SUIVI = { vivant: { label: "En bonne santé", color: "var(--c-accent)" }, stresse: { label: "En difficulté", color: "var(--c-warning)" }, mort: { label: "Mort", color: "#B5451B" } };


export function MonArbre({ arbres, suivis, onAdd, onAddSuivi, lang }) {
  const [showForm, setShowForm] = useState(false);
  const [nom, setNom] = useState("");
  const [photo, setPhoto] = useState(null);
  const [suiviOuvert, setSuiviOuvert] = useState(null);
  const fileRef = useRef(null);

  function handlePhoto(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = async () => setPhoto(await compressImage(reader.result));
    reader.readAsDataURL(f);
  }

  function submit() {
    if (!nom.trim()) return;
    const finalize = (lat, lng) => {
      onAdd({ nom, photo, lat, lng });
      setNom(""); setPhoto(null); setShowForm(false);
    };
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => finalize(pos.coords.latitude, pos.coords.longitude),
        () => finalize(AFRICA_CENTER[0], AFRICA_CENTER[1]),
        { timeout: 6000, enableHighAccuracy: true }
      );
    } else {
      finalize(AFRICA_CENTER[0], AFRICA_CENTER[1]);
    }
  }

  function growth(a) {
    const days = (Date.now() - a.plantedAt) / 86400000;
    return Math.min(100, Math.round((days / 180) * 100));
  }

  function dernierSuivi(arbreId) {
    return (suivis || []).filter(s => s.arbre_id === arbreId).sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0] || null;
  }

  function joursDepuis(dateStr) {
    return Math.round((Date.now() - new Date(dateStr).getTime()) / 86400000);
  }

  return (
    <Screen>
      <SectionTitle sub={t(lang, "sub_arbre")}>{t(lang, "title_arbre")}</SectionTitle>
      {!showForm && (
        <button onClick={() => setShowForm(true)} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "12px 0", borderRadius: 12, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer", marginBottom: 16 }}>
          <IconPlus size={16} /> {t(lang, "btn_planter")}
        </button>
      )}
      {showForm && (
        <div style={{ background: "var(--c-surface)", borderRadius: 14, padding: 14, border: "1px solid var(--c-border)", marginBottom: 16 }}>
          <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} style={{ display: "none" }} />
          {photo ? (
            <img src={photo} style={{ width: "100%", borderRadius: 10, maxHeight: 130, objectFit: "cover", marginBottom: 10 }} />
          ) : (
            <button onClick={() => fileRef.current.click()} style={{ width: "100%", border: "1.5px dashed var(--c-text-faint)", borderRadius: 10, padding: 14, background: "var(--c-surface-dashed)", color: "var(--c-text-secondary)", cursor: "pointer", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 12 }}>
              <IconCamera size={16} /> Photo de l'arbre
            </button>
          )}
          <input value={nom} onChange={e => setNom(e.target.value)} placeholder="Espèce (ex : Manguier, Teck...)" style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10, boxSizing: "border-box" }} />
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setShowForm(false)} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", fontSize: 13 }}>Annuler</button>
            <button onClick={submit} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "none", background: "var(--c-accent)", color: "#fff", fontWeight: 600, cursor: "pointer", fontSize: 13 }}>Enregistrer</button>
          </div>
        </div>
      )}
      {arbres.length === 0 && !showForm && (
        <div style={{ color: "var(--c-text-muted)", fontSize: 13.5, background: "var(--c-surface)", padding: 16, borderRadius: 12, border: "1px dashed var(--c-border-soft)", textAlign: "center" }}>
          <IconSprout size={22} /><div style={{marginTop: 6}}>Aucun arbre enregistré pour le moment.</div>
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {[...arbres].reverse().map(a => {
          const ds = dernierSuivi(a.id);
          const refDate = ds ? ds.created_at : a.plantedAt;
          const jours = joursDepuis(refDate);
          const rappel = jours >= 90;
          const etatInfo = ds ? ETAT_SUIVI[ds.etat] || ETAT_SUIVI.vivant : null;
          return (
          <div key={a.id} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 12, border: "1px solid var(--c-border)" }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <div style={{ position: "relative", width: 56, height: 56, flexShrink: 0 }}>
                {a.photo_url ? (
                  <img src={a.photo_url} style={{ width: 56, height: 56, borderRadius: "50%", objectFit: "cover", border: "3px solid var(--c-bg)" }} />
                ) : (
                  <>
                    <TreeRing pct={growth(a)} />
                    <span style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)" }}><IconTree size={18} color="var(--c-accent)" /></span>
                  </>
                )}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 13.5, color: "var(--c-text)" }}>{a.nom}</div>
                <div style={{ fontSize: 11.5, color: "var(--c-text-muted)" }}>Planté le {a.date}</div>
                {etatInfo && <div style={{ fontSize: 10.5, fontWeight: 600, color: etatInfo.color, marginTop: 2 }}>{etatInfo.label} · suivi il y a {jours} j</div>}
              </div>
              <button onClick={() => shareContent("Mon arbre sur PACE", `Je viens d'enregistrer un ${a.nom} sur PACE 🌱 Ensemble pour un avenir durable.`)}
                style={{ background: "none", border: "none", cursor: "pointer", color: "var(--c-text-muted)", padding: 6 }}><IconShare size={16} /></button>
              <div style={{ fontFamily: "IBM Plex Mono, monospace", fontSize: 13, color: "var(--c-accent)", fontWeight: 600 }}>{growth(a)}%</div>
            </div>

            {rappel && suiviOuvert !== a.id && (
              <div style={{ marginTop: 8, fontSize: 11, fontWeight: 600, color: "var(--c-warning)", background: "var(--c-warning-bg)", borderRadius: 8, padding: "6px 8px" }}>
                🔔 Suivi recommandé — dernière preuve de croissance il y a {jours} jours
              </div>
            )}

            {suiviOuvert === a.id ? (
              <SuiviForm arbre={a} onCancel={() => setSuiviOuvert(null)} onSave={async (payload) => { await onAddSuivi(a.id, payload); setSuiviOuvert(null); }} />
            ) : (
              <button onClick={() => setSuiviOuvert(a.id)} style={{ marginTop: 8, width: "100%", padding: "8px 0", borderRadius: 8, border: "1px dashed var(--c-text-faint)", background: "var(--c-surface-dashed)", color: "var(--c-text-secondary)", fontSize: 12, cursor: "pointer" }}>
                + Ajouter une preuve de suivi (photo récente)
              </button>
            )}
          </div>
          );
        })}
      </div>
    </Screen>
  );
}

