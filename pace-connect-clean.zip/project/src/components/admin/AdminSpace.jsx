import { useEffect, useState } from 'react';
import { AdminActualites } from './AdminActualites';
import { AdminBenevoles } from './AdminBenevoles';
import { AdminHistorique } from './AdminHistorique';
import { AdminRapports } from './AdminRapports';
import { AdminSuppressions } from './AdminSuppressions';
import { IconAlert, IconClock, IconDownload, IconLogOut, IconNewspaper, IconTrash, IconTree, IconUserCircle, IconUsers } from '../icons/index';
import { ConfirmActionModal } from '../ui/ConfirmActionModal';
import { NotifBell } from '../ui/NotifBell';
import { PasswordInput } from '../ui/PasswordInput';
import { Screen } from '../ui/Screen';
import { SectionTitle } from '../ui/SectionTitle';
import { StatCard } from '../ui/StatCard';
import { CATEGORIES, URGENCE } from '../../constants/categories';
import { subscribeToPush } from '../../lib/push';
import { AUTH_URL, SUPABASE_KEY, persistSession, supabase } from '../../lib/supabaseClient';

export const MOTIF_LABELS_ADMIN = { faux: "Faux signalement", doublon: "Doublon", spam: "Spam", erreur_localisation: "Erreur de localisation" };


export const MOTIF_OPTIONS_ADMIN = [
  { id: "faux", label: "Faux signalement" },
  { id: "doublon", label: "Doublon" },
  { id: "spam", label: "Spam" },
  { id: "erreur_localisation", label: "Erreur de localisation" },
];

// Point 5 : ancrage institutionnel — organismes responsables pouvant être crédités d'une résolution


export const ORGANISME_OPTIONS = [
  { id: "mairie", label: "Mairie / collectivité locale" },
  { id: "service_environnement", label: "Service de l'environnement" },
  { id: "ong_partenaire", label: "ONG partenaire" },
  { id: "benevoles_pace", label: "Bénévoles PACE" },
  { id: "autre", label: "Autre organisme" },
];


export const ORGANISME_LABELS = Object.fromEntries(ORGANISME_OPTIONS.map(o => [o.id, o.label]));


export function AdminSpace({ signalements, arbres, onUpdateStatut, onResolve, onValidate, onValidateArbre, onDelete, onSoftDeleteArbre, onRevertModeration, onSoftDeleteSignalement, onExit }) {
  const [session, setSession] = useState(null);
  const [isAdmin, setIsAdmin] = useState(null); // null = en cours de vérification
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [mode, setMode] = useState("login"); // login | signup | forgot
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState("attente");
  const [panel, setPanel] = useState("signalements");
  const [moderationModal, setModerationModal] = useState(null);
  const [recoveryToken, setRecoveryToken] = useState(null);
  const [welcomeSession, setWelcomeSession] = useState(false); // true = vient de cliquer le lien reçu par e-mail
  const [newPassword, setNewPassword] = useState("");

  useEffect(() => {
    const hash = window.location.hash || "";
    if (!hash.includes("access_token")) return;
    const params = new URLSearchParams(hash.replace("#", ""));
    const token = params.get("access_token");
    const refreshToken = params.get("refresh_token");
    const type = params.get("type");
    if (!token) return;

    if (type === "recovery") {
      setRecoveryToken(token);
      return;
    }
    // Lien de création de compte (signup / magiclink / invite) : on connecte directement
    // puis on demande de choisir un mot de passe.
    (async () => {
      try {
        const res = await fetch(`${AUTH_URL}/user`, { headers: { apikey: SUPABASE_KEY, Authorization: "Bearer " + token } });
        const user = await res.json().catch(() => null);
        persistSession({ access_token: token, refresh_token: refreshToken, user });
        setSession({ access_token: token, refresh_token: refreshToken, user });
        setWelcomeSession(true);
        window.location.hash = "";
      } catch (e) {}
    })();
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) { setIsAdmin(null); setIsSuperAdmin(false); return; }
    supabase.from("admins").select("email, role").eq("email", session.user.email).maybeSingle()
      .then(({ data }) => { setIsAdmin(!!data); setIsSuperAdmin(!!data && data.role === "super_admin"); });
  }, [session]);

  async function handleSetNewPassword(e) {
    if (e && e.preventDefault) e.preventDefault();
    setError(""); setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword }, recoveryToken);
    setBusy(false);
    if (error) { setError(error.message); return; }
    setRecoveryToken(null);
    window.location.hash = "";
    setError("Mot de passe mis à jour. Connecte-toi avec ton nouveau mot de passe.");
  }

  async function handleChooseWelcomePassword(e) {
    if (e && e.preventDefault) e.preventDefault();
    setError(""); setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword }, session.access_token);
    setBusy(false);
    if (error) { setError(error.message); return; }
    setWelcomeSession(false);
    setNewPassword("");
  }

  async function handleForgot(e) {
    if (e && e.preventDefault) e.preventDefault();
    setError(""); setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setBusy(false);
    if (error) { setError(error.message); return; }
    setError("Un e-mail de réinitialisation a été envoyé si ce compte existe.");
  }

  async function handleSignupOtp(e) {
    if (e && e.preventDefault) e.preventDefault();
    setError("");
    if (!email.trim() || !email.includes("@")) { setError("Entre une adresse e-mail valide."); return; }
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ email: email.trim() });
    setBusy(false);
    if (error) { setError(error.message); return; }
    setError("E-mail envoyé ! Ouvre le lien reçu pour choisir ton mot de passe et activer ton compte.");
  }

  async function handleAuth(e) {
    if (e && e.preventDefault) e.preventDefault();
    setError("");
    if (!email.trim() || !email.includes("@")) { setError("Entre une adresse e-mail valide."); return; }
    if (!password || password.length < 6) { setError("Le mot de passe doit contenir au moins 6 caractères."); return; }
    setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        try {
          if (typeof Notification !== "undefined" && Notification.permission !== "denied") {
            const perm = await Notification.requestPermission();
            if (perm === "granted") subscribeToPush();
          }
        } catch (notifErr) {
          console.error("Notifications indisponibles dans ce contexte :", notifErr);
        }
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setError("Compte créé. Vérifie ta boîte mail pour confirmer l'adresse, puis connecte-toi.");
      }
    } catch (err) {
      const msg = (err && err.message) ? err.message : "Une erreur est survenue. Réessaie.";
      setError(msg === "Invalid login credentials" ? "Identifiants incorrects." : msg);
    } finally {
      setBusy(false);
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    setSession(null);
  }

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleteSent, setDeleteSent] = useState(false);
  async function handleDeleteAccount() {
    await supabase.from("demandes_suppression").insert({ email: session.user.email, motif: "Demande depuis l'espace administrateur" });
    setDeleteSent(true);
    setTimeout(async () => { await supabase.auth.signOut(); setSession(null); }, 2500);
  }

  if (recoveryToken) {
    return (
      <Screen>
        <SectionTitle sub="Choisis un nouveau mot de passe.">Réinitialisation</SectionTitle>
        <form onSubmit={handleSetNewPassword} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)" }}>
          <PasswordInput value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Nouveau mot de passe"
            style={{ padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10 }} />
          {error && <div role="alert" style={{ fontSize: 12, color: error.startsWith("Mot de passe mis") ? "var(--c-accent)" : "#B5451B", marginBottom: 10 }}>{error}</div>}
          <button type="submit" disabled={busy} style={{ width: "100%", padding: "11px 0", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer" }}>
            {busy ? "..." : "Enregistrer le nouveau mot de passe"}
          </button>
        </form>
      </Screen>
    );
  }

  if (welcomeSession && session) {
    return (
      <Screen>
        <SectionTitle sub={session.user ? session.user.email : ""}>Bienvenue sur PACE Connect</SectionTitle>
        <form onSubmit={handleChooseWelcomePassword} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)" }}>
          <div style={{ fontSize: 13, color: "var(--c-text-secondary)", marginBottom: 12, lineHeight: 1.5 }}>
            Ton adresse est confirmée. Choisis maintenant un mot de passe pour ton compte administrateur.
          </div>
          <PasswordInput value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Choisis un mot de passe (6 caractères min.)"
            style={{ padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10 }} />
          {error && <div role="alert" style={{ fontSize: 12, color: "#B5451B", marginBottom: 10 }}>{error}</div>}
          <button type="submit" disabled={busy || newPassword.length < 6} style={{
            width: "100%", padding: "11px 0", borderRadius: 10, border: "none",
            background: newPassword.length < 6 ? "var(--c-text-faint)" : "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5,
            cursor: newPassword.length < 6 ? "default" : "pointer" }}>
            {busy ? "..." : "Activer mon compte"}
          </button>
        </form>
      </Screen>
    );
  }

  if (!session) {
    if (mode === "forgot") {
      return (
        <Screen>
          <SectionTitle sub="Reçois un lien pour réinitialiser ton mot de passe.">Mot de passe oublié</SectionTitle>
          <form onSubmit={handleForgot} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)" }}>
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="Ton adresse e-mail admin" aria-label="Adresse e-mail"
              style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10, boxSizing: "border-box" }} />
            {error && <div role="alert" style={{ fontSize: 12, color: error.startsWith("Un e-mail") ? "var(--c-accent)" : "#B5451B", marginBottom: 10 }}>{error}</div>}
            <button type="submit" disabled={busy} style={{ width: "100%", padding: "11px 0", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer", marginBottom: 8 }}>
              {busy ? "..." : "Envoyer le lien"}
            </button>
            <button type="button" onClick={() => { setMode("login"); setError(""); }} style={{ width: "100%", background: "none", border: "none", color: "var(--c-text-secondary)", fontSize: 12, cursor: "pointer", padding: 6 }}>← Retour à la connexion</button>
          </form>
          <button onClick={onExit} style={{ marginTop: 14, background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12.5, cursor: "pointer" }}>← Retour à l'app</button>
        </Screen>
      );
    }
    if (mode === "signup") {
      return (
        <Screen>
          <SectionTitle sub="Un lien te sera envoyé pour activer ton compte.">Créer un compte admin</SectionTitle>
          <form onSubmit={handleSignupOtp} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)" }}>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Adresse e-mail" aria-label="Adresse e-mail"
              style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 10, boxSizing: "border-box" }} />
            {error && <div role="alert" style={{ fontSize: 12, color: error.startsWith("E-mail envoyé") ? "var(--c-accent)" : "#B5451B", marginBottom: 10 }}>{error}</div>}
            <button type="submit" disabled={busy} style={{ width: "100%", padding: "11px 0", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer", marginBottom: 8 }}>
              {busy ? "..." : "Envoyer le lien de création"}
            </button>
            <button type="button" onClick={() => { setMode("login"); setError(""); }} style={{ width: "100%", background: "none", border: "none", color: "var(--c-text-secondary)", fontSize: 12, cursor: "pointer", padding: 6 }}>
              Déjà un compte ? Se connecter
            </button>
          </form>
          <button onClick={onExit} style={{ marginTop: 14, background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12.5, cursor: "pointer" }}>← Retour à l'app</button>
        </Screen>
      );
    }
    return (
      <Screen>
        <SectionTitle sub="Réservé à l'équipe de modération.">Centre de contrôle PACE</SectionTitle>
        <form onSubmit={handleAuth} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)" }}>
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Adresse e-mail" aria-label="Adresse e-mail"
            style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
          <PasswordInput value={password} onChange={e => setPassword(e.target.value)} placeholder="Mot de passe"
            style={{ padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 6 }} />
          <button type="button" onClick={() => { setMode("forgot"); setError(""); }} style={{ background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 11.5, cursor: "pointer", padding: 0, marginBottom: 10, display: "block" }}>
            Mot de passe oublié ?
          </button>
          {error && <div role="alert" style={{ fontSize: 12, color: "#B5451B", marginBottom: 10 }}>{error}</div>}
          <button type="submit" disabled={busy} style={{ width: "100%", padding: "11px 0", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 13.5, cursor: "pointer", marginBottom: 8 }}>
            {busy ? "..." : "Se connecter"}
          </button>
          <button type="button" onClick={() => { setMode("signup"); setError(""); }} style={{ width: "100%", background: "none", border: "none", color: "var(--c-text-secondary)", fontSize: 12, cursor: "pointer", padding: 6 }}>
            Pas encore de compte admin ? En créer un
          </button>
        </form>
        <button onClick={onExit} style={{ marginTop: 14, background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12.5, cursor: "pointer" }}>← Retour à l'app</button>
      </Screen>
    );
  }

  if (isAdmin === null) {
    return <Screen><div style={{ textAlign: "center", color: "var(--c-text-muted)", marginTop: 60, fontSize: 13 }}>Vérification des droits…</div></Screen>;
  }

  if (!isAdmin) {
    return (
      <Screen>
        <SectionTitle>Accès refusé</SectionTitle>
        <div style={{ background: "var(--c-surface)", borderRadius: 14, padding: 16, border: "1px solid var(--c-border)", fontSize: 13, color: "var(--c-text-secondary)" }}>
          Le compte <b>{session.user.email}</b> n'a pas les droits administrateur.
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button onClick={handleLogout} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", fontSize: 13 }}>Se déconnecter</button>
          <button onClick={onExit} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", cursor: "pointer", fontSize: 13 }}>Retour à l'app</button>
        </div>
      </Screen>
    );
  }

  const resolus = signalements.filter(s => s.statut === "resolu").length;
  const attente = signalements.filter(s => s.statut !== "resolu").length;
  const filtered = signalements.filter(s => filter === "tous" || (filter === "resolu" ? s.statut === "resolu" : s.statut !== "resolu"));

  return (
    <Screen>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
        <SectionTitle sub={session.user.email}>Centre de contrôle PACE</SectionTitle>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <NotifBell email={session.user.email} onNavigate={setPanel} />
          <button onClick={() => setConfirmDelete(true)} title="Supprimer mon compte" style={{ background: "none", border: "none", color: "var(--c-text-muted)", cursor: "pointer", padding: 6 }}><IconUserCircle size={18} /></button>
          <button onClick={handleLogout} style={{ background: "none", border: "none", color: "var(--c-text-muted)", cursor: "pointer", padding: 6 }}><IconLogOut size={18} /></button>
        </div>
      </div>

      {confirmDelete && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, padding: 20 }} onClick={() => !deleteSent && setConfirmDelete(false)}>
          <div style={{ background: "var(--c-surface)", borderRadius: 16, padding: 20, maxWidth: 340, width: "100%" }} onClick={e => e.stopPropagation()}>
            {deleteSent ? (
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>Demande enregistrée</div>
                <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", lineHeight: 1.5 }}>Ton compte et tes données seront supprimés sous 30 jours. Tu vas être déconnecté.</div>
              </div>
            ) : (
              <>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>Supprimer ton compte ?</div>
                <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", lineHeight: 1.5, marginBottom: 16 }}>
                  Ton compte ({session.user.email}) et les données qui y sont liées seront définitivement supprimés sous 30 jours. Cette action est irréversible.
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => setConfirmDelete(false)} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "none", color: "var(--c-text-secondary)", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Annuler</button>
                  <button onClick={handleDeleteAccount} style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "none", background: "#B5451B", color: "#fff", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Supprimer</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <StatCard label="En attente" value={attente} unit="" accent="#B5451B" />
        <StatCard label="Résolus" value={resolus} unit="" accent="var(--c-accent)" />
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 18, overflowX: "auto" }}>
        {[["signalements", "Signalements", IconAlert], ["arbres", "Arbres", IconTree], ["actualites", "Actualités", IconNewspaper], ["benevoles", "Bénévoles", IconUsers], ["historique", "Historique", IconClock], ["rapports", "Rapports", IconDownload], ["suppressions", "Suppressions", IconUserCircle]].map(([id, label, Ic]) => (
          <button key={id} onClick={() => setPanel(id)} style={{
            display: "flex", alignItems: "center", gap: 5, padding: "7px 12px", borderRadius: 20, fontSize: 11.5, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap",
            border: panel === id ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
            background: panel === id ? "var(--c-accent-dark)" : "var(--c-surface)", color: panel === id ? "#fff" : "var(--c-text-secondary)" }}><Ic size={13} />{label}</button>
        ))}
      </div>

      {panel === "signalements" && (
        <>
          <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
            {[["attente", "En attente"], ["resolu", "Résolus"], ["tous", "Tous"]].map(([id, label]) => (
              <button key={id} onClick={() => setFilter(id)} style={{
                padding: "6px 12px", borderRadius: 20, fontSize: 11.5, fontWeight: 600, cursor: "pointer",
                border: filter === id ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
                background: filter === id ? "var(--c-accent-dark)" : "var(--c-surface)", color: filter === id ? "#fff" : "var(--c-text-secondary)" }}>{label}</button>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {filtered.length === 0 && <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 20 }}>Aucun signalement ici.</div>}
            {[...filtered].reverse().map(s => {
              const cat = CATEGORIES.find(c => c.id === s.categorie);
              const u = URGENCE.find(x => x.id === s.urgence);
              return (
                <div key={s.id} style={{ background: "var(--c-surface)", borderRadius: 14, padding: 12, border: "1px solid var(--c-border)" }}>
                  {s.photo_url && <img src={s.photo_url} style={{ width: "100%", maxHeight: 130, objectFit: "cover", borderRadius: 10, marginBottom: 8 }} />}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{cat ? cat.label : s.categorie}</div>
                    <span style={{ fontSize: 10, fontWeight: 600, color: u ? u.color : "#B5451B" }}>{u ? u.label : s.urgence}</span>
                  </div>
                  {!s.valide && (
                    <div style={{ fontSize: 10.5, fontWeight: 600, color: "#B5451B", marginBottom: 4 }}>⏳ Non validé — invisible du public</div>
                  )}
                  {s.moderation_motif && (
                    <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginBottom: 4 }}>Dernière modération : {MOTIF_LABELS_ADMIN[s.moderation_motif] || s.moderation_motif}</div>
                  )}
                  <div style={{ fontSize: 11, color: "var(--c-text-muted)", marginBottom: 6 }}>{s.date} · appareil {s.device_id.slice(0, 6)}</div>
                  {s.description && <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", marginBottom: 8 }}>{s.description}</div>}
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {!s.valide && (
                      <button onClick={() => onValidate(s.id)} style={{
                        flex: "1 1 100%", fontSize: 11.5, padding: "7px 0", borderRadius: 8, border: "none", cursor: "pointer", fontWeight: 600,
                        background: "var(--c-accent-dark)", color: "#fff" }}>
                        ✓ Valider et publier
                      </button>
                    )}
                    {s.valide && (
                      <button onClick={() => setModerationModal({ type: "revert", signalement: s })} style={{
                        flex: "1 1 100%", fontSize: 11, padding: "7px 0", borderRadius: 8, border: "1px solid var(--c-warning)", cursor: "pointer", fontWeight: 600,
                        background: "var(--c-warning-bg)", color: "var(--c-warning-text)" }}>
                        ↺ Repasser en vérification
                      </button>
                    )}
                    <button onClick={() => s.statut === "resolu" ? onUpdateStatut(s.id, "attente") : setModerationModal({ type: "resolve", signalement: s })} style={{
                      flex: 1, fontSize: 11.5, padding: "7px 0", borderRadius: 8, border: "none", cursor: "pointer", fontWeight: 600,
                      background: s.statut === "resolu" ? "var(--c-bg)" : "var(--c-accent)", color: s.statut === "resolu" ? "var(--c-text-secondary)" : "#fff" }}>
                      {s.statut === "resolu" ? "Remettre en attente" : "Marquer résolu"}
                    </button>
                    <button onClick={() => setModerationModal({ type: "delete", signalement: s })} style={{
                      padding: "7px 10px", borderRadius: 8, border: "1px solid var(--c-danger-border-soft)", background: "var(--c-surface)", color: "#B5451B", cursor: "pointer" }}>
                      <IconTrash size={14} />
                    </button>
                  </div>
                  {s.statut === "resolu" && s.resolution_organisme && (
                    <div style={{ marginTop: 8, fontSize: 11, color: "var(--c-text-secondary)", background: "var(--c-success-bg)", borderRadius: 8, padding: "6px 8px" }}>
                      ✓ Résolu par {ORGANISME_LABELS[s.resolution_organisme] || s.resolution_organisme}{s.resolution_action ? ` — ${s.resolution_action}` : ""}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      {moderationModal && moderationModal.type === "revert" && (
        <ConfirmActionModal
          title="Repasser en vérification"
          description="Le signalement redevient invisible du public jusqu'à nouvelle validation. L'auteur sera notifié de cette décision."
          reasonLabel="Détail pour le journal d'audit (obligatoire)"
          confirmLabel="Repasser ce signalement en vérification"
          motifOptions={MOTIF_OPTIONS_ADMIN}
          danger
          onCancel={() => setModerationModal(null)}
          onConfirm={async (payload) => { await onRevertModeration(moderationModal.signalement, payload); setModerationModal(null); }}
        />
      )}
      {moderationModal && moderationModal.type === "delete" && (
        <ConfirmActionModal
          title="Mettre ce signalement à la corbeille"
          description="Il disparaît immédiatement de l'app et de la carte, mais reste archivé et restaurable par un super-administrateur."
          reasonLabel="Motif de la suppression (obligatoire)"
          confirmLabel="Mettre à la corbeille"
          danger
          onCancel={() => setModerationModal(null)}
          onConfirm={async (payload) => { await onSoftDeleteSignalement(moderationModal.signalement, payload); setModerationModal(null); }}
        />
      )}
      {moderationModal && moderationModal.type === "resolve" && (
        <ConfirmActionModal
          title="Marquer comme résolu"
          description="Indique l'organisme responsable de l'action et ce qui a été fait. Ces informations seront visibles publiquement, pour que les citoyens voient l'impact réel de leur signalement."
          reasonLabel="Action réalisée (obligatoire)"
          confirmLabel="Marquer résolu"
          motifOptions={ORGANISME_OPTIONS}
          onCancel={() => setModerationModal(null)}
          onConfirm={async (payload) => { await onResolve(moderationModal.signalement, { organisme: payload.motif, action: payload.reason }); setModerationModal(null); }}
        />
      )}

      {panel === "arbres" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {arbres.length === 0 && <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 20 }}>Aucun arbre enregistré.</div>}
          {[...arbres].reverse().map(a => (
            <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 10, background: "var(--c-surface)", borderRadius: 12, padding: 10, border: "1px solid var(--c-border)" }}>
              {a.photo_url ? (
                <img src={a.photo_url} style={{ width: 44, height: 44, borderRadius: 8, objectFit: "cover", flexShrink: 0 }} />
              ) : (
                <div style={{ width: 44, height: 44, borderRadius: 8, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "var(--c-surface-soft)" }}>
                  <IconTree size={18} color="var(--c-accent)" />
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 12.5, color: "var(--c-text)" }}>{a.nom || "Arbre"}</div>
                {!a.valide && (
                  <div style={{ fontSize: 10.5, fontWeight: 600, color: "#B5451B" }}>⏳ Non validé — invisible du public</div>
                )}
                <div style={{ fontSize: 10.5, color: "var(--c-text-muted)" }}>{a.date} · appareil {a.device_id ? a.device_id.slice(0, 6) : "?"}</div>
                {!a.valide && (
                  <button onClick={() => onValidateArbre(a.id)} style={{
                    marginTop: 6, fontSize: 11, padding: "6px 10px", borderRadius: 8, border: "none", cursor: "pointer", fontWeight: 600,
                    background: "var(--c-accent-dark)", color: "#fff" }}>
                    ✓ Valider et publier
                  </button>
                )}
              </div>
              <button onClick={() => { if (confirm(`Mettre "${a.nom || "cet arbre"}" à la corbeille ? Il sera restaurable depuis Historique.`)) onSoftDeleteArbre(a); }} aria-label="Supprimer" style={{ background: "none", border: "1px solid var(--c-danger-border-soft)", borderRadius: 8, color: "#B5451B", cursor: "pointer", padding: 7, flexShrink: 0, alignSelf: "flex-start" }}>
                <IconTrash size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      {panel === "actualites" && <AdminActualites />}
      {panel === "benevoles" && <AdminBenevoles />}

      {panel === "historique" && <AdminHistorique />}
      {panel === "rapports" && <AdminRapports signalements={signalements} arbres={arbres} />}
      {panel === "suppressions" && <AdminSuppressions />}

      <button onClick={onExit} style={{ marginTop: 18, width: "100%", background: "none", border: "none", color: "var(--c-text-muted)", fontSize: 12.5, cursor: "pointer", padding: 8 }}>← Retour à l'app</button>
    </Screen>
  );
}

