import { useEffect, useState } from 'react';
import { IconMessageSquare, IconSend, IconTrash } from '../icons/index';
import { t } from '../../i18n/index';
import { logActivity } from '../../lib/activity';
import { currentSession, supabase } from '../../lib/supabaseClient';

export function AdminEquipe() {
  const [admins, setAdmins] = useState(null);
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function load() {
    const { data } = await supabase.from("admins").select("email, added_at").order("added_at", { ascending: true });
    setAdmins(data || []);
  }
  useEffect(() => { load(); }, []);

  async function addAdmin(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!email.trim()) return;
    setBusy(true); setMsg("");
    const { error } = await supabase.from("admins").insert({ email: email.trim().toLowerCase() });
    setBusy(false);
    if (error) { setMsg("Échec — vérifie l'adresse ou tes droits."); return; }
    setMsg(`${email} peut maintenant créer un compte admin avec cette adresse.`);
    setEmail("");
    load();
  }

  return (
    <div style={{ marginTop: 24 }}>
      <div style={{ fontFamily: "Fraunces, serif", fontSize: 15, fontWeight: 600, color: "var(--c-accent-dark)", marginBottom: 10 }}>Équipe administrateurs</div>
      <form onSubmit={addAdmin} style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="email@exemple.com"
          style={{ flex: 1, padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, boxSizing: "border-box" }} />
        <button type="button" onClick={addAdmin} disabled={busy} style={{ padding: "0 16px", borderRadius: 10, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, fontSize: 12.5, cursor: "pointer" }}>
          {busy ? "..." : "Ajouter"}
        </button>
      </form>
      {msg && <div style={{ fontSize: 11.5, color: "var(--c-text-secondary)", marginBottom: 10 }}>{msg}</div>}
      <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginBottom: 8 }}>La personne devra créer son compte via "Centre de contrôle PACE → Créer un compte" avec cette adresse exacte.</div>
      {admins === null ? <div style={{ fontSize: 12, color: "var(--c-text-muted)" }}>Chargement…</div> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {admins.map(a => (
            <div key={a.email} style={{ background: "var(--c-surface)", border: "1px solid var(--c-border)", borderRadius: 10, padding: "8px 12px", fontSize: 12.5, color: "var(--c-text)" }}>
              {a.email}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}


export const COLONNES = [
  { id: "a_faire", label: "À faire", color: "var(--c-text-muted)" },
  { id: "en_cours", label: "En cours", color: "#E3A73B" },
  { id: "termine", label: "Terminé", color: "var(--c-accent)" },
];


export const PRIORITES = { haute: "#B5451B", normale: "#E3A73B", basse: "var(--c-text-muted)" };


export function TacheUpdates({ tacheId, assignee }) {
  const [updates, setUpdates] = useState(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data } = await supabase.from("tache_updates").select("*").eq("tache_id", tacheId).order("created_at", { ascending: true });
    setUpdates(data || []);
  }
  useEffect(() => { load(); }, [tacheId]);

  async function submit(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    const acteur = currentSession && currentSession.user ? currentSession.user.email : "admin";
    const { error } = await supabase.from("tache_updates").insert({ tache_id: tacheId, contenu: text.trim(), auteur: acteur });
    if (!error) {
      logActivity("decision", "taches", tacheId, text.trim());
      if (assignee && assignee !== acteur) {
        supabase.from("notifications").insert({ destinataire: assignee, message: `Mise à jour terrain : "${text.trim().slice(0, 80)}"`, lien: "projets" }).catch(() => {});
      }
    }
    setBusy(false);
    setText("");
    load();
  }

  return (
    <div style={{ marginTop: 8, paddingTop: 8, borderTop: "1px solid var(--c-border)" }}>
      {updates === null ? (
        <div style={{ fontSize: 11, color: "var(--c-text-muted)" }}>Chargement…</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 8 }}>
          {updates.length === 0 && <div style={{ fontSize: 11, color: "var(--c-text-muted)" }}>Aucune mise à jour. Consigne ici les décisions et changements de terrain.</div>}
          {updates.map(u => (
            <div key={u.id} style={{ background: "var(--c-surface-soft)", borderRadius: 8, padding: "7px 9px" }}>
              <div style={{ fontSize: 11.5, color: "var(--c-text)" }}>{u.contenu}</div>
              <div style={{ fontSize: 9.5, color: "var(--c-text-muted)", marginTop: 2 }}>{u.auteur} · {new Date(u.created_at).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</div>
            </div>
          ))}
        </div>
      )}
      <form onSubmit={submit} style={{ display: "flex", gap: 6 }}>
        <input value={text} onChange={e => setText(e.target.value)} placeholder="Nouvelle décision / mise à jour…"
          style={{ flex: 1, padding: "7px 10px", borderRadius: 20, border: "1px solid var(--c-border)", fontSize: 11.5, boxSizing: "border-box" }} />
        <button type="button" onClick={submit} disabled={busy || !text.trim()} aria-label="Envoyer la mise à jour" style={{
          background: text.trim() ? "var(--c-accent)" : "var(--c-text-faint)", border: "none", borderRadius: "50%",
          width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}>
          <IconSend size={12} color="#fff" />
        </button>
      </form>
    </div>
  );
}


export function TacheCard({ t, colonnes, colId, onMove, onRemove }) {
  const [openUpdates, setOpenUpdates] = useState(false);
  return (
    <div style={{ background: "var(--c-surface)", borderRadius: 12, padding: 12, border: "1px solid var(--c-border)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ fontWeight: 600, fontSize: 13, color: "var(--c-text)", flex: 1 }}>{t.titre}</div>
        <span style={{ width: 7, height: 7, borderRadius: "50%", background: PRIORITES[t.priorite] || "var(--c-text-muted)", marginTop: 4, marginLeft: 6, flexShrink: 0 }} />
      </div>
      {t.description && <div style={{ fontSize: 12, color: "var(--c-text-secondary)", marginTop: 3 }}>{t.description}</div>}
      <div style={{ display: "flex", gap: 10, marginTop: 6, fontSize: 10.5, color: "var(--c-text-muted)" }}>
        {t.assignee && <span>👤 {t.assignee}</span>}
        {t.echeance && <span>📅 {new Date(t.echeance).toLocaleDateString("fr-FR")}</span>}
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
        {colonnes.filter(c => c.id !== colId).map(c => (
          <button key={c.id} onClick={() => onMove(t.id, c.id, t.titre)} style={{
            fontSize: 10.5, padding: "5px 8px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-surface-dashed)", color: "var(--c-text-secondary)", cursor: "pointer" }}>
            → {c.label}
          </button>
        ))}
        <button onClick={() => setOpenUpdates(!openUpdates)} style={{
          fontSize: 10.5, padding: "5px 8px", borderRadius: 8, border: "1px solid var(--c-border)", background: openUpdates ? "var(--c-accent-dark)" : "var(--c-surface-dashed)",
          color: openUpdates ? "#fff" : "var(--c-text-secondary)", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
          <IconMessageSquare size={11} /> Coordination
        </button>
        <button onClick={() => onRemove(t.id)} aria-label="Supprimer la tâche" style={{ marginLeft: "auto", background: "none", border: "none", color: "#B5451B", cursor: "pointer", padding: 4 }}><IconTrash size={13} /></button>
      </div>
      {openUpdates && <TacheUpdates tacheId={t.id} assignee={t.assignee} />}
    </div>
  );
}

