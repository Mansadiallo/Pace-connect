import { useEffect, useState } from 'react';
import { AdminEquipe } from './AdminEquipe';
import { IconDownload } from '../icons/index';
import { MiniBarChart } from '../ui/MiniBarChart';
import { StatCard } from '../ui/StatCard';
import { downloadCSV, toCSV } from '../../lib/media';
import { weeklyBuckets } from '../../lib/stats';
import { supabase } from '../../lib/supabaseClient';

export function AdminRapports({ signalements, arbres }) {
  const [benevolesCount, setBenevolesCount] = useState(null);

  useEffect(() => {
    supabase.from("benevoles").select("id", { count: "exact", head: true }).eq("is_deleted", false).then(({ count }) => setBenevolesCount(count));
  }, []);

  function exportSignalements() {
    const csv = toCSV(signalements, [
      { key: "id", label: "ID" }, { key: "categorie", label: "Catégorie" }, { key: "urgence", label: "Urgence" },
      { key: "statut", label: "Statut" }, { key: "description", label: "Description" },
      { key: "lat", label: "Latitude" }, { key: "lng", label: "Longitude" },
      { key: "date", label: "Date" }, { key: "device_id", label: "Appareil" },
    ]);
    downloadCSV(`pace-signalements-${Date.now()}.csv`, csv);
  }
  function exportArbres() {
    const csv = toCSV(arbres, [
      { key: "id", label: "ID" }, { key: "nom", label: "Espèce" }, { key: "lat", label: "Latitude" },
      { key: "lng", label: "Longitude" }, { key: "date", label: "Date de plantation" }, { key: "device_id", label: "Appareil" },
    ]);
    downloadCSV(`pace-arbres-${Date.now()}.csv`, csv);
  }
  async function exportBenevoles() {
    const { data } = await supabase.from("benevoles").select("*").eq("is_deleted", false).order("created_at", { ascending: false });
    const csv = toCSV(data || [], [
      { key: "nom", label: "Nom" }, { key: "contact", label: "Contact" }, { key: "zone", label: "Zone" },
      { key: "statut", label: "Statut" }, { key: "created_at", label: "Date d'inscription" },
    ]);
    downloadCSV(`pace-benevoles-${Date.now()}.csv`, csv);
  }

  const resolus = signalements.filter(s => s.statut === "resolu").length;

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10, marginBottom: 18 }}>
        <StatCard label="Signalements" value={signalements.length} unit="" accent="#B5451B" />
        <StatCard label="Résolus" value={resolus} unit="" accent="var(--c-accent)" />
        <StatCard label="Arbres plantés" value={arbres.length} unit="" accent="var(--c-accent)" />
        <StatCard label="Bénévoles" value={benevolesCount === null ? "…" : benevolesCount} unit="" accent="var(--c-accent-dark)" />
      </div>

      <div style={{ fontFamily: "Fraunces, serif", fontSize: 15, fontWeight: 600, color: "var(--c-accent-dark)", marginBottom: 10 }}>Évolution (8 dernières semaines)</div>
      <MiniBarChart data={weeklyBuckets(signalements)} color="#B5451B" label="Signalements" />
      <MiniBarChart data={weeklyBuckets(arbres)} color="var(--c-accent)" label="Arbres plantés" />

      <div style={{ fontFamily: "Fraunces, serif", fontSize: 15, fontWeight: 600, color: "var(--c-accent-dark)", marginBottom: 10 }}>Exporter en CSV</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <button onClick={exportSignalements} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "11px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", color: "var(--c-text)", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
          <IconDownload size={15} /> Signalements ({signalements.length})
        </button>
        <button onClick={exportArbres} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "11px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", color: "var(--c-text)", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
          <IconDownload size={15} /> Arbres plantés ({arbres.length})
        </button>
        <button onClick={exportBenevoles} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "11px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", color: "var(--c-text)", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
          <IconDownload size={15} /> Bénévoles{benevolesCount !== null ? ` (${benevolesCount})` : ""}
        </button>
      </div>

      <AdminEquipe />
    </div>
  );
}

