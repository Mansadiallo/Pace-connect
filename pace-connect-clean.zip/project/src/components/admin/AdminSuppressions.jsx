import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

export function AdminSuppressions() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("demandes_suppression").select("*").order("created_at", { ascending: false });
    setItems(data || []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function marquerTraitee(id) {
    if (!confirm("Confirmer que le compte et les données associées ont bien été supprimés manuellement (dashboard Supabase) avant de marquer cette demande comme traitée ?")) return;
    await supabase.from("demandes_suppression").update({ statut: "traitee", traitee_at: new Date().toISOString() }).eq("id", id);
    load();
  }

  const enAttente = items.filter(i => i.statut !== "traitee");
  const traitees = items.filter(i => i.statut === "traitee");

  if (loading) return <div style={{ textAlign: "center", color: "var(--c-text-muted)", fontSize: 13 }}>Chargement…</div>;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ background: "var(--c-warning-bg)", border: "1px solid var(--c-warning-border-soft)", borderRadius: 12, padding: 12, fontSize: 12, color: "var(--c-warning-text)", lineHeight: 1.5 }}>
        Ces demandes ne suppriment rien automatiquement. Pour chaque demande, va supprimer manuellement le compte (Supabase → Authentication) et les données associées (device_id ou email), puis marque la demande comme traitée. Délai légal engagé : 30 jours maximum depuis la demande.
      </div>

      <div>
        <div style={{ fontSize: 11.5, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>En attente ({enAttente.length})</div>
        {enAttente.length === 0 && <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 12 }}>Aucune demande en attente.</div>}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {enAttente.map(d => (
            <div key={d.id} style={{ background: "var(--c-surface)", borderRadius: 12, padding: 12, border: "1px solid var(--c-border)", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{d.email || `Appareil ${(d.device_id || "").slice(0, 8)}`}</div>
                {d.motif && <div style={{ fontSize: 11.5, color: "var(--c-text-secondary)" }}>{d.motif}</div>}
                <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 2 }}>Demandé le {new Date(d.created_at).toLocaleDateString("fr-FR")}</div>
              </div>
              <button onClick={() => marquerTraitee(d.id)} style={{ background: "var(--c-accent-dark)", border: "none", color: "#fff", fontSize: 11.5, fontWeight: 600, borderRadius: 8, padding: "7px 10px", cursor: "pointer", whiteSpace: "nowrap" }}>Marquer traitée</button>
            </div>
          ))}
        </div>
      </div>

      {traitees.length > 0 && (
        <div>
          <div style={{ fontSize: 11.5, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Traitées ({traitees.length})</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {traitees.map(d => (
              <div key={d.id} style={{ background: "var(--c-surface-soft)", borderRadius: 12, padding: 12, border: "1px solid var(--c-border)", opacity: 0.7 }}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{d.email || `Appareil ${(d.device_id || "").slice(0, 8)}`}</div>
                <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 2 }}>Traitée le {new Date(d.traitee_at).toLocaleDateString("fr-FR")}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

