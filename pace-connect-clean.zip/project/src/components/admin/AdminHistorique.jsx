import { useEffect, useState } from 'react';
import { CATEGORIES } from '../../constants/categories';
import { logActivity } from '../../lib/activity';
import { supabase } from '../../lib/supabaseClient';

export const ACTION_LABELS = {
  decision: "a ajouté une mise à jour terrain",
  resolution: "a marqué résolu",
  reouverture: "a remis en attente",
  validation: "a validé",
  suppression: "a supprimé",
  suspension: "a suspendu",
  rejet: "a rejeté",
  soft_delete: "a mis à la corbeille",
  restauration: "a restauré",
  suppression_definitive: "a supprimé définitivement",
};


export function AdminHistorique() {
  const [logs, setLogs] = useState(null);
  const [corbeille, setCorbeille] = useState(null);
  const [vue, setVue] = useState("journal"); // journal | corbeille

  async function loadLogs() {
    const { data } = await supabase.from("activity_log").select("*").order("created_at", { ascending: false }).limit(100);
    setLogs(data || []);
  }
  async function loadCorbeille() {
    const [{ data: s }, { data: a }, { data: b }] = await Promise.all([
      supabase.from("signalements").select("*").eq("is_deleted", true).order("deleted_at", { ascending: false }),
      supabase.from("arbres").select("*").eq("is_deleted", true).order("deleted_at", { ascending: false }),
      supabase.from("benevoles").select("*").eq("is_deleted", true).order("deleted_at", { ascending: false }),
    ]);
    setCorbeille({ signalements: s || [], arbres: a || [], benevoles: b || [] });
  }
  useEffect(() => { loadLogs(); loadCorbeille(); }, []);

  function nomDe(table, item) {
    if (table === "signalements") { const cat = CATEGORIES.find(c => c.id === item.categorie); return cat ? cat.label : item.categorie; }
    if (table === "arbres") return item.nom || "Arbre";
    if (table === "benevoles") return item.nom;
    return "élément";
  }

  async function restaurer(table, item) {
    const nom = nomDe(table, item);
    const { data, error } = await supabase.from(table).update({ is_deleted: false, deleted_at: null, deleted_by: null }).eq("id", item.id).select();
    if (error || !data || data.length === 0) { alert("Action refusée par le serveur (droits admin requis)."); return; }
    logActivity("restauration", table, item.id, nom);
    loadCorbeille(); loadLogs();
  }

  async function supprimerDefinitivement(table, item) {
    const nom = nomDe(table, item);
    if (!confirm(`Supprimer définitivement "${nom}" ? Cette action est irréversible.`)) return;
    if (!confirm("Confirme une seconde fois : il n'y a aucun moyen de revenir en arrière après ça.")) return;
    const { error } = await supabase.from(table).delete().eq("id", item.id);
    if (error) { alert("Échec de la suppression : " + error.message); return; }
    logActivity("suppression_definitive", table, item.id, nom);
    loadCorbeille(); loadLogs();
  }

  const totalCorbeille = corbeille ? corbeille.signalements.length + corbeille.arbres.length + corbeille.benevoles.length : 0;

  function CorbeilleSection({ titre, table, items }) {
    if (items.length === 0) return null;
    return (
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--c-text-muted)", textTransform: "uppercase", letterSpacing: 0.4, margin: "10px 0 6px" }}>{titre} ({items.length})</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {items.map(item => (
            <div key={item.id} style={{ background: "var(--c-surface)", borderRadius: 12, padding: 12, border: "1px solid var(--c-border)" }}>
              <div style={{ fontWeight: 600, fontSize: 13, color: "var(--c-text)" }}>{nomDe(table, item)}</div>
              <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 3 }}>Supprimé par {item.deleted_by || "?"} le {new Date(item.deleted_at).toLocaleDateString("fr-FR")}</div>
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button onClick={() => restaurer(table, item)} style={{ fontSize: 11.5, padding: "6px 12px", borderRadius: 8, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, cursor: "pointer" }}>Restaurer</button>
                <button onClick={() => supprimerDefinitivement(table, item)} style={{ fontSize: 11.5, padding: "6px 12px", borderRadius: 8, border: "1px solid #B5451B", background: "var(--c-danger-border-soft)", color: "#B5451B", fontWeight: 600, cursor: "pointer" }}>Supprimer définitivement</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ display: "flex", gap: 6, marginBottom: 4 }}>
        {[["journal", "Journal"], ["corbeille", `Éléments supprimés${corbeille ? ` (${totalCorbeille})` : ""}`]].map(([id, label]) => (
          <button key={id} onClick={() => setVue(id)} style={{
            padding: "6px 12px", borderRadius: 20, fontSize: 11.5, fontWeight: 600, cursor: "pointer",
            border: vue === id ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
            background: vue === id ? "var(--c-accent-dark)" : "var(--c-surface)", color: vue === id ? "#fff" : "var(--c-text-secondary)" }}>{label}</button>
        ))}
      </div>

      {vue === "journal" && (
        logs === null ? <div style={{ textAlign: "center", color: "var(--c-text-muted)", fontSize: 13 }}>Chargement…</div> :
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontSize: 11.5, color: "var(--c-text-muted)", marginBottom: 4 }}>Les 100 dernières actions de l'équipe.</div>
          {logs.length === 0 && <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 20 }}>Aucune action enregistrée pour l'instant.</div>}
          {logs.map(l => (
            <div key={l.id} style={{ background: "var(--c-surface)", borderRadius: 10, padding: "10px 12px", border: "1px solid var(--c-border)", fontSize: 12.5 }}>
              <span style={{ fontWeight: 600, color: "var(--c-text)" }}>{l.acteur}</span>{" "}
              <span style={{ color: "var(--c-text-secondary)" }}>{ACTION_LABELS[l.action] || l.action}</span>{" "}
              <span style={{ color: "var(--c-text-secondary)" }}>{l.cible_table}</span>
              {l.detail && <span style={{ color: "var(--c-text-muted)" }}> — {l.detail}</span>}
              <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 3 }}>
                {new Date(l.created_at).toLocaleDateString("fr-FR")} à {new Date(l.created_at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
              </div>
            </div>
          ))}
        </div>
      )}

      {vue === "corbeille" && (
        corbeille === null ? <div style={{ textAlign: "center", color: "var(--c-text-muted)", fontSize: 13 }}>Chargement…</div> :
        totalCorbeille === 0 ? <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 20 }}>Corbeille vide.</div> :
        <div>
          <div style={{ fontSize: 11.5, color: "var(--c-text-muted)", marginBottom: 4 }}>
            Les éléments supprimés restent ici jusqu'à restauration ou suppression définitive.
          </div>
          <CorbeilleSection titre="Signalements" table="signalements" items={corbeille.signalements} />
          <CorbeilleSection titre="Arbres" table="arbres" items={corbeille.arbres} />
          <CorbeilleSection titre="Bénévoles" table="benevoles" items={corbeille.benevoles} />
        </div>
      )}
    </div>
  );
}

