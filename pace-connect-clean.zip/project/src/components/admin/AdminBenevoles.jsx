import { useEffect, useState } from 'react';
import { IconTrash } from '../icons/index';
import { logActivity } from '../../lib/activity';
import { currentSession, supabase } from '../../lib/supabaseClient';

export function AdminBenevoles() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filtre, setFiltre] = useState("en_attente");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("benevoles").select("*").eq("is_deleted", false).order("created_at", { ascending: false });
    setItems(data || []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function remove(b) {
    if (!confirm(`Mettre "${b.nom}" à la corbeille ? Il sera restaurable depuis Historique.`)) return;
    const email = currentSession && currentSession.user ? currentSession.user.email : "";
    const { error } = await supabase.from("benevoles").update({ is_deleted: true, deleted_at: new Date().toISOString(), deleted_by: email }).eq("id", b.id);
    if (error) { alert("Action refusée par le serveur (droits admin requis)."); return; }
    logActivity("soft_delete", "benevoles", b.id, b.nom);
    load();
  }

  async function setStatut(b, statut, action) {
    const { error } = await supabase.from("benevoles").update({ statut }).eq("id", b.id);
    if (error) { alert("Action refusée par le serveur (droits admin requis)."); return; }
    logActivity(action, "benevoles", b.id, b.nom);
    load();
  }

  const STATUT_LABELS = { en_attente: "En attente", valide: "Validé", suspendu: "Suspendu", rejete: "Rejeté" };
  const STATUT_COLORS = { en_attente: "var(--c-warning)", valide: "var(--c-accent)", suspendu: "#B5451B", rejete: "var(--c-text-muted)" };

  if (loading) return <div style={{ textAlign: "center", color: "var(--c-text-muted)", fontSize: 13 }}>Chargement…</div>;

  const filtered = filtre === "tous" ? items : items.filter(b => (b.statut || "valide") === filtre);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ fontSize: 11.5, color: "var(--c-text-muted)", marginBottom: 4 }}>
        Un bénévole n'a accès au contenu de PACE Connect qu'après validation ici.
      </div>
      <div style={{ display: "flex", gap: 6, marginBottom: 4, flexWrap: "wrap" }}>
        {[["en_attente", "En attente"], ["valide", "Validés"], ["suspendu", "Suspendus"], ["rejete", "Rejetés"], ["tous", "Tous"]].map(([id, label]) => (
          <button key={id} onClick={() => setFiltre(id)} style={{
            padding: "6px 12px", borderRadius: 20, fontSize: 11.5, fontWeight: 600, cursor: "pointer",
            border: filtre === id ? "1px solid var(--c-accent-dark)" : "1px solid var(--c-border)",
            background: filtre === id ? "var(--c-accent-dark)" : "var(--c-surface)", color: filtre === id ? "#fff" : "var(--c-text-secondary)" }}>{label}</button>
        ))}
      </div>
      <div style={{ fontSize: 11.5, color: "var(--c-text-muted)", marginBottom: 4 }}>{filtered.length} bénévole{filtered.length > 1 ? "s" : ""}</div>
      {filtered.length === 0 && <div style={{ color: "var(--c-text-muted)", fontSize: 13, textAlign: "center", padding: 12 }}>Aucune inscription dans cette catégorie.</div>}
      {filtered.map(b => {
        const statut = b.statut || "valide";
        return (
          <div key={b.id} style={{ background: "var(--c-surface)", borderRadius: 12, padding: 12, border: "1px solid var(--c-border)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{b.nom}</div>
                <div style={{ fontSize: 11.5, color: "var(--c-text-secondary)" }}>{b.contact}</div>
                <div style={{ fontSize: 11.5, color: "var(--c-text-secondary)" }}>{[b.ville, b.pays, b.zone].filter(Boolean).join(" · ")}</div>
                <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 2 }}>Inscrit le {new Date(b.created_at).toLocaleDateString("fr-FR")}</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
                <span style={{ fontSize: 10.5, fontWeight: 600, color: STATUT_COLORS[statut], border: `1px solid ${STATUT_COLORS[statut]}`, borderRadius: 20, padding: "3px 8px" }}>{STATUT_LABELS[statut]}</span>
                <button onClick={() => remove(b)} style={{ background: "none", border: "none", color: "#B5451B", cursor: "pointer", padding: 4 }}><IconTrash size={16} /></button>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
              {statut !== "valide" && (
                <button onClick={() => setStatut(b, "valide", "validation")} style={{ fontSize: 11.5, padding: "6px 12px", borderRadius: 8, border: "none", background: "var(--c-accent-dark)", color: "#fff", fontWeight: 600, cursor: "pointer" }}>Valider</button>
              )}
              {statut === "valide" && (
                <button onClick={() => setStatut(b, "suspendu", "suspension")} style={{ fontSize: 11.5, padding: "6px 12px", borderRadius: 8, border: "1px solid #B5451B", background: "var(--c-danger-border-soft)", color: "#B5451B", fontWeight: 600, cursor: "pointer" }}>Suspendre</button>
              )}
              {statut !== "rejete" && (
                <button onClick={() => setStatut(b, "rejete", "rejet")} style={{ fontSize: 11.5, padding: "6px 12px", borderRadius: 8, border: "1px solid var(--c-border)", background: "var(--c-surface)", color: "var(--c-text-secondary)", fontWeight: 600, cursor: "pointer" }}>Rejeter</button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

