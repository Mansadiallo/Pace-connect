import { useEffect, useState } from 'react';
import { IconCloudRain, IconSun } from './icons/index';
import { t } from '../i18n/index';

export function ClimatWidget({ lang }) {
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!navigator.geolocation) { setError(true); return; }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,precipitation,weather_code,wind_speed_10m&timezone=auto`;
          const res = await fetch(url);
          const data = await res.json();
          setWeather(data.current);
        } catch (e) { setError(true); }
      },
      () => setError(true),
      { timeout: 6000 }
    );
  }, []);

  if (error || !weather) return null;

  const code = weather.weather_code;
  const isRain = code >= 51 && code <= 82;
  const isHeat = weather.temperature_2m >= 34;
  const WIcon = isRain ? IconCloudRain : IconSun;
  const alert = isRain ? t(lang, "alerte_pluie") : isHeat ? t(lang, "alerte_chaleur") : null;

  return (
    <div style={{ background: "linear-gradient(120deg,var(--c-accent-dark),var(--c-sky))", borderRadius: 14, padding: 14, marginBottom: 16, color: "#fff" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 11, opacity: 0.8 }}>{t(lang, "meteo_locale")}</div>
          <div style={{ fontFamily: "IBM Plex Mono, monospace", fontSize: 26, fontWeight: 700 }}>{Math.round(weather.temperature_2m)}°C</div>
        </div>
        <WIcon size={30} color="#fff" />
      </div>
      {alert && (
        <div style={{ marginTop: 8, fontSize: 11.5, background: "rgba(255,255,255,0.15)", borderRadius: 8, padding: "6px 10px" }}>
          ⚠ {alert}
        </div>
      )}
    </div>
  );
}

