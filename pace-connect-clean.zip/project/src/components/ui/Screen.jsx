export function Screen({ children }) { return <div style={{ padding: "16px 16px 90px" }}>{children}</div>; }

