import { LOGO_DATA_URL } from '../../constants/branding';

export function SplashScreen() {
  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 30000,
      background: "linear-gradient(160deg,#007A3D,#0077B6)",
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
    }}>
      <div className="pace-scale-in" style={{
        width: 96, height: 96, borderRadius: "50%", background: "#fff",
        display: "flex", alignItems: "center", justifyContent: "center",
        boxShadow: "0 12px 40px rgba(0,0,0,0.25)", overflow: "hidden", marginBottom: 18,
      }}>
        <img src={LOGO_DATA_URL} alt="Logo PACE Connect" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </div>
      <div className="pace-fade-in" style={{ fontFamily: "Fraunces, serif", fontWeight: 700, fontSize: 24, color: "#fff", letterSpacing: 0.4 }}>
        PACE Connect
      </div>
      <div className="pace-fade-in" style={{ fontSize: 12, color: "rgba(255,255,255,0.85)", marginTop: 4 }}>
        Ensemble pour un avenir durable
      </div>
    </div>
  );
}

