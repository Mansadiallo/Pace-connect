import { useState } from 'react';

export function ConfirmActionModal({ title, description, reasonLabel, confirmLabel, confirmColor, danger, showDuration, motifOptions, onConfirm, onCancel }) {
  const [reason, setReason] = useState("");
  const [motif, setMotif] = useState(motifOptions ? motifOptions[0].id : "");
  const [duration, setDuration] = useState("7");
  const [customDate, setCustomDate] = useState("");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(1); // double confirmation : 1 = formulaire, 2 = confirmation finale

  const reasonOk = reason.trim().length >= 5;

  function computeJusqua() {
    if (!showDuration) return null;
    if (duration === "indetermine") return null;
    if (duration === "custom") return customDate ? new Date(customDate).toISOString() : null;
    const days = parseInt(duration, 10);
    const d = new Date(); d.setDate(d.getDate() + days);
    return d.toISOString();
  }

  async function handleFinalConfirm() {
    setBusy(true);
    await onConfirm({ reason: reason.trim(), motif: motifOptions ? motif : null, jusqua: computeJusqua() });
    setBusy(false);
  }

  return (
    <div role="dialog" aria-label={title} style={{ position: "fixed", inset: 0, zIndex: 26000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <button aria-label="Fermer" onClick={onCancel} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.4)", border: "none", cursor: "pointer" }} />
      <div className="pace-fade-in" style={{ position: "relative", width: "100%", maxWidth: 480, background: "var(--c-surface)", borderRadius: "20px 20px 0 0", padding: 20, maxHeight: "88vh", overflowY: "auto" }}>
        {step === 1 ? (
          <>
            <div style={{ fontFamily: "Fraunces, serif", fontSize: 16, fontWeight: 600, color: danger ? "#B5451B" : "var(--c-accent-dark)", marginBottom: 6 }}>{title}</div>
            {description && <div style={{ fontSize: 12.5, color: "var(--c-text-secondary)", marginBottom: 14, lineHeight: 1.5 }}>{description}</div>}

            {motifOptions && (
              <>
                <div style={{ fontSize: 11.5, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 6 }}>Motif</div>
                <select value={motif} onChange={e => setMotif(e.target.value)} style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 12, boxSizing: "border-box" }}>
                  {motifOptions.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
                </select>
              </>
            )}

            {showDuration && (
              <>
                <div style={{ fontSize: 11.5, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 6 }}>Durée</div>
                <select value={duration} onChange={e => setDuration(e.target.value)} style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }}>
                  <option value="7">7 jours</option>
                  <option value="30">30 jours</option>
                  <option value="custom">Date précise…</option>
                  <option value="indetermine">Indéterminée</option>
                </select>
                {duration === "custom" && (
                  <input type="date" value={customDate} onChange={e => setCustomDate(e.target.value)}
                    style={{ width: "100%", padding: 9, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 12, boxSizing: "border-box" }} />
                )}
              </>
            )}

            <div style={{ fontSize: 11.5, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 6 }}>{reasonLabel || "Motif de l'action (obligatoire)"}</div>
            <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3} placeholder="Explique la raison de cette action…"
              style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid var(--c-border)", fontSize: 13, marginBottom: 6, boxSizing: "border-box", resize: "none", fontFamily: "Work Sans, sans-serif" }} />
            {!reasonOk && reason.length > 0 && <div style={{ fontSize: 11, color: "#B5451B", marginBottom: 8 }}>Précise un peu plus (5 caractères minimum).</div>}

            <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
              <button type="button" onClick={onCancel} style={{ flex: 1, padding: "11px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", fontSize: 13, color: "var(--c-text)" }}>Annuler</button>
              <button type="button" disabled={!reasonOk} onClick={() => setStep(2)} style={{
                flex: 1, padding: "11px 0", borderRadius: 10, border: "none", cursor: reasonOk ? "pointer" : "default",
                background: !reasonOk ? "var(--c-text-faint)" : (confirmColor || "var(--c-accent-dark)"), color: "#fff", fontWeight: 600, fontSize: 13 }}>
                Continuer
              </button>
            </div>
          </>
        ) : (
          <>
            <div style={{ fontFamily: "Fraunces, serif", fontSize: 16, fontWeight: 600, color: "#B5451B", marginBottom: 10 }}>Confirmer définitivement ?</div>
            <div style={{ fontSize: 13, color: "var(--c-text-secondary)", lineHeight: 1.6, marginBottom: 4 }}>
              {confirmLabel || "Cette action"} — motif : « {reason.trim()} »
            </div>
            <div style={{ fontSize: 12, color: "var(--c-text-muted)", marginBottom: 16 }}>Cette action sera enregistrée dans le journal d'audit avec ton identité et l'horodatage.</div>
            <div style={{ display: "flex", gap: 8 }}>
              <button type="button" onClick={() => setStep(1)} style={{ flex: 1, padding: "11px 0", borderRadius: 10, border: "1px solid var(--c-border)", background: "var(--c-surface)", cursor: "pointer", fontSize: 13, color: "var(--c-text)" }}>Retour</button>
              <button type="button" disabled={busy} onClick={handleFinalConfirm} style={{
                flex: 1, padding: "11px 0", borderRadius: 10, border: "none", background: "#B5451B", color: "#fff", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
                {busy ? "..." : "Confirmer"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

