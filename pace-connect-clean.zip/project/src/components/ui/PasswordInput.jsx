import { useState } from 'react';
import { IconEye, IconEyeOff } from '../icons/index';

export function PasswordInput({ value, onChange, placeholder, ariaLabel, style }) {
  const [visible, setVisible] = useState(false);
  return (
    <div style={{ position: "relative", width: "100%" }}>
      <input type={visible ? "text" : "password"} value={value} onChange={onChange} placeholder={placeholder} aria-label={ariaLabel || placeholder}
        style={{ ...style, width: "100%", paddingRight: 40, boxSizing: "border-box" }} />
      <button type="button" onClick={() => setVisible(!visible)} aria-label={visible ? "Masquer le mot de passe" : "Afficher le mot de passe"} style={{
        position: "absolute", right: 4, top: "50%", transform: "translateY(-50%)", background: "none", border: "none",
        cursor: "pointer", color: "var(--c-text-muted)", padding: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
        {visible ? <IconEyeOff size={16} /> : <IconEye size={16} />}
      </button>
    </div>
  );
}

