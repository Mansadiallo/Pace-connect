import { useEffect, useState } from 'react';
import { IconBell } from '../icons/index';
import { t } from '../../i18n/index';
import { supabase } from '../../lib/supabaseClient';

export function NotifBell({ email, onNavigate }) {
  const [open, setOpen] = useState(false);
  const [notifs, setNotifs] = useState([]);

  async function load() {
    const { data } = await supabase.from("notifications").select("*").eq("destinataire", email).order("created_at", { ascending: false }).limit(30);
    setNotifs(data || []);
  }
  useEffect(() => { load(); const t = setInterval(load, 60000); return () => clearInterval(t); }, [email]);

  const unread = notifs.filter(n => !n.lu).length;

  async function openPanel() {
    setOpen(!open);
    if (!open && unread > 0) {
      const ids = notifs.filter(n => !n.lu).map(n => n.id);
      setNotifs(prev => prev.map(n => ({ ...n, lu: true })));
      for (const id of ids) supabase.from("notifications").update({ lu: true }).eq("id", id).then(() => {});
    }
  }

  return (
    <div style={{ position: "relative" }}>
      <button onClick={openPanel} style={{ background: "none", border: "none", color: "var(--c-text-muted)", cursor: "pointer", padding: 6, position: "relative" }}>
        <IconBell size={18} />
        {unread > 0 && <span style={{ position: "absolute", top: 2, right: 2, background: "#B5451B", color: "#fff", fontSize: 9, fontWeight: 700, borderRadius: "50%", width: 15, height: 15, display: "flex", alignItems: "center", justifyContent: "center" }}>{unread > 9 ? "9+" : unread}</span>}
      </button>
      {open && (
        <div style={{ position: "absolute", top: 34, right: 0, width: 260, background: "var(--c-surface)", borderRadius: 12, border: "1px solid var(--c-border)", boxShadow: "0 6px 20px rgba(0,0,0,0.15)", zIndex: 100, maxHeight: 320, overflowY: "auto" }}>
          {notifs.length === 0 ? (
            <div style={{ padding: 16, fontSize: 12.5, color: "var(--c-text-muted)", textAlign: "center" }}>Aucune notification.</div>
          ) : notifs.map(n => (
            <button key={n.id} onClick={() => { if (n.lien) onNavigate(n.lien); setOpen(false); }} style={{
              display: "block", width: "100%", textAlign: "left", padding: "10px 12px", border: "none", borderBottom: "1px solid var(--c-surface-soft)",
              background: "var(--c-surface)", cursor: "pointer" }}>
              <div style={{ fontSize: 12, color: "var(--c-text)" }}>{n.message}</div>
              <div style={{ fontSize: 10, color: "var(--c-text-muted)", marginTop: 3 }}>{new Date(n.created_at).toLocaleDateString("fr-FR")}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

