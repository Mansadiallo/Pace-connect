import { IconMonitor, IconMoon, IconSun } from '../icons/index';

export function ThemePanel({ themeMode, accent, lang, onSetMode, onSetAccent, onSetLang, onClose }) {
  const modes = [
    { id: "light", label: "Clair", icon: IconSun },
    { id: "dark", label: "Sombre", icon: IconMoon },
    { id: "system", label: "Auto", icon: IconMonitor },
  ];
  const accents = [
    { id: "green", label: "Vert", color: "#4CAF50" },
    { id: "blue", label: "Bleu", color: "#2E6E86" },
    { id: "gold", label: "Doré", color: "#8A6318" },
  ];
  const langues = [
    { id: "fr", label: "Français" },
    { id: "en", label: "English" },
    { id: "pt", label: "Português" },
    { id: "es", label: "Español" },
    { id: "sw", label: "Kiswahili" },
    { id: "ar", label: "العربية" },
  ];
  return (
    <div role="dialog" aria-label="Réglages d'affichage" style={{ position: "fixed", inset: 0, zIndex: 25000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <button aria-label="Fermer les réglages" onClick={onClose} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.35)", border: "none", cursor: "pointer" }} />
      <div className="pace-fade-in" style={{ position: "relative", width: "100%", maxWidth: 480, background: "var(--c-surface)", borderRadius: "20px 20px 0 0", padding: 20, boxShadow: "var(--shadow-md)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ fontFamily: "Fraunces, serif", fontSize: 17, fontWeight: 600, color: "var(--c-accent-dark)" }}>Affichage</div>
          <button onClick={onClose} aria-label="Fermer" style={{ background: "var(--c-surface-soft)", border: "none", borderRadius: "50%", width: 32, height: 32, cursor: "pointer", color: "var(--c-text-secondary)" }}>✕</button>
        </div>

        <div style={{ fontSize: 12, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Thème</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 20 }}>
          {modes.map(m => {
            const MIcon = m.icon;
            const active = themeMode === m.id;
            return (
              <button key={m.id} onClick={() => onSetMode(m.id)} aria-pressed={active} style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: 6, padding: "12px 0", borderRadius: 12,
                border: active ? "2px solid var(--c-accent)" : "1px solid var(--c-border)",
                background: active ? "var(--c-surface-soft)" : "var(--c-surface)", cursor: "pointer" }}>
                <MIcon size={18} color={active ? "var(--c-accent)" : "var(--c-text-muted)"} />
                <span style={{ fontSize: 11.5, fontWeight: 600, color: active ? "var(--c-accent)" : "var(--c-text-secondary)" }}>{m.label}</span>
              </button>
            );
          })}
        </div>

        <div style={{ fontSize: 12, fontWeight: 600, color: "var(--c-text-secondary)", marginBottom: 8 }}>Couleur d'accent</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
          {accents.map(a => {
            const active = accent === a.id;
            return (
              <button key={a.id} onClick={() => onSetAccent(a.id)} aria-pressed={active} style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: 6, padding: "12px 0", borderRadius: 12,
                border: active ? `2px solid ${a.color}` : "1px solid var(--c-border)",
                background: active ? "var(--c-surface-soft)" : "var(--c-surface)", cursor: "pointer" }}>
                <span style={{ width: 20, height: 20, borderRadius: "50%", background: a.color, display: "block" }} />
                <span style={{ fontSize: 11.5, fontWeight: 600, color: "var(--c-text-secondary)" }}>{a.label}</span>
              </button>
            );
          })}
        </div>

        <div style={{ fontSize: 12, fontWeight: 600, color: "var(--c-text-secondary)", marginTop: 20, marginBottom: 8 }}>Langue / Language</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          {langues.map(l => {
            const active = lang === l.id;
            return (
              <button key={l.id} onClick={() => onSetLang(l.id)} aria-pressed={active} style={{
                padding: "12px 0", borderRadius: 12, fontSize: 12.5, fontWeight: 600,
                border: active ? "2px solid var(--c-accent)" : "1px solid var(--c-border)",
                background: active ? "var(--c-surface-soft)" : "var(--c-surface)", color: active ? "var(--c-accent)" : "var(--c-text-secondary)", cursor: "pointer" }}>
                {l.label}
              </button>
            );
          })}
        </div>
        <div style={{ fontSize: 10.5, color: "var(--c-text-muted)", marginTop: 8, lineHeight: 1.5 }}>
          La navigation principale et les titres changent de langue immédiatement. La traduction complète du contenu est en cours.
        </div>
      </div>
    </div>
  );
}

