export function StatCard({ label, value, unit, accent }) {
  return (
    <div style={{ background: "var(--c-surface)", borderRadius: 14, padding: "12px 14px", flex: 1, border: "1px solid var(--c-border)" }}>
      <div style={{ fontFamily: "IBM Plex Mono, monospace", fontSize: 22, fontWeight: 600, color: accent || "var(--c-accent-dark)" }}>
        {value}<span style={{ fontSize: 12, marginLeft: 3, color: "var(--c-text-muted)" }}>{unit}</span>
      </div>
      <div style={{ fontSize: 11.5, color: "var(--c-text-secondary)", marginTop: 2, lineHeight: 1.3 }}>{label}</div>
    </div>
  );
}

