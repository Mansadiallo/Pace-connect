export function SectionTitle({ children, sub }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontFamily: "Fraunces, serif", fontSize: 22, fontWeight: 600, color: "var(--c-accent-dark)" }}>{children}</div>
      {sub && <div style={{ fontSize: 13, color: "var(--c-text-secondary)", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

