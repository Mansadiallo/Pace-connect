export function MiniBarChart({ data, color, label }) {
  const max = Math.max(1, ...data.map(d => d.count));
  return (
    <div style={{ background: "var(--c-surface)", borderRadius: 14, padding: 14, border: "1px solid var(--c-border)", marginBottom: 12 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: "var(--c-text)", marginBottom: 10 }}>{label}</div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 70 }}>
        {data.map((d, i) => (
          <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", height: "100%" }}>
            <div style={{ width: "100%", background: color, borderRadius: 3, height: `${Math.max(4, (d.count / max) * 100)}%`, opacity: d.week === 0 ? 1 : 0.65 }} title={`${d.count}`} />
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
        {data.map((d, i) => (
          <div key={i} style={{ flex: 1, textAlign: "center", fontSize: 8.5, color: "var(--c-text-muted)" }}>{d.week === 0 ? "cette sem." : `-${d.week}`}</div>
        ))}
      </div>
    </div>
  );
}

