import { TRANSLATIONS } from './translations';

export const RTL_LANGS = ["ar"];
// N'ko (écriture ߒߞߏ, langues mandingues) : infrastructure prête (voir langues disponibles dans le
// sélecteur de réglages et RTL_LANGS ci-dessus si activé), mais les traductions ne sont volontairement
// PAS incluses ici — une traduction automatique non vérifiée par un locuteur natif risquerait d'induire
// les citoyens en erreur sur un outil à vocation civique. Pour l'activer : ajouter une clé "nko" ci-dessus
// avec les mêmes clés que "fr", ajouter "nko" à RTL_LANGS (le n'ko s'écrit de droite à gauche), et
// l'ajouter à la liste `langues` dans ThemePanel.


export function t(lang, key) {
  return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || TRANSLATIONS.fr[key] || key;
}

// --- Point 1 : estimation du CO2 selon l'âge de l'arbre plutôt qu'une constante fixe.
// Approximation : ~6 kg/an la 1ère année (jeune plant), puis ~21 kg/an en rythme de croisière une fois établi.

