import { IconAlert, IconDroplet, IconFish, IconFlame, IconFlask, IconGlobe, IconHome, IconLayers, IconPaw, IconPick, IconSprout, IconSun, IconTrash, IconTree, IconWaves, IconWind } from '../components/icons/index';

export const CATEGORIES = [
  { id: "decharge", label: "Décharge sauvage", icon: IconTrash },
  { id: "pollution", label: "Pollution des cours d'eau", icon: IconDroplet },
  { id: "deforestation", label: "Déforestation", icon: IconTree },
  { id: "feu", label: "Feu de brousse", icon: IconFlame },
  { id: "mine", label: "Exploitation minière illégale", icon: IconPick },
  { id: "deversement", label: "Déversement polluant", icon: IconAlert },
  { id: "braconnage", label: "Braconnage", icon: IconPaw },
  { id: "peche_illegale", label: "Pêche illégale", icon: IconFish },
  { id: "pollution_air", label: "Pollution de l'air / fumées toxiques", icon: IconWind },
  { id: "extraction_sable", label: "Extraction de sable illégale", icon: IconLayers },
  { id: "zones_humides", label: "Destruction de zones humides / mangroves", icon: IconWaves },
  { id: "dechets_dangereux", label: "Déchets médicaux ou dangereux", icon: IconFlask },
  { id: "construction_illegale", label: "Construction illégale en zone protégée", icon: IconHome },
  { id: "assechement", label: "Assèchement d'un point d'eau", icon: IconSun },
  { id: "espece_envahissante", label: "Espèce envahissante", icon: IconSprout },
  { id: "erosion", label: "Érosion des sols / désertification", icon: IconGlobe },
];

// Libellés des catégories de signalement et niveaux d'urgence par langue, indexés par id (le tableau FR reste la source de vérité pour id/icône).


export const CATEGORIES_LABELS = {
  en: {
    decharge: "Illegal dump", pollution: "Water pollution", deforestation: "Deforestation", feu: "Bush fire",
    mine: "Illegal mining", deversement: "Pollutant spill", braconnage: "Poaching", peche_illegale: "Illegal fishing",
    pollution_air: "Air pollution / toxic fumes", extraction_sable: "Illegal sand extraction",
    zones_humides: "Wetland / mangrove destruction", dechets_dangereux: "Medical or hazardous waste",
    construction_illegale: "Illegal construction in protected area", assechement: "Water point drying up",
    espece_envahissante: "Invasive species", erosion: "Soil erosion / desertification",
  },
  pt: {
    decharge: "Lixeira ilegal", pollution: "Poluição de cursos de água", deforestation: "Desflorestação", feu: "Incêndio florestal",
    mine: "Mineração ilegal", deversement: "Derrame poluente", braconnage: "Caça furtiva", peche_illegale: "Pesca ilegal",
    pollution_air: "Poluição do ar / fumos tóxicos", extraction_sable: "Extração ilegal de areia",
    zones_humides: "Destruição de zonas húmidas / mangais", dechets_dangereux: "Resíduos médicos ou perigosos",
    construction_illegale: "Construção ilegal em área protegida", assechement: "Secagem de um ponto de água",
    espece_envahissante: "Espécie invasora", erosion: "Erosão do solo / desertificação",
  },
  es: {
    decharge: "Vertedero ilegal", pollution: "Contaminación de cursos de agua", deforestation: "Deforestación", feu: "Incendio forestal",
    mine: "Minería ilegal", deversement: "Derrame contaminante", braconnage: "Caza furtiva", peche_illegale: "Pesca ilegal",
    pollution_air: "Contaminación del aire / humos tóxicos", extraction_sable: "Extracción ilegal de arena",
    zones_humides: "Destrucción de humedales / manglares", dechets_dangereux: "Residuos médicos o peligrosos",
    construction_illegale: "Construcción ilegal en área protegida", assechement: "Secado de un punto de agua",
    espece_envahissante: "Especie invasora", erosion: "Erosión del suelo / desertificación",
  },
  sw: {
    decharge: "Dampo haramu", pollution: "Uchafuzi wa vyanzo vya maji", deforestation: "Ukataji miti", feu: "Moto wa nyika",
    mine: "Uchimbaji haramu", deversement: "Umwagikaji wa uchafuzi", braconnage: "Ujangili", peche_illegale: "Uvuvi haramu",
    pollution_air: "Uchafuzi wa hewa / moshi wenye sumu", extraction_sable: "Uchimbaji haramu wa mchanga",
    zones_humides: "Uharibifu wa ardhioevu / mikoko", dechets_dangereux: "Taka za hospitali au hatari",
    construction_illegale: "Ujenzi haramu katika eneo lililohifadhiwa", assechement: "Kukauka kwa chanzo cha maji",
    espece_envahissante: "Spishi vamizi", erosion: "Mmomonyoko wa udongo / jangwa",
  },
  ar: {
    decharge: "مكب نفايات عشوائي", pollution: "تلوث المجاري المائية", deforestation: "إزالة الغابات", feu: "حريق أدغال",
    mine: "تعدين غير قانوني", deversement: "تسرب ملوّث", braconnage: "صيد جائر", peche_illegale: "صيد غير قانوني",
    pollution_air: "تلوث الهواء / أدخنة سامة", extraction_sable: "استخراج رمل غير قانوني",
    zones_humides: "تدمير الأراضي الرطبة / أشجار المانغروف", dechets_dangereux: "نفايات طبية أو خطرة",
    construction_illegale: "بناء غير قانوني في منطقة محمية", assechement: "جفاف مصدر مياه",
    espece_envahissante: "نوع غازٍ", erosion: "تآكل التربة / التصحر",
  },
};


export const URGENCE_LABELS = {
  en: { faible: "Low", moyenne: "Medium", haute: "High" },
  pt: { faible: "Baixa", moyenne: "Média", haute: "Alta" },
  es: { faible: "Baja", moyenne: "Media", haute: "Alta" },
  sw: { faible: "Chini", moyenne: "Wastani", haute: "Juu" },
  ar: { faible: "منخفضة", moyenne: "متوسطة", haute: "مرتفعة" },
};


export function categorieLabel(lang, id) {
  const cat = CATEGORIES.find(c => c.id === id);
  if (!cat) return id;
  return (CATEGORIES_LABELS[lang] && CATEGORIES_LABELS[lang][id]) || cat.label;
}


export function urgenceLabel(lang, id) {
  const u = URGENCE.find(x => x.id === id);
  if (!u) return id;
  return (URGENCE_LABELS[lang] && URGENCE_LABELS[lang][id]) || u.label;
}


export const URGENCE = [
  { id: "faible", label: "Faible", color: "#4A8B6F" },
  { id: "moyenne", label: "Moyenne", color: "#E3A73B" },
  { id: "haute", label: "Haute", color: "#B5451B" },
];

