import { IconAlert, IconAward, IconMapPin, IconSprout, IconTree, IconTrophy } from '../components/icons/index';

export const DEFIS = [
  { id: "d1", title: "Planter 10 arbres", target: 10, unit: "arbres", points: 200 },
  { id: "d2", title: "Nettoyer un quartier", target: 1, unit: "quartier", points: 150 },
  { id: "d3", title: "Recycler 100 kg de déchets", target: 100, unit: "kg", points: 250 },
  { id: "d4", title: "Sensibiliser 50 personnes", target: 50, unit: "personnes", points: 180 },
];


export const BADGES = [
  { id: "b1", label: "Premier pas", desc: "1er signalement envoyé", icon: IconAlert, check: (st) => st.signalements.length >= 1 },
  { id: "b2", label: "Planteur", desc: "1er arbre enregistré", icon: IconSprout, check: (st) => st.arbres.length >= 1 },
  { id: "b3", label: "Vigie", desc: "5 signalements envoyés", icon: IconMapPin, check: (st) => st.signalements.length >= 5 },
  { id: "b4", label: "Forestier", desc: "10 arbres plantés", icon: IconTree, check: (st) => st.arbres.length >= 10 },
  { id: "b5", label: "Cent points", desc: "100 points cumulés", icon: IconAward, check: (st) => st.defisProgress.points >= 100 },
  { id: "b6", label: "Champion", desc: "Un défi terminé", icon: IconTrophy, check: (st) => DEFIS.some(d => (st.defisProgress[d.id] || 0) >= d.target) },
];

// Libellés des défis et badges par langue, indexés par id.


export const DEFIS_LABELS = {
  en: {
    d1: { title: "Plant 10 trees", unit: "trees" }, d2: { title: "Clean up a neighborhood", unit: "neighborhood" },
    d3: { title: "Recycle 100 kg of waste", unit: "kg" }, d4: { title: "Raise awareness with 50 people", unit: "people" },
  },
  pt: {
    d1: { title: "Plantar 10 árvores", unit: "árvores" }, d2: { title: "Limpar um bairro", unit: "bairro" },
    d3: { title: "Reciclar 100 kg de resíduos", unit: "kg" }, d4: { title: "Sensibilizar 50 pessoas", unit: "pessoas" },
  },
  es: {
    d1: { title: "Plantar 10 árboles", unit: "árboles" }, d2: { title: "Limpiar un barrio", unit: "barrio" },
    d3: { title: "Reciclar 100 kg de residuos", unit: "kg" }, d4: { title: "Sensibilizar a 50 personas", unit: "personas" },
  },
  sw: {
    d1: { title: "Panda miti 10", unit: "miti" }, d2: { title: "Safisha mtaa", unit: "mtaa" },
    d3: { title: "Rejeleza kilo 100 za taka", unit: "kg" }, d4: { title: "Elimisha watu 50", unit: "watu" },
  },
  ar: {
    d1: { title: "زراعة 10 أشجار", unit: "أشجار" }, d2: { title: "تنظيف حي", unit: "حي" },
    d3: { title: "إعادة تدوير 100 كغ من النفايات", unit: "كغ" }, d4: { title: "توعية 50 شخصًا", unit: "أشخاص" },
  },
};


export const BADGES_LABELS = {
  en: {
    b1: { label: "First step", desc: "1st report sent" }, b2: { label: "Planter", desc: "1st tree registered" },
    b3: { label: "Watcher", desc: "5 reports sent" }, b4: { label: "Forester", desc: "10 trees planted" },
    b5: { label: "Hundred points", desc: "100 points earned" }, b6: { label: "Champion", desc: "One challenge completed" },
  },
  pt: {
    b1: { label: "Primeiro passo", desc: "1ª ocorrência enviada" }, b2: { label: "Plantador", desc: "1ª árvore registada" },
    b3: { label: "Vigilante", desc: "5 ocorrências enviadas" }, b4: { label: "Florestal", desc: "10 árvores plantadas" },
    b5: { label: "Cem pontos", desc: "100 pontos acumulados" }, b6: { label: "Campeão", desc: "Um desafio concluído" },
  },
  es: {
    b1: { label: "Primer paso", desc: "1er reporte enviado" }, b2: { label: "Plantador", desc: "1er árbol registrado" },
    b3: { label: "Vigía", desc: "5 reportes enviados" }, b4: { label: "Forestal", desc: "10 árboles plantados" },
    b5: { label: "Cien puntos", desc: "100 puntos acumulados" }, b6: { label: "Campeón", desc: "Un reto completado" },
  },
  sw: {
    b1: { label: "Hatua ya kwanza", desc: "Ripoti ya kwanza imetumwa" }, b2: { label: "Mpandaji", desc: "Mti wa kwanza umesajiliwa" },
    b3: { label: "Mlinzi", desc: "Ripoti 5 zimetumwa" }, b4: { label: "Mtaalamu wa misitu", desc: "Miti 10 imepandwa" },
    b5: { label: "Pointi mia", desc: "Pointi 100 zimepatikana" }, b6: { label: "Bingwa", desc: "Changamoto moja imekamilika" },
  },
  ar: {
    b1: { label: "الخطوة الأولى", desc: "إرسال أول بلاغ" }, b2: { label: "زارع", desc: "تسجيل أول شجرة" },
    b3: { label: "الحارس", desc: "إرسال 5 بلاغات" }, b4: { label: "الحرّاج", desc: "زراعة 10 أشجار" },
    b5: { label: "مئة نقطة", desc: "الحصول على 100 نقطة" }, b6: { label: "البطل", desc: "إنجاز تحدٍّ واحد" },
  },
};


export function defiTitle(lang, id) { const d = DEFIS.find(x => x.id === id); return (DEFIS_LABELS[lang] && DEFIS_LABELS[lang][id]) ? DEFIS_LABELS[lang][id].title : (d ? d.title : id); }


export function defiUnit(lang, id) { const d = DEFIS.find(x => x.id === id); return (DEFIS_LABELS[lang] && DEFIS_LABELS[lang][id]) ? DEFIS_LABELS[lang][id].unit : (d ? d.unit : ""); }


export function badgeLabel(lang, id) { const b = BADGES.find(x => x.id === id); return (BADGES_LABELS[lang] && BADGES_LABELS[lang][id]) ? BADGES_LABELS[lang][id].label : (b ? b.label : id); }


export function badgeDesc(lang, id) { const b = BADGES.find(x => x.id === id); return (BADGES_LABELS[lang] && BADGES_LABELS[lang][id]) ? BADGES_LABELS[lang][id].desc : (b ? b.desc : ""); }

