import { IconAlert, IconHome, IconMapPin, IconTree, IconTrophy } from '../components/icons/index';

export const TABS = [
  { id: "accueil", label: "Accueil", icon: IconHome },
  { id: "carte", label: "Carte", icon: IconMapPin },
  { id: "signaler", label: "Signaler", icon: IconAlert, cta: true },
  { id: "arbre", label: "Mon Arbre", icon: IconTree },
  { id: "defis", label: "Défis", icon: IconTrophy },
];

