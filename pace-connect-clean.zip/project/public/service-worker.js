// Service worker minimal (placeholder).
// L'ancien fichier HTML monolithique référençait ./service-worker.js sans en
// fournir le contenu : ce fichier n'a donc pas pu être migré tel quel.
// Le cache "vrai" applicatif (tuiles carto hors-ligne) vit déjà côté client
// dans src/lib/tileCache.js (IndexedDB) et n'a pas besoin de ce SW pour fonctionner.
// À compléter si un cache d'assets (app shell) est souhaité, par ex. avec Workbox.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
