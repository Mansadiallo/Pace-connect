icon-192.png et icon-512.png référencés dans manifest.json / index.html ne sont pas
présents dans le fichier HTML source fourni (ils y étaient chargés en ./icon-192.png,
hors du <script> analysé). Le logo existe en revanche en base64 dans
src/constants/branding.js (LOGO_DATA_URL) — à exporter en PNG 192x192 et 512x512
et à déposer ici sous ces deux noms.
