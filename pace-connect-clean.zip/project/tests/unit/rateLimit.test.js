import { describe, it, expect, beforeEach } from "vitest";
import { checkLimiteFrequence } from "../../src/lib/rateLimit";

describe("checkLimiteFrequence", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("autorise les actions tant que la limite n'est pas atteinte", () => {
    expect(checkLimiteFrequence(3)).toBe(true);
    expect(checkLimiteFrequence(3)).toBe(true);
    expect(checkLimiteFrequence(3)).toBe(true);
  });

  it("bloque une fois la limite horaire atteinte", () => {
    checkLimiteFrequence(2);
    checkLimiteFrequence(2);
    expect(checkLimiteFrequence(2)).toBe(false);
  });
});
