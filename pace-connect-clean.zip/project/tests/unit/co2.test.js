import { describe, it, expect } from "vitest";
import { co2EstimeParArbre } from "../../src/lib/co2";

describe("co2EstimeParArbre", () => {
  it("retourne 0 kg pour un arbre planté à l'instant", () => {
    expect(co2EstimeParArbre({ plantedAt: Date.now() })).toBe(0);
  });

  it("estime ~6 kg après une demi-année (jeune plant, ~6 kg/an)", () => {
    const sixMoisMs = 182.5 * 86400000;
    const estim = co2EstimeParArbre({ plantedAt: Date.now() - sixMoisMs });
    expect(estim).toBeGreaterThanOrEqual(2);
    expect(estim).toBeLessThanOrEqual(4);
  });

  it("plafonne à 6 kg pile à un an", () => {
    const unAnMs = 365 * 86400000;
    expect(co2EstimeParArbre({ plantedAt: Date.now() - unAnMs })).toBe(6);
  });

  it("accélère à ~21 kg/an après la première année", () => {
    const deuxAnsMs = 2 * 365 * 86400000;
    // 6 (première année) + 21 (année suivante) = 27
    expect(co2EstimeParArbre({ plantedAt: Date.now() - deuxAnsMs })).toBe(27);
  });

  it("accepte planted_at (format Supabase) en plus de plantedAt", () => {
    const iso = new Date(Date.now() - 365 * 86400000).toISOString();
    expect(co2EstimeParArbre({ planted_at: iso })).toBe(6);
  });
});
