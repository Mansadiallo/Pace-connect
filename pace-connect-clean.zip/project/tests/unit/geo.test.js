import { describe, it, expect } from "vitest";
import { distanceMetres, pointInPolygon, gpsQualite, formatCap, formatVitesse } from "../../src/lib/geo";

describe("distanceMetres", () => {
  it("retourne ~0 pour deux points identiques", () => {
    expect(distanceMetres(5.35, -4.02, 5.35, -4.02)).toBeCloseTo(0, 5);
  });

  it("calcule une distance cohérente entre Abidjan et Dakar (≈ 1800 km à vol d'oiseau)", () => {
    const d = distanceMetres(5.3599, -4.0083, 14.6928, -17.4467);
    expect(d).toBeGreaterThan(1_750_000);
    expect(d).toBeLessThan(1_850_000);
  });
});

describe("pointInPolygon", () => {
  // Carré [lat, lng] de 0,0 à 10,10
  const carre = [[0, 0], [0, 10], [10, 10], [10, 0]];

  it("détecte un point à l'intérieur", () => {
    expect(pointInPolygon([5, 5], carre)).toBe(true);
  });

  it("détecte un point à l'extérieur", () => {
    expect(pointInPolygon([15, 15], carre)).toBe(false);
  });
});

describe("gpsQualite", () => {
  it("retourne Excellente sous 10m", () => {
    expect(gpsQualite(5).label).toBe("Excellente");
  });
  it("retourne Bonne entre 10 et 25m", () => {
    expect(gpsQualite(20).label).toBe("Bonne");
  });
  it("retourne Moyenne entre 25 et 50m", () => {
    expect(gpsQualite(40).label).toBe("Moyenne");
  });
  it("retourne Faible au-delà de 50m", () => {
    expect(gpsQualite(200).label).toBe("Faible");
  });
  it("retourne Inconnue si la précision est absente", () => {
    expect(gpsQualite(null).label).toBe("Inconnue");
    expect(gpsQualite(NaN).label).toBe("Inconnue");
  });
});

describe("formatCap", () => {
  it("formate un cap nul en Nord", () => {
    expect(formatCap(0)).toBe("0° (N)");
  });
  it("formate un cap de 90° en Est", () => {
    expect(formatCap(90)).toBe("90° (E)");
  });
  it("retourne un tiret si la valeur est absente", () => {
    expect(formatCap(null)).toBe("—");
    expect(formatCap(NaN)).toBe("—");
  });
});

describe("formatVitesse", () => {
  it("convertit des m/s en km/h", () => {
    expect(formatVitesse(10)).toBe("36.0 km/h");
  });
  it("retourne un tiret si la valeur est absente", () => {
    expect(formatVitesse(undefined)).toBe("—");
  });
});
