import { describe, it, expect, beforeEach, vi } from "vitest";
import {
  loadPendingQueue,
  savePendingQueue,
  enqueuePendingAction,
  dequeuePendingAction,
  PENDING_QUEUE_KEY,
} from "../../src/lib/offlineQueue";

describe("file d'attente hors-ligne (offlineQueue)", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("retourne une file vide par défaut", () => {
    expect(loadPendingQueue()).toEqual([]);
  });

  it("empile une action et la retrouve dans la file", () => {
    const id = enqueuePendingAction("signalement", { titre: "Décharge" });
    const queue = loadPendingQueue();
    expect(queue).toHaveLength(1);
    expect(queue[0].id).toBe(id);
    expect(queue[0].type).toBe("signalement");
    expect(queue[0].payload).toEqual({ titre: "Décharge" });
  });

  it("retire une action précise sans toucher aux autres", () => {
    const id1 = enqueuePendingAction("signalement", { a: 1 });
    const id2 = enqueuePendingAction("arbre", { b: 2 });
    dequeuePendingAction(id1);
    const queue = loadPendingQueue();
    expect(queue).toHaveLength(1);
    expect(queue[0].id).toBe(id2);
  });

  it("ne casse pas si le JSON stocké est corrompu", () => {
    localStorage.setItem(PENDING_QUEUE_KEY, "{ pas du json valide");
    expect(loadPendingQueue()).toEqual([]);
  });

  it("retire l'entrée la plus ancienne si le quota localStorage est dépassé", () => {
    const original = enqueuePendingAction("signalement", { a: 1 });
    enqueuePendingAction("arbre", { b: 2 });

    const setItemSpy = vi
      .spyOn(Storage.prototype, "setItem")
      .mockImplementationOnce(() => {
        throw new DOMException("quota dépassé", "QuotaExceededError");
      });

    savePendingQueue(loadPendingQueue());

    setItemSpy.mockRestore();
    const queue = loadPendingQueue();
    expect(queue.find((it) => it.id === original)).toBeUndefined();
  });
});
