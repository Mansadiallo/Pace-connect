import { describe, it, expect } from "vitest";
import { weeksAgo, weeklyBuckets } from "../../src/lib/stats";

function isoDaysAgo(days) {
  return new Date(Date.now() - days * 86400000).toISOString();
}

describe("weeksAgo", () => {
  it("reconnaît une date d'il y a 0 semaine (aujourd'hui)", () => {
    expect(weeksAgo(isoDaysAgo(1), 0)).toBe(true);
  });

  it("reconnaît une date d'il y a 2 semaines pleines", () => {
    expect(weeksAgo(isoDaysAgo(15), 2)).toBe(true);
  });

  it("rejette une date qui ne correspond pas au bucket demandé", () => {
    expect(weeksAgo(isoDaysAgo(15), 0)).toBe(false);
  });
});

describe("weeklyBuckets", () => {
  it("retourne le nombre de buckets demandé, du plus ancien au plus récent", () => {
    const buckets = weeklyBuckets([], 4);
    expect(buckets).toHaveLength(4);
    expect(buckets.map((b) => b.week)).toEqual([3, 2, 1, 0]);
  });

  it("compte correctement les items par semaine", () => {
    const items = [
      { created_at: isoDaysAgo(1) },  // semaine 0
      { created_at: isoDaysAgo(2) },  // semaine 0
      { created_at: isoDaysAgo(9) },  // semaine 1
    ];
    const buckets = weeklyBuckets(items, 2);
    const week0 = buckets.find((b) => b.week === 0);
    const week1 = buckets.find((b) => b.week === 1);
    expect(week0.count).toBe(2);
    expect(week1.count).toBe(1);
  });

  it("ignore les items sans date de création", () => {
    const buckets = weeklyBuckets([{ foo: "bar" }], 1);
    expect(buckets[0].count).toBe(0);
  });
});
