import { describe, it, expect } from "vitest";
import { toCSV } from "../../src/lib/media";

describe("toCSV", () => {
  const columns = [
    { key: "nom", label: "Nom" },
    { key: "score", label: "Score" },
  ];

  it("génère un en-tête simple (non quoté) suivi des lignes de données quotées", () => {
    // L'en-tête n'est pas mis entre guillemets dans le code d'origine : seules
    // les cellules de données le sont (voir src/lib/media.js: toCSV).
    const csv = toCSV([{ nom: "Awa", score: 12 }], columns);
    expect(csv).toBe('Nom,Score\n"Awa","12"');
  });

  it("échappe les guillemets internes", () => {
    const csv = toCSV([{ nom: 'Le "meilleur"', score: 5 }], columns);
    expect(csv).toContain('"Le ""meilleur"""');
  });

  it("remplace les valeurs manquantes par une chaîne vide", () => {
    const csv = toCSV([{ nom: "Awa" }], columns);
    expect(csv).toBe('Nom,Score\n"Awa",""');
  });

  it("gère une liste vide", () => {
    expect(toCSV([], columns)).toBe("Nom,Score");
  });
});
