import { describe, it, expect } from "vitest";
import { t, RTL_LANGS } from "../../src/i18n/index";

describe("t (traduction)", () => {
  it("retourne la traduction dans la langue demandée quand elle existe", () => {
    const fr = t("fr", "nav_accueil");
    const en = t("en", "nav_accueil");
    expect(fr).not.toBe(en);
  });

  it("retombe sur le français si la langue est inconnue", () => {
    expect(t("xx", "nav_accueil")).toBe(t("fr", "nav_accueil"));
  });

  it("retourne la clé elle-même si aucune traduction n'existe nulle part", () => {
    expect(t("fr", "cle_totalement_inexistante_xyz")).toBe(
      "cle_totalement_inexistante_xyz"
    );
  });
});

describe("RTL_LANGS", () => {
  it("contient l'arabe", () => {
    expect(RTL_LANGS).toContain("ar");
  });
});
