import { describe, it, expect, beforeEach } from "vitest";
import { uid, getDeviceId } from "../../src/lib/device";

describe("uid", () => {
  it("génère une chaîne alphanumérique non vide", () => {
    const id = uid();
    expect(typeof id).toBe("string");
    expect(id.length).toBeGreaterThan(0);
    expect(id).toMatch(/^[a-z0-9]+$/);
  });

  it("génère des identifiants différents à chaque appel", () => {
    const ids = new Set(Array.from({ length: 50 }, () => uid()));
    expect(ids.size).toBeGreaterThan(1);
  });
});

describe("getDeviceId", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("génère un identifiant et le persiste en localStorage", () => {
    const id = getDeviceId();
    expect(localStorage.getItem("pace-device-id")).toBe(id);
  });

  it("retourne le même identifiant à chaque appel", () => {
    const first = getDeviceId();
    const second = getDeviceId();
    expect(first).toBe(second);
  });
});
