import { describe, it, expect } from "vitest";
import { categorieLabel, urgenceLabel, CATEGORIES, URGENCE } from "../../src/constants/categories";

describe("categorieLabel", () => {
  it("retourne le libellé français par défaut (source de vérité)", () => {
    expect(categorieLabel("fr", "decharge")).toBe(
      CATEGORIES.find((c) => c.id === "decharge").label
    );
  });

  it("retourne le libellé anglais s'il existe", () => {
    expect(categorieLabel("en", "decharge")).toBe("Illegal dump");
  });

  it("retombe sur le libellé français si la traduction manque", () => {
    // "xx" n'existe pas comme langue -> fallback vers cat.label (FR)
    expect(categorieLabel("xx", "decharge")).toBe(
      CATEGORIES.find((c) => c.id === "decharge").label
    );
  });

  it("retourne l'id brut si la catégorie n'existe pas", () => {
    expect(categorieLabel("fr", "inexistant")).toBe("inexistant");
  });
});

describe("urgenceLabel", () => {
  it("retourne le libellé français par défaut", () => {
    expect(urgenceLabel("fr", "haute")).toBe(
      URGENCE.find((u) => u.id === "haute").label
    );
  });

  it("retourne l'id brut si le niveau d'urgence n'existe pas", () => {
    expect(urgenceLabel("fr", "inexistant")).toBe("inexistant");
  });
});
